/*author David Edward Condon, University of Pennsylvania*/
#include "safe_str_num.h"
#define GNU_SOURCE//strtok_r, getline
#include <math.h>//lgammal, pow, sqrt
#include <limits.h>//UINT_MAX definition
#include <strings.h>//strcasecmp
#include <sys/stat.h> // mkdir
#include "annotation.h"//for reading annotations and a few string functions
#include "fdr.h"
#include "dmr.h"//for calculating and identifying DMRs
#include "read_bisulfite_data.h"//reading bisulfite data
#include "my_string.h"//count_occurences
#include "option_range.h"//so I can get a range of options if I want to vary the options
#include "file_exists.h"
#include "is_program_installed.h"
#include "layout_R.h"
#include "uint.h"//adding and clearing 
#include "double.h"
#include "help.h"

struct options_struct {//will not contain all options
	unsigned int allowed_nucleotide_gap_between_CpN, MINIMUM_CPN_RANGE;
	unsigned int MAX_SIMILAR_CPN;
	bool make_bed_files, overwrite_output;
	unsigned int CPU;
	unsigned short int ALLOWED_NON_DEFAULTS;
	bool make_figures, printing_CpN_list;//, isolation;
	bool print_all_nucleotides;
	bool print_DMR_pvalue;
	bool fdr_on_all_cpn;
};

int main (int argc, char * argv[]) {
	puts("\n    ____  ___________________    _   ________");
   puts("   / __ \\/ ____/ ____/  _/   |  / | / /_  __/");
   puts("  / / / / __/ / /_   / // /| | /  |/ / / /   ");
   puts(" / /_/ / /___/ __/ _/ // ___ |/ /|  / / /    ");
   puts("/_____/_____/_/   /___/_/  |_/_/ |_/ /_/\n\nDifferential methylation: Easy, Fast, Identification and ANnoTation\n\n by David E. Condon, University of Pennsylvania, 2015-2017.\n\n");
	if (argc == 1) {//in case options or files aren't entered
		puts("The correct syntax is ./defiant [OPTIONS]... -i [FILES]\n\twhere [FILES] is a comma-separated list of input files within each replicate, and space-separated between different sets, e.g. control vs. case.\n");
		help();
		exit(EXIT_FAILURE);
	}
//See all default option settings here
//set options to defaults
	struct options_struct options;
	options.allowed_nucleotide_gap_between_CpN = 20000;
	options.MINIMUM_CPN_RANGE                  = 0;
	options.make_bed_files                     = false;
	options.CPU                                = 1;
	options.ALLOWED_NON_DEFAULTS               = 5;
	options.MAX_SIMILAR_CPN                    = 6;
	options.overwrite_output                   = true;
	options.make_figures                       = false;
	options.printing_CpN_list                  = false;
//	options.isolation                          = false;
	options.print_all_nucleotides              = false;
	options.print_DMR_pvalue                   = false;
	options.fdr_on_all_cpn                     = false;
//get structs of option ranges, these are the defaults
	option_range_struct coverage = get_option_range("10");
	option_range_struct CpN = get_option_range("5");
	option_range_struct d = get_option_range("1");
	option_range_struct p = get_option_range("0.05");
	option_range_struct percent = get_option_range("0.1");//10%
	option_range_struct skip = get_option_range("0");
	cutoff_struct default_option_range;
	default_option_range.coverage	= 10;
	default_option_range.CpN		= 5;
	default_option_range.d			= 1;
	default_option_range.p			= 0.05;
	default_option_range.percent	= 0.10;
	default_option_range.skip		= 0;
//
	bool DEBUG = false;
	bool dry = false;
	int input_file_start = 0;
	bool random_chromosomes_read = false, un_chromosomes_read = false;
	size_t labels_size = 0;
	unsigned int number_of_labels = 0;
	char *restrict total_label = NULL;
	char **restrict labels = NULL;
	char *restrict xaxis_label = strdup("CpN");
	char *restrict defiant_run_info_filename = strdup("defiant_run_info.txt");
	char *restrict FDR_type = NULL;
	for (unsigned short int loop = 1; loop < argc; loop++) {
		if (strcmp(argv[loop],"-b") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			options.make_bed_files = true;
			puts("You specified the '-b' option, so there will be an output bed file.");
		} else if (strcmp(argv[loop],"-c") == 0) {
			if (DEBUG == true) {
				printf("@ %s %u\n", __FILE__, __LINE__);
			}
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			coverage = get_option_range(argv[loop+1]);
			printf("The minimum coverage used will be %.0f\n",coverage.min);
			if (coverage.min != coverage.max) {
				printf("Coverage cutoffs will be incremented from %u to %u in steps of %u\n", (unsigned)coverage.min, (unsigned)coverage.max, (unsigned)coverage.step);
			}
			loop++;
		} else if (strcasecmp(argv[loop],"-CpN") == 0) {//command line flag for minimum CpN count
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			CpN = get_option_range(argv[loop+1]);
			if (CpN.min != CpN.max) {
				printf("CpN cutoffs will be incremented from %u to %u in steps of %u\n", (unsigned)CpN.min, (unsigned)CpN.max, (unsigned)CpN.step);
			}
			loop++;
		} else if (strcasecmp(argv[loop],"-cpu") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			if (is_string_integer(argv[loop+1]) == true) {
				options.CPU = safe_strtoul(argv[loop+1]);
				printf("Calculations will be split among %u CPU.\n", options.CPU);
				loop++;
			} else {
				printf("-cpu '%s' isn't an integer.\n", argv[loop+1]);
				exit(EXIT_FAILURE);
			}
		} else if (strcmp(argv[loop],"-d") == 0) {//looking for match to command line flag, 'd' = 'differentially methylated nucleotides
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			d = get_option_range(argv[loop+1]);
			if (d.min != d.max) {
				printf("You specified the '-d' option, so the minimum # of differentially methylated CpN will be increased from %u to %u in steps of %u\n", (unsigned)d.min, (unsigned)d.max, (unsigned)d.step);
			} else {
				printf("there will be a minimum of %u differentially methylated nucleotides in each region.\n",(unsigned)d.min);
			}
			loop++;
		} else if (strcasecmp(argv[loop], "-debug") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			DEBUG = true;
		} else if (strcmp(argv[loop], "-dry") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			dry = true;
		} else if (strcmp(argv[loop],"-D") == 0) {//D for Defaults
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			if (is_string_integer(argv[loop+1]) == true) {
				options.ALLOWED_NON_DEFAULTS = safe_strtoul(argv[loop+1]);
				if (options.ALLOWED_NON_DEFAULTS > 6) {
					printf("You specified %u allowed non-default cutoffs in parallelization, which is the equivalent of 6 non-defaults, as only 6 parameters can be parallelized.\n", options.ALLOWED_NON_DEFAULTS);
				}
				printf("You specified the '-D' option, so Defiant will calculate up to %u non-default cutoffs.\nThis will take Defiant much longer to compute.\n", options.ALLOWED_NON_DEFAULTS);
			} else {
				printf("-D '%s' isn't an integer.\n", argv[loop+1]);
				exit(EXIT_FAILURE);
			}
			loop++;
		} else if (strcmp(argv[loop],"-E") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			options.print_all_nucleotides = true;//defined in dmr.h
			puts("A p-value and percent will be printed for each nucleotide.");
		} else if (strcmp(argv[loop],"-f") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			if (is_program_installed("Rscript") == true) {
				options.make_figures = true;
			} else {
				puts("You specified '-f' to make figures, but Rscript is not installed.");
				exit(EXIT_FAILURE);
			}
			options.make_figures = true;
			puts("You specified the '-f' option, so figures will be made for each and every DMR.");
		} else if (strcasecmp(argv[loop], "-fdr") == 0) {
			options.fdr_on_all_cpn = true;
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "BH") == 0) ) {
				FDR_type = strdup("BH");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "fdr") == 0)) {
				FDR_type = strdup("BH");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "by") == 0)) {
				FDR_type = strdup("BY");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "Bonferroni") == 0)) {
				FDR_type = strdup("Bonferroni");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "hochberg") == 0)) {
				FDR_type = strdup("Hochberg");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "holm") == 0)) {
				FDR_type = strdup("Holm");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "hommel") == 0)) {
				FDR_type = strdup("Hommel");
			} else {
				loop--;
				FDR_type = strdup("BH");
			}
			printf("Adjusted p-value will be calculated using %s's method on each CpN.\n", FDR_type);
			printf("I %c[1mSTRONGLY DISCOURAGE%c[0m this option, as it will\n", 27, 27);
			puts("give many false negatives and poor precision.\n");
			loop++;
		} else if (strcmp(argv[loop],"-G") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			if (is_string_integer(argv[loop+1]) == true) {
				options.allowed_nucleotide_gap_between_CpN = (unsigned int)safe_strtoul(argv[loop+1]);
			} else {
				printf("-G %s isn't an integer.\n", argv[loop+1]);
				exit(EXIT_FAILURE);
			}
			printf("The maximum allowed gap between CpN will be %u nucleotides.\n", options.allowed_nucleotide_gap_between_CpN);
			loop++;
		} else if (strcasecmp(argv[loop],"-h") == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			help();
			exit(EXIT_SUCCESS);
		} else if (strcmp(argv[loop],"-i") == 0) {//start input files
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			if (input_file_start == argc) {
				printf("Please specify input file(s)... exiting now.\n");
				exit(EXIT_FAILURE);
			}
			input_file_start = loop+1;
			if ((argc - input_file_start) == 0) {
				puts("No data files were specified.");
				free(defiant_run_info_filename); defiant_run_info_filename = NULL;
				exit(EXIT_SUCCESS);
			}
			printf("There are %u sets to be read\n", argc - input_file_start);
			break;//no point in looping through input file names and making additional needless comparisons
/*		} else if (strcmp("-I", argv[loop]) == 0) {
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			options.isolation = true;
			puts("You specified the '-I' option, so the distance between *detected* CpG will be printed.");*/
		} else if (strcmp(argv[loop], "-j") == 0) {
			
		} else if (strcmp(argv[loop],"-l") == 0) {//looking for match to command line flag
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			total_label = strdup(argv[loop+1]);
			if (total_label == NULL) {
				printf("mallof of total_label failed @ %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			defiant_run_info_filename = realloc(defiant_run_info_filename, sizeof(char)*strlen("defiant_run_info_.txt")+sizeof(char*)*strlen(total_label));
			if (defiant_run_info_filename == NULL) {
				printf("realloc of defiant_run_info_filename failed @ %s line %u\n", __FILE__, __LINE__);
				perror("");
				exit(EXIT_FAILURE);
			}
			strcpy(defiant_run_info_filename, "defiant_run_info_");
			strcat(defiant_run_info_filename, argv[loop+1]);
			strcat(defiant_run_info_filename, ".txt");//add null terminating string
			printf("Answer files will have \"%s\" in their names, and run information will be written to %s\n", argv[loop+1], defiant_run_info_filename);
			loop++;
		} else if (strcmp(argv[loop],"-L") == 0) {//labels with -f option
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			char *restrict label = NULL;
			char * labels_pointer = NULL;
			label = strtok_r(argv[loop+1],",",&labels_pointer);
			labels = add_name(labels, &labels_size, &number_of_labels, label, false, true);
			label = strtok_r(NULL,",", &labels_pointer);
			while (label != NULL) {
				if (label == NULL) {
					break;
				}
				labels = add_name(labels, &labels_size, &number_of_labels, label, false, true);
				label = strtok_r(NULL,",", &labels_pointer);
			}
			for (unsigned short int x = 0; x < number_of_labels; x++) {
				printf("Set %u will be labeled \"%s\"\n", x+1, labels[x]);
			}
			loop++;
		} else if (strcmp(argv[loop],"-N") == 0) {//print nucleotide list (Yu-Chin's request)
			if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
			options.printing_CpN_list = true;
			puts("\nYou specified the '-N' option, so Defiant will print a list of individually differentially methylated nucleotides in the answers file.\n");
		} else if (strcmp(argv[loop],"-o") == 0) {
			options.overwrite_output = false;
			puts("You specified the '-o' option, so files will not be overwritten if they exist.");
		} else if (strcmp(argv[loop],"-p") == 0) {//looking for match to command line flag
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			p = get_option_range(argv[loop+1]);
			if ((p.min < 0.0) || (p.min > 1.0) || (p.max < 0.0) || (p.max > 1.0)) {
				printf("Maximum p-value is defined to be 0 <= p <= 1, and you selected %s\n",argv[loop+1]);
				exit(EXIT_FAILURE);
			}
			if (p.min != p.max) {
				printf("p-value cutoffs will be incremented from %lf to %lf in steps of %lf\n", p.min, p.max, p.step);
			}
			loop++;//I already know what the next value will be
		} else if (strcmp(argv[loop],"-P") == 0) {//command line flag for minimum percent change
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			percent = get_option_range(argv[loop+1]);
			if ((percent.min < 0.0) || (percent.min > 100.0) || (percent.max < 0.0) || (percent.max > 100.0)|| (percent.step < 0.0) || (percent.step > 100.0)) {
				printf("Minimum percent is defined to be 0 <= p <= 100, and you selected %s\n",argv[loop+1]);
				exit(EXIT_FAILURE);
			}
			if (percent.min != percent.max) {
				printf("Percentage cutoffs will be incremented from %lf to %lf in steps of %lf\n", percent.min, percent.max, percent.step);
			}
			percent.min /= 100;
			percent.max /= 100;
			percent.step /= 100;
			loop++;
		} else if ((strcmp(argv[loop],"-q") == 0) || (strcmp(argv[loop],"-promoter_cutoff") == 0)) {
			promoter_cutoff = (unsigned int)strtoul(argv[loop+1],NULL,0);
			printf("Intergenic genes will be assigned a promoter cutoff of %u nucleotides for identification.\n", promoter_cutoff);
			loop++;
		} else if (strcmp(argv[loop],"-r") == 0) {//command line flag for CpN range
			options.MINIMUM_CPN_RANGE = (unsigned short int)strtoul(argv[loop+1],NULL,0);
			printf("The minimum CpN range is set to %u nucleotides.\n",options.MINIMUM_CPN_RANGE);
			loop++;
		} else if (strcmp(argv[loop],"-R") == 0) {//command line flag for reading random chromosomes
			random_chromosomes_read = true;
			puts("Random nucleotides will be included in analysis.\n");
		} else if (strcmp(argv[loop],"-S") == 0) {
			if (strcasecmp(argv[loop+1],"inf") == 0) {//case insensitive comparison
				skip.min = UINT_MAX-1;
				skip.max = UINT_MAX-1;
				skip.step = 1.0;
				loop++;
				printf("You entered '-S %s', so the limit of skips will be infinite (set to %.0f, which is big enough)\n", argv[loop], skip.min);
			} else {
				skip = get_option_range(argv[loop+1]);
				if (percent.min != percent.max) {
					printf("Skip cutoffs will be incremented from %.0f to %.0f in steps of %lf\n", skip.min, skip.max, skip.step);
				} else {
					printf("There will be %.0f allowed consecutive skip(s) of low coverage nucleotides when reading data.\n",skip.min);
				}
				loop++;
			}
		} else if (strcmp(argv[loop],"-s") == 0) {
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			if (is_string_integer(argv[loop+1]) == true) {
				options.MAX_SIMILAR_CPN = safe_strtoul(argv[loop+1]);
				printf("The maximum number of allowed similar CpN after differentially methylated CpN is %u.\n", options.MAX_SIMILAR_CPN);
				loop++;
			} else {
				printf("-s '%s' isn't an integer.\n", argv[loop+1]);
				free(defiant_run_info_filename); defiant_run_info_filename = NULL;
				exit(EXIT_FAILURE);
			}
		} else if (strcmp(argv[loop],"-U") == 0) {//command line flag for annotation
			un_chromosomes_read = true;
			puts("Un nucleotides will be read.");
		} else if (strcmp(argv[loop],"-v") == 0) {
			options.print_DMR_pvalue = true;
			if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "BH") == 0) ) {
				FDR_type = strdup("BH");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "fdr") == 0)) {
				FDR_type = strdup("BH");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "by") == 0)) {
				FDR_type = strdup("BY");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "Bonferroni") == 0)) {
				FDR_type = strdup("Bonferroni");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "hochberg") == 0)) {
				FDR_type = strdup("Hochberg");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "holm") == 0)) {
				FDR_type = strdup("Holm");
			} else if ((loop < (argc-1)) && (strcasecmp(argv[loop+1], "hommel") == 0)) {
				FDR_type = strdup("Hommel");
			} else {
				loop--;
				FDR_type = strdup("BH");
			}
			loop++;
			printf("You specified the '-v' option, so a p-value & an adjusted p-value using %s's method will be printed for each DMR.\n", FDR_type);
/*		} else if (strcmp(argv[loop],"-w") == 0) {
			options.pvalue_scaling = true;
			puts("you specified the '-w' option, so DMR p-values will be scaled according to the distribution.");*/
		} else if (strcmp(argv[loop],"-x") == 0) {
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			if (is_program_installed("Rscript") == false) {
				puts("You are attempting to make figures, but you don't have Rscript installed.");
				exit(EXIT_FAILURE);
			}
			free(xaxis_label); xaxis_label = NULL;
			xaxis_label = strdup(argv[loop+1]);
			options.make_figures = true;
			printf("You specified the \"-x\" option, so the xaxis in figures will be labeled \"%s\".  Figures will be made.\n", xaxis_label);
			loop++;
		} else if (strcmp(argv[loop],"-a") == 0) {//command line flag for annotation
			if (loop == (argc-1)) {//prevents segfault on argv
				printf("the '%s' option requires something to come after it.\n", argv[loop]);
				printf("Failed at %s line %u\n", __FILE__, __LINE__);
				exit(EXIT_FAILURE);
			}
			FILE *restrict file;//does this file exist? 
			if (DEBUG == true) {
				printf("@ %s %u\n", __FILE__, __LINE__);
			}
			if ((file = fopen(argv[loop+1], "r")) == NULL) {
				printf("gene annotation file %s (specified by -a flag) could not be read, maybe this file doesn't exist or doesn't have proper read permissions.\n",argv[loop+1]);
				perror("");
				exit(EXIT_FAILURE);
			}
			fclose(file);
//---------------------------------------------------------------------------------------------
//Read gene data to memory
//---------------------------------------------------------------------------------------------
//check file type
			unsigned short int annotation_file_type = 0;		
			FILE *restrict fh0;
			fh0 = fopen(argv[loop+1],"r");
			if (fh0 == NULL) {
				perror("");
				printf("Failed to read %s\n", argv[loop+1]);
				exit(EXIT_FAILURE);
			}
	   	size_t len = 0;
	   	ssize_t read = 0;
			char *gene_line = NULL;
	   	while ((read = getline(&gene_line, &len, fh0)) != -1) {//http://man7.org/linux/man-pages/man3/getline.3.html
	   		annotation_file_type = get_annotation_type(gene_line);
	   		if (annotation_file_type > 0) {
	   			break;
	   		}//keep going if the annotation file isn't defined (i.e. = 0)
			}
			free(gene_line); gene_line = NULL;
			fclose(fh0);
			if (annotation_file_type == 0) {
				printf("Failed to find annotation type for %s\n",argv[loop+1]);
				exit(EXIT_FAILURE);
			}
//
			char *restrict annotation_filename = NULL;
			bool sorted = true;
			if (annotation_file_type != 1) {//only type 1 is sorted
				annotation_filename = strdup(argv[loop+1]);//if the file doesn't need sorting
				sorted = false;
			} else {//i.e., the annotation file needs to be sorted
				annotation_filename = strdup("temporary_file_will_delete");
				char *restrict command = malloc(strlen("temporary_file_will_delete")*sizeof(char) + sizeof(char)*strlen(argv[loop+1]) + sizeof(char)*200);//200 is about 2x the length of the grep command
				sprintf(command,"grep -v chrUn %s | grep -Pv '^\\S+\\s+\\S+\\s+chr.*_' | sort -k 3,3 -k 5n,5n -k 6n,6n -k 7n,7n -k 8n,8n > %s",argv[loop+1],annotation_filename);
				if (system(command) != 0) {
					puts("sort command failed.");
					perror("");
					exit(EXIT_FAILURE);
				}
				free(command); command = NULL;
			}
			FILE *restrict fh = fopen(annotation_filename,"r");
			if (fh == NULL) {
				printf("Could not open %s :( dying :,(\n",annotation_filename);
				perror("");
				exit(EXIT_FAILURE);
			}
			printf("Reading gene annotation %s\n", argv[loop+1]);
			gene_annotation_defined = true;
			char previous_chromosome[] = "Ave Maria Dominus Tecum benedicta tu en mulieribus et";
			gene_chromosome_changes = malloc(0);
			unsigned short int GENES_chromosome_change_index = 0;
	   	GENES_chromosome_change_index = 0;//globally accessed variable declared before main
	   	while ((read = getline(&gene_line, &len, fh)) != -1) {//http://man7.org/linux/man-pages/man3/getline.3.html
//				printf("@%s line %u	%s\n", __FILE__, __LINE__, gene_line);//debugging
				const ANNOTATION_LINE_STRUCT line = read_gene_annotation_line(gene_line, annotation_file_type);
				if (line.sense == 0) {//i.e. this is a transcript and not a gene
					continue;
				}//don't allocate if it's not necessary
				if ((number_of_annotated_genes > 0) && (strcmp(line.gene_name,GENES[number_of_annotated_genes-1].gene_name) == 0)) {
//				printf("%s %u-%u\n",GENES[number_of_annotated_genes-1].gene_name, GENES[number_of_annotated_genes-1].gene_start, GENES[number_of_annotated_genes-1].gene_end);
					GENES[number_of_annotated_genes-1].gene_start = line.gene_start < GENES[number_of_annotated_genes-1].gene_start ? line.gene_start : GENES[number_of_annotated_genes-1].gene_start;
					GENES[number_of_annotated_genes-1].gene_end = line.gene_end > GENES[number_of_annotated_genes-1].gene_end ? line.gene_end : GENES[number_of_annotated_genes-1].gene_end;
//					printf("%s %u-%u\n",GENES[number_of_annotated_genes-1].gene_name, GENES[number_of_annotated_genes-1].gene_start, GENES[number_of_annotated_genes-1].gene_end);
					continue;//some GTF files lack genes, have only transcripts, so exact gene boundaries aren't known
				}
				GENES = realloc(GENES,(number_of_annotated_genes+1)*sizeof(GENES_STRUCT));//add memory for this gene
				if (GENES == NULL) {//error checking
					printf("realloc of GENES failed at index %u\n",number_of_annotated_genes);
					printf("GENES struct failed realloc for line %s; file %s line %u.\n",gene_line,__FILE__,__LINE__);//DEBUGGING
					exit(EXIT_FAILURE);
				}
				GENES[number_of_annotated_genes].gene_start = line.gene_start;
				GENES[number_of_annotated_genes].gene_end = line.gene_end;
				GENES[number_of_annotated_genes].sense = line.sense;
				safe_string_copy(GENES[number_of_annotated_genes].gene_name, line.gene_name);
				if (strcmp(previous_chromosome,line.chromosome) != 0) {
//					if (DEBUG == true) {
//						printf("line %u -> %s changes to %s\n",__LINE__, previous_chromosome, column);//DEBUGGING
//					}
					number_of_chromosomes_in_GENES++;
					gene_chromosome_changes = realloc(gene_chromosome_changes, number_of_chromosomes_in_GENES*sizeof(CHROMOSOME_CHANGES_STRUCT));
					if (gene_chromosome_changes == NULL) {
						printf("@line %u	realloc of gene_chromosome_changes failed.\n",__LINE__);
						exit(EXIT_FAILURE);
					}
					gene_chromosome_changes[GENES_chromosome_change_index].index = number_of_annotated_genes;
					safe_string_copy(gene_chromosome_changes[GENES_chromosome_change_index].chromosome,line.chromosome);
					if (DEBUG == true) {
						printf("chromosome %s, gene_chromosome_changes[%u] = %zu\n",gene_chromosome_changes[GENES_chromosome_change_index].chromosome,GENES_chromosome_change_index,gene_chromosome_changes[GENES_chromosome_change_index].index);
					}
					GENES_chromosome_change_index++;
					safe_string_copy(previous_chromosome,line.chromosome);
					if (strcmp(previous_chromosome,line.chromosome) != 0) {
						printf("%s failed copy from %s @ line %u\n",previous_chromosome,line.chromosome,__LINE__);
						exit(EXIT_FAILURE);
					}
				}
				number_of_annotated_genes++;//also by line
			}//end reading file
			fclose(fh);
			free(gene_line); gene_line = NULL;
			printf("Finished reading gene annotation %s\n", argv[loop+1]);
//	printf("@line %u\n", __LINE__);
			if (sorted == true) {//sorted_gene_filename will be хрень in this case
				if (remove(annotation_filename) != 0) {//deleting temporary sorted file
					printf("Couldn't delete %s\n",annotation_filename);
					exit(EXIT_FAILURE);
				}
			}
			free(annotation_filename); annotation_filename = NULL;
//			printf("GENES[%u]:\tChromosome %s end -> [%u,%u]\n",index,gene_chromosome_changes[GENES_chromosome_change_index].chromosome,GENES[index].gene_start,GENES[index].gene_end);//debugging
			printf("There are %u genes and %u chromosomes read from %s.\n",number_of_annotated_genes, number_of_chromosomes_in_GENES, argv[loop+1]);
			printf("finished reading gene data from %s into RAM.\n",argv[loop+1]);//Tell user program has finished reading gene data into RAM
			if (DEBUG == true) {
				if (number_of_annotated_genes >= 1) {
					printf("last gene goes from %u-%u\n", GENES[number_of_annotated_genes-1].gene_start, GENES[number_of_annotated_genes-1].gene_end);
				} else {
					puts("There are 0 genes in GENES struct.");
				}
			}
			loop++;//the next string will be the file, no sense in strcmp the file
		} else {
			printf("\"%s\" isn't a recognized option.\n", argv[loop]);
			help();
			exit(EXIT_FAILURE);
		}
	}
	if (input_file_start == 0) {
		free(xaxis_label); xaxis_label = NULL;
		free(defiant_run_info_filename); defiant_run_info_filename = NULL;
		puts("Input files were not defined with the '-i' option.\nThe correct syntax is `defiant [OPTIONS]... -i [FILES]'\n\twhere [FILES] is a comma-separated list of input files within each replicate, and space-separated between different sets, e.g. control vs. case.");
		help();
		exit(EXIT_FAILURE);
	}
	if (input_file_start > (argc-2)) {
		free(xaxis_label); xaxis_label = NULL;
		free(defiant_run_info_filename); defiant_run_info_filename = NULL;
		help();
		puts("There must be at least two sets of data to be compared.");
		exit(EXIT_FAILURE);
	}
	if (DEBUG == true) {printf("@ %s %u\n", __FILE__, __LINE__);}
//------------------------------------------
//make struct of cutoffs
//-----------------------------------------
	const unsigned int RUNS = how_many_runs(coverage, CpN, d, p, percent, skip, default_option_range, options.ALLOWED_NON_DEFAULTS, options.CPU);
	cutoff_struct *restrict cutoff = make_cutoff_struct(coverage, CpN, d, p, percent, skip, default_option_range, options.ALLOWED_NON_DEFAULTS, options.CPU);
	printf("There will be %u runs.\n", RUNS);
	if (dry == true) {
		free(xaxis_label); xaxis_label = NULL;
		free(defiant_run_info_filename); defiant_run_info_filename = NULL;
		printf("c\tCpN\td\tp\tP\tS\t#DMR\n");
		for (unsigned int run = 0; run < RUNS; run++) {
			printf( "%u\t%u\t%u\t%g\t%.1f\t%u\t%u\n", cutoff[run].coverage, cutoff[run].CpN, cutoff[run].d, cutoff[run].p, 100.0*cutoff[run].percent, cutoff[run].skip, cutoff[run].number_of_DMRs);
		}
		free(cutoff); cutoff = NULL;
		exit(EXIT_SUCCESS);
	}
	if (options.make_figures == true) {
		if (file_exists("DMR_figures") == false) {
			if (mkdir("DMR_figures",0777) == -1) {
				perror("Cannot create directory");
				exit(EXIT_FAILURE);
			}
		}
		if (RUNS > 1) {
			printf("You are making figures for %u runs, this will take a lot longer.\n", RUNS);
		}
	} else {
		free(xaxis_label); xaxis_label = NULL;
	}
//
	FILE *restrict defiant_run_info;
	printf("Run information will be printed to %s\n", defiant_run_info_filename);
	defiant_run_info = fopen(defiant_run_info_filename,"w");
	fprintf(defiant_run_info,"The following arguments were submitted to the command line: ");
	if (defiant_run_info == NULL) {
		printf("Failed to write %s\n", defiant_run_info_filename);
		perror("");
		exit(EXIT_FAILURE);
	}
	for (unsigned short int x = 0; x < argc; x++) {//print the command line arguments to the run_info file
		fprintf(defiant_run_info," %s",argv[x]);
	}
	fprintf(defiant_run_info,"\n");
	const unsigned short int SETS = argc-input_file_start;
	if (SETS != number_of_labels) {
		printf("There are %u labels, yet %u sets, just a warning that you may not have correctly labeled data.\n", number_of_labels, SETS);
	}
	unsigned short int *restrict number_of_replicates_per_set = malloc(SETS*sizeof(unsigned short int));
	unsigned int bs_data_chromosome_changes_RAM_size = SETS*sizeof(CHROMOSOME_CHANGES_STRUCT***);
	CHROMOSOME_CHANGES_STRUCT ***restrict bs_data_chromosome_changes = malloc(bs_data_chromosome_changes_RAM_size);//trace chromosome changes to accelerate searching later on, chromosome_changes[set][replicate][chromosome_loop]
	size_t BISULFITE_DATA_total_size = sizeof(BISULFITE_DATA_STRUCT***)+sizeof(BISULFITE_DATA_STRUCT);
	BISULFITE_DATA_STRUCT ***restrict BISULFITE_DATA = malloc(BISULFITE_DATA_total_size);//were bisulfite sequencing data goes
	unsigned short int number_of_data_chromosomes = 0;
//---------------------------------------------------------------------------------------------
//Begin reading data files
//---------------------------------------------------------------------------------------------
	unsigned int global_array_size = SETS*sizeof(size_t);//keep track of array sizes for alloc, global_methylated_C_array & global_coverage_array, will have the same size
	size_t **restrict global_methylation = malloc(global_array_size);//global coverage can have >= 1 set, so I cannot store values in DMR_struct, which can only have 2 sets
	size_t **restrict global_coverage = malloc(global_array_size);
	for (unsigned short int set_loop = input_file_start; set_loop < argc; set_loop++) {//for each set
		const unsigned short int set = set_loop-input_file_start;
		unsigned int MINIMUM_READ_COVERAGE = skip.min > 0 ? 0 : coverage.min;
		if (options.print_all_nucleotides == true) {
			MINIMUM_READ_COVERAGE = 0;
		}
		number_of_replicates_per_set[set] = count_occurences_of_string(argv[set+input_file_start],",")+1;//used as array index; +1 because 2 commas
		if (DEBUG == true) {
			printf("There are %u replicates in set %u @ line %u.\n",number_of_replicates_per_set[set],set, __LINE__);
		}
		global_array_size += sizeof(size_t) * number_of_replicates_per_set[set];
		global_methylation = realloc(global_methylation, global_array_size);
		if (global_methylation == NULL) {
			printf("@ %s line %u	realloc of global_methylation failed.\n",__FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		global_coverage = realloc(global_coverage, global_array_size);
		if (global_coverage == NULL) {
			printf("@line %u	realloc of global_coverage failed.\n",__LINE__);
			exit(EXIT_FAILURE);
		}
		global_methylation[set] = calloc(number_of_replicates_per_set[set], number_of_replicates_per_set[set] * sizeof(size_t));
		global_coverage[set] = calloc(number_of_replicates_per_set[set], number_of_replicates_per_set[set] * sizeof(size_t));
		fprintf(defiant_run_info,"These files are considered set %u: %s\n\n",set+1,argv[set+input_file_start]);
//alloc set for BISULFITE_DATA
		size_t BISULFITE_DATA_set_RAM_size = 8*sizeof(BISULFITE_DATA_STRUCT)*number_of_replicates_per_set[set];
		BISULFITE_DATA_total_size += BISULFITE_DATA_set_RAM_size;
		BISULFITE_DATA = realloc(BISULFITE_DATA, BISULFITE_DATA_total_size);
		if (BISULFITE_DATA == NULL) {
			printf("@line %u	realloc of BISULFITE_DATA failed.\n", __LINE__);
			exit(EXIT_FAILURE);
		}
		BISULFITE_DATA[set] = malloc(BISULFITE_DATA_set_RAM_size);
//alloc set for bs_data_chromosome_changes
		size_t bs_data_chromosome_changes_set_RAM_size = number_of_replicates_per_set[set] * sizeof(CHROMOSOME_CHANGES_STRUCT);
		bs_data_chromosome_changes_RAM_size += bs_data_chromosome_changes_set_RAM_size;
		bs_data_chromosome_changes = realloc(bs_data_chromosome_changes, bs_data_chromosome_changes_RAM_size);
		if (bs_data_chromosome_changes == NULL) {
			printf("@line %u	realloc of bs_data_chromosome_changes failed.\n", __LINE__);
			exit(EXIT_FAILURE);
		}
		bs_data_chromosome_changes[set] = malloc(bs_data_chromosome_changes_set_RAM_size);
		char *restrict files;
		char *files_pointer;
		files = strtok_r(argv[set_loop],",",&files_pointer);//start string token extraction
		unsigned short int replicate = 0;//, data_chromosomes_index = 0;
		while (files != NULL) {//parsing arguments from command line, for each file
			char previous_chromosome[] = "UNDEFINED";
			FILE *restrict BISULFITE_DATA_file;
			BISULFITE_DATA_file = fopen(files,"r");
			printf("Now reading file %s into memory...\n",files);//debugging, telling end user what's happening
			if (BISULFITE_DATA_file == NULL) {
				printf("Could not open %s\n",files);
				perror("");
				exit(EXIT_FAILURE);
			}
			char *bs_line = NULL;
			size_t len = 0, index = 0;
			ssize_t read;//for getline function
//		printf("now alloc'ing BISULFITE_DATA[%u][%u] on line %u\n",set, replicate, __LINE__);
			size_t BISULFITE_DATA_replicate_RAM_size = sizeof(BISULFITE_DATA_STRUCT);
			BISULFITE_DATA[set][replicate] = malloc(BISULFITE_DATA_replicate_RAM_size);
//
			size_t bs_data_chromosome_changes_replicate_RAM_size = sizeof(CHROMOSOME_CHANGES_STRUCT);
			bs_data_chromosome_changes[set][replicate] = malloc(bs_data_chromosome_changes_replicate_RAM_size);
			unsigned short int bs_data_chromosome_changes_chromosome_loop = 0;
//about getting file types
			unsigned int failed_coverage = 0, passed_coverage = 0;
			bool two_strands = false;
			FILE_TYPE_STRUCT file_type;
			file_type.type = 0;
//			printf("starting methylated_C = %u	starting coverage = %u\n", global_methylated_C_array[set][replicate], global_coverage_array[set][replicate]);
			while ((read = getline ( &bs_line, &len, BISULFITE_DATA_file)) != -1) {//splitting files based on whitespace
//				printf("%s",bs_line);//DEBUGGING
				if (file_type.type == 0) {//i.e. not defined
	 				file_type = get_file_type(bs_line);
	 				if ((file_type.type == 2) || (file_type.type == 5) || (file_type.type == 9) || (file_type.type == 10)) {
	 					two_strands = true;
	 				}
	 			}
	 			if (file_type.header == true) {
	 				file_type.header = false;
	 				continue;
	 			}
				if ((un_chromosomes_read == false) && (strstr(bs_line,"_random") != NULL)) {//skip lines with "random"
					continue;
				} else if ((random_chromosomes_read == false) && (strstr(bs_line,"Un") != NULL)) {//skip lines with "Un"
					continue;
				} else if (strstr(bs_line,"_alt") != NULL) {//skip lines with "_alt"
					continue;
				}
	 			LINE_STRUCT line = read_data_line(bs_line, file_type.type, (const bool) DEBUG);
				if (line.nucleotide == 0) {
					continue;
				}
//				printf("%s\n=>chromosome = %s;\tmC = %u\tmethC = %u\tcoverage = %u\n",bs_line,line.chromosome,line.nucleotide,line.methylated_C,line.coverage);//debugging
				if ((two_strands == false) && (line.coverage < MINIMUM_READ_COVERAGE)) {
//					printf("failed coverage");
					if (line.coverage < coverage.min) {
						failed_coverage++;
					}
					continue;
				}
				passed_coverage++;
				if ((two_strands == true) && (index > 0) && (line.nucleotide == (BISULFITE_DATA[set][replicate][index-1].nucleotide+1))) {
					BISULFITE_DATA[set][replicate][index-1].methylated_C += line.methylated_C;
					BISULFITE_DATA[set][replicate][index-1].coverage += line.coverage;
					continue;//add the the last index
				} else if ((two_strands == true) && (index > 0) && (BISULFITE_DATA[set][replicate][index-1].coverage < MINIMUM_READ_COVERAGE) && (line.nucleotide > (BISULFITE_DATA[set][replicate][index-1].nucleotide+1))) {
					BISULFITE_DATA[set][replicate][index-1].methylated_C = line.methylated_C;
					BISULFITE_DATA[set][replicate][index-1].coverage = line.coverage;
					BISULFITE_DATA[set][replicate][index-1].nucleotide = line.nucleotide;
					continue;//overwrite the last index if I can't use it
				}
		 		removeSubstring(line.chromosome,"chr");
				if (strcmp(line.chromosome,previous_chromosome) != 0) {
//				printf("found a switch from chromosome %s to %s for element %u\n",previous_chromosome, chromosome, bs_data_chromosome_changes_chromosome_loop);
					bs_data_chromosome_changes_RAM_size += sizeof(CHROMOSOME_CHANGES_STRUCT);
					bs_data_chromosome_changes = realloc(bs_data_chromosome_changes, bs_data_chromosome_changes_RAM_size);
					if (bs_data_chromosome_changes == NULL) {
						printf("@line %u	realloc of bs_data_chromosome_changes failed @ chromosome %s.\n", __LINE__, line.chromosome);
						exit(EXIT_FAILURE);
					}
					bs_data_chromosome_changes_set_RAM_size += sizeof(CHROMOSOME_CHANGES_STRUCT);
					bs_data_chromosome_changes[set] = realloc(bs_data_chromosome_changes[set], bs_data_chromosome_changes_set_RAM_size);
					bs_data_chromosome_changes_replicate_RAM_size += sizeof(CHROMOSOME_CHANGES_STRUCT);
					bs_data_chromosome_changes[set][replicate] = realloc(bs_data_chromosome_changes[set][replicate],bs_data_chromosome_changes_replicate_RAM_size);
					bs_data_chromosome_changes[set][replicate][bs_data_chromosome_changes_chromosome_loop].index = index;
					safe_string_copy(bs_data_chromosome_changes[set][replicate][bs_data_chromosome_changes_chromosome_loop].chromosome, line.chromosome);
					if (DEBUG == true) {
						printf("%s -> bs_data_chromosome_changes[%u][%u][%u].index = %zu (chromosome %s at %s line %u)\n",line.chromosome,set,replicate,bs_data_chromosome_changes_chromosome_loop, bs_data_chromosome_changes[set][replicate][bs_data_chromosome_changes_chromosome_loop].index,line.chromosome, __FILE__, __LINE__);//debugging
					}
					safe_string_copy(previous_chromosome,line.chromosome);
					bs_data_chromosome_changes_chromosome_loop++;
				}
//Begin reallocing BISULFITE_bs_data_chromosome_changesDATA
				BISULFITE_DATA_total_size += sizeof(BISULFITE_DATA_STRUCT);
				BISULFITE_DATA = realloc(BISULFITE_DATA,BISULFITE_DATA_total_size);
				if (BISULFITE_DATA == NULL) {
					printf("realloc of BISULFITE_DATA failed @ line %u.", __LINE__);
					exit(EXIT_FAILURE);
				}
				BISULFITE_DATA_set_RAM_size += sizeof(BISULFITE_DATA_STRUCT);
				BISULFITE_DATA[set] = realloc(BISULFITE_DATA[set], BISULFITE_DATA_set_RAM_size);
				if (BISULFITE_DATA[set] == NULL) {
					printf("realloc of BISULFITE_DATA[%u] failed @ %s line %u.",set , __FILE__, __LINE__);
					exit(EXIT_FAILURE);
				}
				BISULFITE_DATA_replicate_RAM_size += sizeof(BISULFITE_DATA_STRUCT);
				BISULFITE_DATA[set][replicate] = realloc(BISULFITE_DATA[set][replicate], BISULFITE_DATA_replicate_RAM_size);
				if (BISULFITE_DATA[set][replicate] == NULL) {
					printf("realloc of BISULFITE_DATA[%u][%u] failed @ line %u.",set ,replicate, __LINE__);
					exit(EXIT_FAILURE);
				}
				BISULFITE_DATA[set][replicate][index].nucleotide = line.nucleotide;
				BISULFITE_DATA[set][replicate][index].methylated_C = line.methylated_C;
				BISULFITE_DATA[set][replicate][index].coverage = line.coverage;
//				printf("%s\t@line %u\t nucleotide = %u\t methylated_C = %u\tcoverage = %u\t%lf\n",bs_line,__LINE__, BISULFITE_DATA[set][replicate][index].nucleotide, BISULFITE_DATA[set][replicate][index].methylated_C, BISULFITE_DATA[set][replicate][index].coverage, (double)BISULFITE_DATA[set][replicate][index].methylated_C / BISULFITE_DATA[set][replicate][index].coverage);//debugging
				global_methylation[set][replicate] += line.methylated_C;
				global_coverage[set][replicate] += line.coverage;
				passed_coverage++;
//				printf("%s -> methylated_C = %zu, coverage = %zu\n\t-> methylated_C = %zu	coverage = %zu\n", bs_line, line.methylated_C, line.coverage, global_methylated_C_array[set][replicate], global_coverage_array[set][replicate]);
				index++;
			}
			fclose(BISULFITE_DATA_file);
			free(bs_line); bs_line = NULL;
			if (index == 0) {
				printf("\nWARNING\n\nno data points were added to BISULFITE_DATA[%u][%u]\n\n",set, replicate);
			} else if (DEBUG == true) {
				printf("last written data point was BISULFITE_DATA[%u][%u][%zu]\n",set, replicate, index);
			}
			if (two_strands == true) {
				fprintf(defiant_run_info,"%s: %u nucleotide pairs failed coverage, and %u nucleotide pairs passed coverage = %.1f%% passing minimum coverage.\n",files,failed_coverage,passed_coverage,(double)100*passed_coverage/(failed_coverage+passed_coverage));
			} else {
				fprintf(defiant_run_info,"%s: %u nucleotides failed coverage, and %u nucleotides passed coverage = %.1f%% passing minimum coverage.\n",files,failed_coverage,passed_coverage,(double)100*passed_coverage/(failed_coverage+passed_coverage));
			}
			fprintf(defiant_run_info,"Global methylation percent = %.1f; %zu CpN, sum(5mC) = %zu, sum(coverage) = %zu\n",100.0*global_methylation[set][replicate] / global_coverage[set][replicate], index - 1, global_methylation[set][replicate], global_coverage[set][replicate]);
			number_of_data_chromosomes = bs_data_chromosome_changes_chromosome_loop;
//
			bs_data_chromosome_changes_RAM_size += sizeof(CHROMOSOME_CHANGES_STRUCT);
			bs_data_chromosome_changes = realloc(bs_data_chromosome_changes, bs_data_chromosome_changes_RAM_size);
			if (bs_data_chromosome_changes == NULL) {
				printf("@line %u	realloc of bs_data_chromosome_changes failed after file is read.\n", __LINE__);
				exit(EXIT_FAILURE);
			}
			bs_data_chromosome_changes_set_RAM_size += sizeof(CHROMOSOME_CHANGES_STRUCT);
			bs_data_chromosome_changes[set] = realloc(bs_data_chromosome_changes[set], bs_data_chromosome_changes_set_RAM_size);
			if (bs_data_chromosome_changes[set] == NULL) {
				printf("@line %u	realloc of bs_data_chromosome_changes[%u] failed after file is read.\n", __LINE__, set);
				exit(EXIT_FAILURE);
			}
			bs_data_chromosome_changes_replicate_RAM_size += sizeof(CHROMOSOME_CHANGES_STRUCT);
			bs_data_chromosome_changes[set][replicate] = realloc(bs_data_chromosome_changes[set][replicate], bs_data_chromosome_changes_replicate_RAM_size);
			if (bs_data_chromosome_changes[set][replicate] == NULL) {
				printf("@line %u	realloc of bs_data_chromosome_changes[%u][%u] failed after file is read.\n", __LINE__, set, replicate);
				exit(EXIT_FAILURE);
			}
			bs_data_chromosome_changes[set][replicate][bs_data_chromosome_changes_chromosome_loop].index = index;
			safe_string_copy(bs_data_chromosome_changes[set][replicate][bs_data_chromosome_changes_chromosome_loop].chromosome, "END");
			replicate++;
			printf("there were %u chromosomes detected in set %u replicate %u\n", number_of_data_chromosomes, set + 1, replicate);
//ABSOLUTELY **NOTHING** MORE IN THIS LOOP AFTER THE FOLLOWING COMMAND
			files = strtok_r(NULL,",",&files_pointer);
		}
	}
//print global methylation comparisons
	for (unsigned short int set1 = 0; set1 < SETS; set1++) {//global_methylation may have > 2 sets, so I must do a 2x2 comparison
		for (unsigned short int set2 = 1; set2 < SETS; set2++) {
			if (set2 <= set1) {
				continue;
	 		}
	 		double dummy = 7.0;//holder
	 		DMR_struct **restrict global = malloc((number_of_replicates_per_set[set2] + number_of_replicates_per_set[set1]) * sizeof(DMR_struct) + sizeof(char));
	 		global[0] = malloc(number_of_replicates_per_set[set1] * sizeof(DMR_struct));
	 		global[1] = malloc(number_of_replicates_per_set[set2] * sizeof(DMR_struct));
	 		const unsigned short int COMPARED_SETS[] = {set1,set2};//for references to global variables
			for (unsigned short int set = 0; set < 2; set++) {
				for (unsigned int replicate = 0; replicate < number_of_replicates_per_set[COMPARED_SETS[set]]; replicate++) {
					global[set][replicate].methylated_C = global_methylation[COMPARED_SETS[set]][replicate];
					global[set][replicate].coverage     = global_coverage[COMPARED_SETS[set]][replicate];
				}
			}
			const unsigned short int NUMBER_OF_REPLICATES_COMPARED[] = {number_of_replicates_per_set[COMPARED_SETS[0]], number_of_replicates_per_set[COMPARED_SETS[1]]};
	 		fprintf(defiant_run_info,"\nSet %u vs set %u global methylation:\tp-value = %g\t",set1+1,set2+1,Pvalue(global, NUMBER_OF_REPLICATES_COMPARED, dummy, &dummy, &dummy, true));
	 		fprintf(defiant_run_info,"Percent Change = %g%%\n\n", 100.0*mean_percent_difference(global, NUMBER_OF_REPLICATES_COMPARED));
			free(global[0]); global[0] = NULL;
			free(global[1]); global[1] = NULL;
			free(global); global = NULL;
	 	}
		free(global_methylation[set1]); global_methylation[set1] = NULL;
		free(global_coverage[set1]);	global_coverage[set1] = NULL;
	}
	free(global_coverage); global_coverage = NULL;
	free(global_methylation); global_methylation = NULL;
	fprintf(defiant_run_info,"There will be %u runs split among %u workers.\n", RUNS, options.CPU);
	fclose(defiant_run_info);
	printf("Details of the data have been written to %s.\n",defiant_run_info_filename);
	free(defiant_run_info_filename); defiant_run_info_filename = NULL;
	printf("There will be %u runs split among %u workers.\n", RUNS, options.CPU);
//---------------------------------------------------------------------------------------------
//Analysis (heart of program)
//---------------------------------------------------------------------------------------------
	puts("\n------\nBeginning analysis.\n");
	for (unsigned short int set1 = 0; set1 < SETS; set1++) {
		for (unsigned short int set2 = 1; set2 < SETS; set2++) {
			if (set2 <= set1) {
				continue;
	 		}
	 		char *restrict label_set1 = malloc(16*sizeof(char)), *restrict label_set2 = malloc(16*sizeof(char));
	 		if (label_set1 == NULL) {
	 			printf("Failed to malloc at %s line %u\n", __FILE__, __LINE__);
	 			perror("");
	 			exit(EXIT_FAILURE);
	 		}
	 		if (label_set2 == NULL) {
	 			printf("Failed to malloc at %s line %u\n", __FILE__, __LINE__);
	 			perror("");
	 			exit(EXIT_FAILURE);
	 		}
	 		if (number_of_labels >= (set1+1)) {//does this set have a label?
	 			label_set1 = realloc(label_set1, sizeof(labels[set1]));
	 			if (label_set1 == NULL) {
	 				printf("realloc failed at %s line %u\n", __FILE__, __LINE__);
	 				exit(EXIT_FAILURE);
	 			}
	 			safe_string_copy(label_set1, labels[set1]);
	 		} else {
	 			sprintf(label_set1, "set%u", set1+1);
	 		}
	 		if (number_of_labels >= (set2+1)) {//does this set have a label?
	 			label_set2 = realloc(label_set2, sizeof(labels[set2]));
	 			if (label_set2 == NULL) {
	 				printf("realloc failed at %s line %u\n", __FILE__, __LINE__);
	 				exit(EXIT_FAILURE);
	 			}
	 			safe_string_copy(label_set2, labels[set2]);
	 		} else {
	 			sprintf(label_set2, "set%u", set2+1);
	 		}
	 		if (DEBUG == true) {
	 			printf("Now comparing set %u (%s) against set %u (%s) @line %u\n", set1, label_set1, set2, label_set2, __LINE__);
	 		}
	 		const unsigned short int COMPARED_SETS[] = {set1,set2};//for references to global variables
			const unsigned short int NUMBER_OF_REPLICATES_COMPARED[] = {number_of_replicates_per_set[set1], number_of_replicates_per_set[set2]}; 
			const unsigned short int TOTAL_REPLICATES = NUMBER_OF_REPLICATES_COMPARED[0] + NUMBER_OF_REPLICATES_COMPARED[1];
			for (unsigned int run = 0; run < RUNS; run++) {//for each cutoff group
//-o option specifies that Defiant won't overwrite files if the answers file present, so I need to create the answer filename first, though this may slow Defiant down with calls to access
//-------------------------------------------------
//open answers file and write header
//-------------------------------------------------
//alter label
				if (DEBUG == true) {
					printf("now at run %u/%u at %s line %u.\n", run, RUNS, __FILE__, __LINE__);
				}
				char options_string[96];
				sprintf(options_string,"c%u_CpN%u_d%u",cutoff[run].coverage, cutoff[run].CpN, cutoff[run].d);
				if (options.allowed_nucleotide_gap_between_CpN != 20000) {
					sprintf(options_string,"%s_G%u", options_string, options.allowed_nucleotide_gap_between_CpN);
				}
				sprintf(options_string,"%s_p%.2f_P%.0f",options_string, cutoff[run].p, cutoff[run].percent * 100.0);
				if ((cutoff[run].skip > 0) && (cutoff[run].skip != UINT_MAX)) {
					sprintf(options_string, "%s_S%u", options_string, cutoff[run].skip);
				} else if (cutoff[run].skip == UINT_MAX) {
					strcat(options_string, "_S∞");
				}
				unsigned int answers_filename_size = (strlen(options_string) + strlen("_vs_.tsv"))*sizeof(char) + sizeof(char*);
				if (label_set1 != NULL) {
					answers_filename_size += strlen(label_set1)*sizeof(char);
				}
				if (label_set2 != NULL) {
					answers_filename_size += strlen(label_set2)*sizeof(char);
				}
				if (total_label != NULL) {
					answers_filename_size += strlen(total_label)*sizeof(char);
				}
				char *restrict answers_filename = malloc(answers_filename_size);
				if (answers_filename == NULL) {
					printf("failed to malloc at %s line %u.\n", __FILE__, __LINE__);
					perror("");
					exit(EXIT_FAILURE);
				}
				sprintf(answers_filename,"%s_vs_%s_",label_set1, label_set2);
				if (total_label != NULL) {
					strcat(answers_filename, total_label);
					strcat(answers_filename,"_");
				}
				strcat(answers_filename, options_string);
				strcat(answers_filename,".tsv");
				if ((options.overwrite_output == false) && (file_exists(answers_filename) == true)) {
					printf("Answers file %s already exists, so Defiant is skipping this iteration.\n", answers_filename);
					free(answers_filename); answers_filename = NULL;
					continue;
				}
				if (DEBUG == true) {
					printf("now at run %u/%u at %s line %u.\n", run, RUNS, __FILE__, __LINE__);
				}
//----make answers file-----------------
				FILE *restrict rscript = NULL;
				char rscript_filename[48];
				if (options.make_figures == true) {
					sprintf(rscript_filename, "DMR_figures/defiant_%u.R", run);
					rscript = fopen(rscript_filename,"w");
					if (rscript == NULL) {
						perror("failed to write defiant.R.\n");
						exit(EXIT_FAILURE);
					}
					fprintf(rscript, "legend_space <- -0.26\n");
					fprintf(rscript, "right <- 10.5\n");
					fprintf(rscript, "bottom <- 0\n");
					fprintf(rscript, "left <- 5\n");
					fprintf(rscript, "top <- 0\ncex_main = 1\n");
				}
				FILE *restrict answers;
				answers = fopen(answers_filename,"w");
				if (answers == NULL) {
					printf("\nfailed to write %s\n", answers_filename);
					perror("Failed to open file.\n");
					free(answers_filename); answers_filename = NULL;
					exit(EXIT_FAILURE);
				}
				fprintf(answers,"Chromosome\tStart\tEnd\t#mCpN\t#Diff.CpN");//despite all options, this will be in the header
				fprintf(answers,"\tMean_Difference\t%s\t%s",label_set1, label_set2);//answers file header
/*				if (options.pvalue_scaling == true) {//the successive rolls in dice example
					fprintf(answers,"\tq(DMR)");//answers file header
				}*/
				if (cutoff[run].skip > 0) {
					fprintf(answers,"\tTotal_Skips");
				}
				if (gene_annotation_defined == true) {//part of the answer file header
					fprintf(answers,"\tInside_Genes\tBetween_Genes\tGene_Promoter_Cutoff_%u_Nucleotides", promoter_cutoff);
				}
				if (options.printing_CpN_list == true) {//part of the answer file header
					fprintf(answers,"\tDiff.CpN.list");
				}
/*				if (options.isolation == true) {//part of the answer file header
					fprintf(answers,"\tNearest.CpN.Distances");
				}*/
				fprintf(answers,"\n");//part of the answer file header
				unsigned int min_gene_search_index = 0, max_gene_search_index = 0, first_nucleotide = 0;
				double min_DEGREES_OF_FREEDOM = 0.0, min_WELCH_T_STATISTIC = 0.0;
				if (cutoff[run].p == 0.01) {
					min_DEGREES_OF_FREEDOM = 3.999998681169771; min_WELCH_T_STATISTIC = 4.604000000000035;
				} else if (cutoff[run].p == 0.05) {
					min_DEGREES_OF_FREEDOM = 3.999999999592020; min_WELCH_T_STATISTIC = 2.776460000000001;
				}
				size_t methylation_up_gene_list_size = sizeof(char);
				size_t methylation_down_gene_list_size = sizeof(char);
				size_t gene_list_size = sizeof(char);
				char **restrict methylation_up_gene_list = NULL;
				char **restrict methylation_down_gene_list = NULL;
				char **restrict gene_list = NULL;
				if (gene_annotation_defined == true) {
					methylation_up_gene_list = malloc(sizeof(char));
					methylation_down_gene_list = malloc(sizeof(char));
					gene_list = malloc(sizeof(char));
				}
				unsigned int number_of_methylation_up_list_genes = 0, number_of_methylation_down_list_genes = 0;
				unsigned int number_of_list_genes = 0;
				unsigned int MIN_COVERAGE = cutoff[run].skip > 0 ? 0 : cutoff[run].coverage;
/*				if (options.isolation == true) {
					MIN_COVERAGE = 0;
				} else */
				if (options.print_all_nucleotides == true) {
					MIN_COVERAGE = 0;
				}
				FILE *restrict fh_print_all_nucleotides = NULL, *restrict bedfile_fh = NULL;
				if (options.print_all_nucleotides == true) {//printing to each individual nucleotide information
					unsigned short int FILENAME_SIZE = strlen("nucleotide_.tsv")*2*sizeof(char) + sizeof(char*);
					
					if (label_set1 != NULL) {
						FILENAME_SIZE += strlen(label_set1)*sizeof(char);
					}
					if (label_set2 != NULL) {
						FILENAME_SIZE += strlen(label_set2)*sizeof(char);
					}
					if (total_label != NULL) {
						FILENAME_SIZE += strlen(total_label)*sizeof(char);
					}
					char *restrict each_nucleotide_filename = malloc(FILENAME_SIZE);
					if (each_nucleotide_filename == NULL) {
						printf("Failed to malloc at %s line %u\n", __FILE__, __LINE__);
						perror("");
						exit(EXIT_FAILURE);
					}
					if (total_label != NULL) {
						sprintf(each_nucleotide_filename,"nucleotide_%s_%s_%s.tsv",label_set1, label_set2, total_label);
					} else {
						sprintf(each_nucleotide_filename,"nucleotide_%s_%s.tsv",label_set1, label_set2);
					}
					fh_print_all_nucleotides = fopen(each_nucleotide_filename, "w");
					if (fh_print_all_nucleotides == NULL) {
						printf("\nfailed to write %s\n\n", each_nucleotide_filename);
						perror("");
						free(answers_filename); answers_filename = NULL;
						exit(EXIT_FAILURE);
					}
					if (options.fdr_on_all_cpn == false) {
						fprintf(fh_print_all_nucleotides,"Chr\tNucleotide\t%%Difference\tp\t%s\t%s\tmC_count\tSimilar.Nucleotides\tSkipped.Nucleotides\tRunning.%%Diff\tRunning.p\t\n",label_set1, label_set2);
					} else {
						fprintf(fh_print_all_nucleotides,"Chr\tNucleotide\t%%Difference\tp\tq (%s)\t%s\t%s\tmC_count\tSimilar.Nucleotides\tSkipped.Nucleotides\tRunning.%%Diff\tRunning.p\n", FDR_type, label_set1, label_set2);
					}
					printf("\nNow writing %s\n\n",each_nucleotide_filename);
					free(each_nucleotide_filename); each_nucleotide_filename = NULL;
				}
				char *restrict bedfile_filename = NULL;
				if (options.make_bed_files == true) {
					bedfile_filename = malloc(sizeof(char*) + sizeof(char)* (strlen("_.bed")+strlen(label_set1)+strlen(label_set2)));
					sprintf(bedfile_filename, "%s_%s.bed",label_set1, label_set2);
					bedfile_fh = fopen(bedfile_filename, "w");
					if (bedfile_fh == NULL) {
						perror("\nFailed to open bedfile\n");
						printf("Failed to open %s\n", bedfile_filename);
						free(answers_filename); answers_filename = NULL;
						free(bedfile_filename); bedfile_filename = NULL;
						exit(EXIT_FAILURE);
					}
				}
//-------------------------------------------------
//finished opening answers file and writing header
//-------------------------------------------------
//		may need an array of p-values to determine the q-value ahead of time, if fdr == true
//-------------------------------------------------
//-------------------------------------------------
				double *restrict pvalues = NULL;//only used if fdr option is set to 'true'
				double *restrict qvalues = NULL;//only used if fdr option is set to 'true'
				size_t pvalue_index = 0;
				if (options.fdr_on_all_cpn == true) {//get an array of p-values for FDR computation
					for (unsigned short int chromosome = 0; chromosome < number_of_data_chromosomes; chromosome++) {//this is done for each comparison
						if (DEBUG == true) {
							printf("chromosome = %u @ line %u\n", chromosome, __LINE__);
						}
						printf("Gathering p-values for p-value adjustment/FDR for chromosome %s...\n", bs_data_chromosome_changes[set1][0][chromosome].chromosome);
						DMR_struct **restrict single_nucleotide = malloc(TOTAL_REPLICATES * sizeof(DMR_struct));
						size_t **restrict bisulfite_nucleotide_min = malloc((TOTAL_REPLICATES) * sizeof(size_t));
						size_t **restrict bisulfite_nucleotide_max = malloc((TOTAL_REPLICATES) * sizeof(size_t));
						for (unsigned short int set = 0; set < 2; set++) {
							single_nucleotide[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set] * sizeof(DMR_struct));
							bisulfite_nucleotide_min[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set]*sizeof(size_t));
							if (bisulfite_nucleotide_min[set] == NULL) {
								printf("@line %u, malloc of bisulfite_nucleotide_min[%u] failed.\n",__LINE__, set);
								perror("");
								exit(EXIT_FAILURE);
							}
							bisulfite_nucleotide_max[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set] * sizeof(size_t));
							if (bisulfite_nucleotide_max[set] == NULL) {
								printf("@line %u, malloc of bisulfite_nucleotide_max[%u] failed.\n",__LINE__, set);
								perror("");
								exit(EXIT_FAILURE);
							}
						}
						
//now get the minimum index in BISULFITE_DATA where the chromosome matches, as Bismark does not sort by chromosome
						unsigned int chromosome_present = 0;
						for (unsigned short int set = 0; set < 2; set++) {
							for (unsigned short int r = 0; r < NUMBER_OF_REPLICATES_COMPARED[set]; r++) {
		//						printf("@line %u, set %u, replicate %u\n", __LINE__, set, r);
								for (unsigned int chr_loop = 0; chr_loop < number_of_data_chromosomes; chr_loop++) {//loop through bs_data_chromosome_changes
		//							printf("chromosome = %u\tset = %u\treplicate=%u\tchr_loop = %u\tchr%s ?= chr%s\n",chromosome,set,r,chr_loop,bs_data_chromosome_changes[set1][0][chromosome].chromosome,bs_data_chromosome_changes[set][r][chr_loop].chromosome);//debugging
									if (strcmp(bs_data_chromosome_changes[set1][0][chromosome].chromosome,bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].chromosome) == 0) {
										if (bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].index > bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop+1].index) {
											printf("somehow this chromosome ends before it starts.\n");
											exit(EXIT_FAILURE);
										}
		//								printf("@line %u	chr_loop = %u	bisulfite_nucleotide_min[%u][%u] = %u\n", __LINE__, chr_loop, set, r, bisulfite_nucleotide_min[set][r]);
										bisulfite_nucleotide_min[set][r] = bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].index;
										bisulfite_nucleotide_max[set][r] = bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop+1].index;
		//								printf("@line %u	bisulfite_nucleotide_max[%u][%u] = %u\n", __LINE__, set, r, bisulfite_nucleotide_max[set][r]);
										if (bisulfite_nucleotide_max[set][r] < bisulfite_nucleotide_min[set][r]) {//if the minimum > maximum, kill the program.  I have no idea why it sometimes does this
											printf("chromosome %s max < min: %zu < %zu\n",bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].chromosome, bisulfite_nucleotide_max[set][r], bisulfite_nucleotide_min[set][r]);
											free(pvalues); pvalues = NULL;
											free(qvalues); qvalues = NULL;
											free(answers_filename); answers_filename = NULL;
											free(bedfile_filename); bedfile_filename = NULL;
											exit(EXIT_FAILURE);
										}
										if (DEBUG == true) {
											printf("@line %u => minimum nucleotide (index %zu) for set %u-replicate %u is %u @ chromosome_loop %u = %s\n",__LINE__,bisulfite_nucleotide_min[set][r],set,r,BISULFITE_DATA[COMPARED_SETS[set]][r][bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].index].nucleotide, chr_loop, bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].chromosome);
										}
										chromosome_present++;
										break;
									}
								}
							}
						}
						if (chromosome_present < TOTAL_REPLICATES) {//I put this here because of Ayma's data, which had 0 coverage in an entire chromosome
							printf("Data is too sparse to consider chromosome %s, continuing to next chromosome.\n",bs_data_chromosome_changes[set1][0][chromosome].chromosome);
							continue;
						}
						zero_DMR_struct(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);//Initialize to 0
						while (true) {//always true, to keep it looping
							bool breaker = false;
							zero_DMR_struct(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);//Initialize to 0
							unsigned int nucleotide = UINT_MAX;//as big as I can get it
//go through all sets to get the minimum nucleotide
							for (unsigned short int set = 0; set < 2; set++) {//get the new minimum nucleotide 
								for (unsigned short int r = 0; r < NUMBER_OF_REPLICATES_COMPARED[set]; r++) {	//							 	printf("line%u-> index for BISULFITE_DATA bisulfite_nucleotide_min[%u][%u] = %u	bisulfite_nucleotide_max = %u\n",__LINE__, COMPARED_SETS[set], r, bisulfite_nucleotide_min[set][r], bisulfite_nucleotide_max[set][r]);
									if (bisulfite_nucleotide_min[set][r] >= bisulfite_nucleotide_max[set][r]) {
										breaker = true;
										break;//prevent segmentation faults
									}
//							 	printf("line%u-> nucleotide from above: %u\n",__LINE__,BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide);
//							 	printf("@line %u bisulfite_nucleotide_max[%u][%u] index = \n",__LINE__,set,r);
//								printf("@line %u BISULFITE_DATA[%u][%u][%zu].nucleotide = %u\n",__LINE__,COMPARED_SETS[set],r,bisulfite_nucleotide_min[set][r],BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide);
									if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide < nucleotide) {
										nucleotide = BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide;
									}
								}
							}
//							printf("nucleotide is %u\n", nucleotide);
							if (breaker == true) {//end this chromosome
								break;
							}
							unsigned short int replicates_meeting_minimum_coverage = 0;
				 			for (unsigned short int set = 0; set < 2; set++) {//how many organisms have this nucleotide?
								for (unsigned short int r = 0; r < NUMBER_OF_REPLICATES_COMPARED[set]; r++) {
									if (nucleotide < BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide) {
										continue;//I haven't yet reached this nucleotide, continue to next individual
									}
									if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide == nucleotide) {
										if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage >= MIN_COVERAGE) {
	/*										if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].methylated_C > BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage) {
												printf("@line %u nucleotide %u has methylated_C %u > coverage %u\n", __LINE__, nucleotide, BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].methylated_C, BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage);
												exit(EXIT_FAILURE);
											}*/
											single_nucleotide[set][r].methylated_C = BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].methylated_C;
											single_nucleotide[set][r].coverage     = BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage;
											if (single_nucleotide[set][r].coverage >= cutoff[run].coverage) {
												replicates_meeting_minimum_coverage++;
											}
										}
									}
									bisulfite_nucleotide_min[set][r]++;
								}
							}
//							if (replicates_meeting_minimum_coverage == TOTAL_REPLICATES) {
								const double PVALUE = Pvalue(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true);
								pvalues = add_double(pvalues, PVALUE, pvalue_index);
//printf("@ line %u, pvalue_index = %u for nucleotide %u and p = %g\n", __LINE__, pvalue_index, nucleotide, PVALUE);
								pvalue_index++;
	//						}
						}
						for (unsigned short int set = 0; set < 2; set++) {//there are only 2 sets compared at a time
							free(bisulfite_nucleotide_min[set]); bisulfite_nucleotide_min[set] = NULL;
							free(bisulfite_nucleotide_max[set]); bisulfite_nucleotide_max[set] = NULL;
							free(single_nucleotide[set]); single_nucleotide[set] = NULL;
						}						
						free(single_nucleotide); single_nucleotide = NULL;
						free(bisulfite_nucleotide_min); bisulfite_nucleotide_min = NULL;
						free(bisulfite_nucleotide_max); bisulfite_nucleotide_max = NULL;
					}//end of each chromosome
					if (options.fdr_on_all_cpn == true) {
						qvalues = p_adjust(pvalues, pvalue_index, FDR_type);
					}
					pvalue_index++;
					puts("finished p-value collection.\n");
				}//end of FDR 
//-------------------------------------------------
// Finished getting q-values
//-------------------------------------------------
				size_t nucleotides_good_in_every_organism = 0, total_nucleotides = 0;
				if (DEBUG == true) {
					printf("@ %s line %u, there are %u chromosomes\n", __FILE__, __LINE__, number_of_data_chromosomes);
				}
				if (number_of_data_chromosomes == 0) {
					puts("there are 0 chromosomes.\n");
					free(answers_filename); answers_filename = NULL;
					free(bedfile_filename); bedfile_filename = NULL;
					exit(EXIT_FAILURE);
				}
				DMR_struct ***restrict all_DMRs = NULL;
				unsigned int *restrict DMR_chromosome_indices = NULL;//only used if DMR FDR is 'true'
				unsigned int *restrict DMR_starts = NULL;
				unsigned int *restrict DMR_ends   = NULL;
				unsigned int *restrict nCpN       = NULL;
				unsigned int *restrict diffCpN    = NULL;
				unsigned int *restrict CpN_skips_in_this_DMR_all = NULL;
				if (options.print_DMR_pvalue == true) {
					if (DEBUG == true) {printf("at %s line %u\n", __FILE__, __LINE__);}
					all_DMRs = malloc_nucleotides(all_DMRs, NUMBER_OF_REPLICATES_COMPARED);
					if (DEBUG == true) {printf("at %s line %u\n", __FILE__, __LINE__);}
				}
				for (unsigned short int chromosome = 0; chromosome < number_of_data_chromosomes; chromosome++) {//this is done for each comparison
					if (options.CPU == 1) {
						printf("Now analyzing chromosome %s, at iteration loop %u/%u\n",bs_data_chromosome_changes[set1][0][chromosome].chromosome, chromosome+1, number_of_data_chromosomes);
					}
					DMR_struct **restrict DMR_sum           = malloc(TOTAL_REPLICATES * sizeof(DMR_struct));
					DMR_struct **restrict single_nucleotide = malloc(TOTAL_REPLICATES * sizeof(DMR_struct));
					DMR_struct ***restrict all_nucleotides  = NULL;
					if (options.make_figures == true) {
						if (DEBUG == true) {printf("at %s line %u\n", __FILE__, __LINE__);}
						all_nucleotides = malloc_nucleotides(all_nucleotides, NUMBER_OF_REPLICATES_COMPARED);
						if (DEBUG == true) {printf("at %s line %u\n", __FILE__, __LINE__);}
					}
					DMR_struct **restrict DMR_similar_sum = malloc(TOTAL_REPLICATES * sizeof(DMR_struct));
					size_t **restrict bisulfite_nucleotide_min = malloc((TOTAL_REPLICATES)*sizeof(size_t));
					size_t **restrict bisulfite_nucleotide_max = malloc((TOTAL_REPLICATES)*sizeof(size_t));
					for (unsigned short int set = 0; set < 2; set++) {
						DMR_sum[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set] * sizeof(DMR_struct));
						single_nucleotide[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set] * sizeof(DMR_struct));
						DMR_similar_sum[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set] * sizeof(DMR_struct));
						bisulfite_nucleotide_min[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set]*sizeof(size_t));
						if (bisulfite_nucleotide_min[set] == NULL) {
							printf("@line %u, malloc of bisulfite_nucleotide_min[%u] failed.\n",__LINE__, set);
							perror("");
							free(answers_filename); answers_filename = NULL;
							free(bedfile_filename); bedfile_filename = NULL;
							exit(EXIT_FAILURE);
						}
						bisulfite_nucleotide_max[set] = malloc(NUMBER_OF_REPLICATES_COMPARED[set]*sizeof(size_t));
						if (bisulfite_nucleotide_max[set] == NULL) {
							printf("@line %u, malloc of bisulfite_nucleotide_max[%u] failed.\n",__LINE__, set);
							perror("");
							free(answers_filename); answers_filename = NULL;
							free(bedfile_filename); bedfile_filename = NULL;
							exit(EXIT_FAILURE);
						}
					}
//now get the minimum index in BISULFITE_DATA where the chromosome matches, as Bismark does not sort by chromosome
					unsigned short int chromosome_present = 0;
					for (unsigned short int set = 0; set < 2; set++) {
						for (unsigned short int r = 0; r < NUMBER_OF_REPLICATES_COMPARED[set]; r++) {
	//						printf("@line %u, set %u, replicate %u\n", __LINE__, set, r);
							for (unsigned int chr_loop = 0; chr_loop < number_of_data_chromosomes; chr_loop++) {//loop through bs_data_chromosome_changes
	//							printf("chromosome = %u\tset = %u\treplicate=%u\tchr_loop = %u\tchr%s ?= chr%s\n",chromosome,set,r,chr_loop,bs_data_chromosome_changes[set1][0][chromosome].chromosome,bs_data_chromosome_changes[set][r][chr_loop].chromosome);//debugging
								if (strcmp(bs_data_chromosome_changes[set1][0][chromosome].chromosome,bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].chromosome) == 0) {
									if (bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].index > bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop+1].index) {
										printf("somehow this chromosome ends before it starts.\n");
										exit(EXIT_FAILURE);
									}
	//								printf("@line %u	chr_loop = %u	bisulfite_nucleotide_min[%u][%u] = %u\n", __LINE__, chr_loop, set, r, bisulfite_nucleotide_min[set][r]);
									bisulfite_nucleotide_min[set][r] = bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].index;
									bisulfite_nucleotide_max[set][r] = bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop+1].index;
	//								printf("@line %u	bisulfite_nucleotide_max[%u][%u] = %u\n", __LINE__, set, r, bisulfite_nucleotide_max[set][r]);
									if (bisulfite_nucleotide_max[set][r] < bisulfite_nucleotide_min[set][r]) {//if the minimum > maximum, kill the program.  I have no idea why it sometimes does this
										printf("chromosome %s max < min: %zu < %zu\n",bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].chromosome, bisulfite_nucleotide_max[set][r], bisulfite_nucleotide_min[set][r]);
										free(answers_filename); answers_filename = NULL;
										free(bedfile_filename); bedfile_filename = NULL;
										exit(EXIT_FAILURE);
									}
									if (DEBUG == true) {
										printf("@line %u => minimum nucleotide (index %zu) for set %u-replicate %u is %u @ chromosome_loop %u = %s\n",__LINE__,bisulfite_nucleotide_min[set][r],set,r,BISULFITE_DATA[COMPARED_SETS[set]][r][bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].index].nucleotide, chr_loop, bs_data_chromosome_changes[COMPARED_SETS[set]][r][chr_loop].chromosome);
									}
									chromosome_present++;
									break;
								}
							}
						}
					}
					if (chromosome_present < TOTAL_REPLICATES) {//I put this here because of Ayma's data, which had 0 coverage in an entire chromosome
						printf("Data is too sparse to consider chromosome %s, continuing to next chromosome.\n",bs_data_chromosome_changes[set1][0][chromosome].chromosome);
						continue;
					}
	//				printf("Now analyzing chromosome%s\n",bs_data_chromosome_changes[set1][0][chromosome].chromosome);//DEBUGGING
	//ensure chromosome loop in GENES and BISULFITE_DATA matches
					unsigned short int chr = 0;
					if (DEBUG == true) {printf("@line %u\n", __LINE__);}
					if (gene_annotation_defined == true) {//find which indices of gene_chromosome_changes should be searched
		 				bool chromosome_annotation_found = false;
		 				for (unsigned int chr_loop = 0; chr_loop < number_of_chromosomes_in_GENES; chr_loop++) {
	//						printf("@line %u	comparing %s with %s\n",__LINE__, gene_chromosome_changes[chr_loop].chromosome,bs_data_chromosome_changes[set1][0][chromosome].chromosome);//DEBUGGING
							if (strcmp(gene_chromosome_changes[chr_loop].chromosome,bs_data_chromosome_changes[set1][0][chromosome].chromosome) == 0) {
								chr = chr_loop;
								chromosome_annotation_found = true;
								GENES_chromosome_change_index = chr;
	//							printf("@line %u	now analyzing chromosome %u, GENES chromosome = %s; BS_DATA[%u][0] = %s; BS_DATA[%u][0] = %s\n", __LINE__, chromosome, gene_chromosome_changes[chr].chromosome, set1, bs_data_chromosome_changes[set1][0][chromosome].chromosome, set2, bs_data_chromosome_changes[set2][0][chromosome].chromosome);
								min_gene_search_index = gene_chromosome_changes[chr_loop].index;//this is a globally referenced variable, to be accessed by identify_gene function
								if (chromosome < number_of_chromosomes_in_GENES) {
									max_gene_search_index = gene_chromosome_changes[GENES_chromosome_change_index + 1].index - 1;
									if (DEBUG == true){
										printf("@line %u, max_gene_search_index = %u\n", __LINE__, max_gene_search_index);
									}
								} else if (chromosome == number_of_chromosomes_in_GENES) {
									max_gene_search_index = number_of_annotated_genes-1;
									if (DEBUG == true) {
										printf("@line %u, max_gene_search_index = %u\n", __LINE__, max_gene_search_index);
									}
								}
								if (max_gene_search_index > number_of_annotated_genes) {
									max_gene_search_index = number_of_annotated_genes;
								}
								if (min_gene_search_index == max_gene_search_index) {
									printf("Somehow got min_gene_search_index = max_gene_search_index = %u\n", max_gene_search_index);
									free(answers_filename); answers_filename = NULL;
									free(bedfile_filename); bedfile_filename = NULL;
									exit(EXIT_FAILURE);
								}
								first_nucleotide = GENES[min_gene_search_index].gene_start;
								if (DEBUG == true) {
									printf("@ line %u, GENES_chromosome_change_index = %u -> searching %u-%u indices\n", __LINE__, GENES_chromosome_change_index, min_gene_search_index, max_gene_search_index);
									printf("@ line %u -> 1st nucleotide = %u; max nucleotide in chromosome = %u\n",__LINE__,first_nucleotide, GENES[max_gene_search_index].gene_end);
								}
								break;
							}
						}
						if (chromosome_annotation_found == false) {
							printf("Warning: chromosome %s has no annotation data.\n", bs_data_chromosome_changes[set1][0][chromosome].chromosome);
						}
					}
					if (DEBUG == true) {printf("@line %u\n", __LINE__);}
//following arrays are only for making figures
					unsigned int *restrict CpN_list = NULL,	*restrict all_CpN = NULL;
					double *restrict all_p = NULL,				*restrict all_percent = NULL;
					double *restrict all_sum_p = NULL,			*restrict all_sum_percent = NULL;
					double *restrict dice_p_values = NULL;//for the dice DMR
					unsigned int mC_start = 0, mC_end = 0;//, last_CpN_before_DMR = 0;
					unsigned int mC_count = 0,	similar_nucleotide_count = 0, good_nucleotide_count = 0, consecutive_skipped_CpN = 0, CpN_skips_in_this_DMR = 0;
					zero_DMR_struct(DMR_sum, NUMBER_OF_REPLICATES_COMPARED);//Initialize to 0
					zero_DMR_struct(DMR_similar_sum, NUMBER_OF_REPLICATES_COMPARED);//Initialize to 0
					zero_DMR_struct(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);//Initialize to 0
					while (true) {//always true, to keep it looping
						bool breaker = false;
						zero_DMR_struct(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);//Initialize to 0
						unsigned int nucleotide = UINT_MAX;//as big as I can get it
//go through all sets to get the minimum nucleotide
						for (unsigned short int set = 0; set < 2; set++) {//get the new minimum nucleotide 
							for (unsigned short int r = 0; r < NUMBER_OF_REPLICATES_COMPARED[set]; r++) {
	//						 	printf("line%u-> index for BISULFITE_DATA bisulfite_nucleotide_min[%u][%u] = %u	bisulfite_nucleotide_max = %u\n",__LINE__, COMPARED_SETS[set], r, bisulfite_nucleotide_min[set][r], bisulfite_nucleotide_max[set][r]);
								if (bisulfite_nucleotide_min[set][r] >= bisulfite_nucleotide_max[set][r]) {
									breaker = true;
									break;//prevent segmentation faults
								}
//							 	printf("line%u-> nucleotide from above: %u\n",__LINE__,BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide);
//							 	printf("@line %u bisulfite_nucleotide_max[%u][%u] index = \n",__LINE__,set,r);
//								printf("@line %u BISULFITE_DATA[%u][%u][%zu].nucleotide = %u\n",__LINE__,COMPARED_SETS[set],r,bisulfite_nucleotide_min[set][r],BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide);
								if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide < nucleotide) {
									nucleotide = BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide;
								}
							}
						}
						if (breaker == true) {//end this chromosome
							if (((mC_count - similar_nucleotide_count) >= cutoff[run].CpN) && (good_nucleotide_count >= cutoff[run].d)) {
								const int NO_COAT_TAILS = mC_count - similar_nucleotide_count;
								if ((NO_COAT_TAILS >= cutoff[run].CpN) && ((mC_end-mC_start) >= options.MINIMUM_CPN_RANGE) && (good_nucleotide_count >= cutoff[run].d)) {
									subtract_2nd_dmr_from_1st_dmr(DMR_sum, DMR_similar_sum, NUMBER_OF_REPLICATES_COMPARED, __LINE__);
									const double SUM_PERCENT_DIFFERENCE = mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED);
									if (fabs(SUM_PERCENT_DIFFERENCE) >= cutoff[run].percent) {
										if (options.make_bed_files == true) {
											fprintf(bedfile_fh,"chr%s	%u	%u\n",bs_data_chromosome_changes[set1][0][chromosome].chromosome,mC_start ,mC_end);
										}
										fprintf(answers,"%s	%u	%u\t%u	%u",bs_data_chromosome_changes[set1][0][chromosome].chromosome, mC_start , mC_end, NO_COAT_TAILS, good_nucleotide_count);
										fprintf(answers,"\t%.1f", 100.0*SUM_PERCENT_DIFFERENCE);
										if (options.print_DMR_pvalue == true) {
											if (DEBUG == true) {printf("@line %u\n", __LINE__);}
											all_DMRs = add_nucleotides(all_DMRs, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].number_of_DMRs, DMR_sum);
											DMR_chromosome_indices = add_uint(DMR_chromosome_indices, chromosome, cutoff[run].number_of_DMRs);
											DMR_starts             = add_uint(DMR_starts, mC_start, cutoff[run].number_of_DMRs);
											DMR_ends               = add_uint(DMR_ends, mC_end, cutoff[run].number_of_DMRs);
											nCpN                   = add_uint(nCpN, NO_COAT_TAILS, cutoff[run].number_of_DMRs);
											diffCpN                = add_uint(diffCpN, good_nucleotide_count, cutoff[run].number_of_DMRs);
											CpN_skips_in_this_DMR_all  = add_uint(CpN_skips_in_this_DMR_all, CpN_skips_in_this_DMR, cutoff[run].number_of_DMRs);
											if (DEBUG == true) {printf("@line %u\n", __LINE__);}
										}
/*										if (options.pvalue_scaling == true) {
											if (DEBUG == true) {printf("at %s line %u\n", __FILE__, __LINE__);}
											fprintf(answers, "\t%.3g", DMR_p(pvalues, pvalue_index, dice_p_values, mC_count-1));
											if (DEBUG == true) {printf("at %s line %u\n", __FILE__, __LINE__);}
										}*/
										print_methylation_percentages(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, answers);
										if (cutoff[run].skip > 0) {
											CpN_skips_in_this_DMR -= consecutive_skipped_CpN;
											fprintf(answers,"\t%u", CpN_skips_in_this_DMR);
										}
										char gene[48] = "n/a", intergene[48] = "n/a", list_gene[48] = "n/a";
										if (gene_annotation_defined == true) {
	//									printf("@ %s line %u list_gene = %s\n", __FILE__, __LINE__, list_gene);
											identify_gene(mC_start, mC_end, gene, intergene, list_gene, &min_gene_search_index, &max_gene_search_index, first_nucleotide);
											fprintf(answers,"\t%s\t%s\t%s", gene, intergene, list_gene);
											gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, gene, false, true);
											gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, intergene, false, true);
											gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, list_gene, false, true);
								   	//void *restrict add_name(char **restrict array, size_t *restrict size, unsigned int *restrict f_number_of_list_genes, const char *restrict NAME, const bool UNIQUE) 
											if (SUM_PERCENT_DIFFERENCE > 0) {
												methylation_up_gene_list = add_name(methylation_up_gene_list, &methylation_up_gene_list_size, &number_of_methylation_up_list_genes, list_gene, true, false);
											} else {
												methylation_down_gene_list = add_name(methylation_down_gene_list, &methylation_down_gene_list_size, &number_of_methylation_down_list_genes, list_gene, true, false);
											}
										}
										if (options.printing_CpN_list == true) {
											print_CpN_list(answers, CpN_list, good_nucleotide_count);
										}
//										if (options.isolation == true) {
//											fprintf(answers, "\t%u;%u", mC_start - last_CpN_before_DMR, get_next_CpN(mC_end, (const size_t **restrict)bisulfite_nucleotide_min, (const size_t **restrict)bisulfite_nucleotide_max, BISULFITE_DATA, NUMBER_OF_REPLICATES_COMPARED, COMPARED_SETS) - mC_end);
	//									}
										fprintf(answers,"\n");
										if (options.make_figures == true) {
											fprintf(rscript, "setEPS()\n");
											fprintf(rscript, "postscript('DMR_figures/%s_%s_c%u_CpN%u_d%u_p0_%02.0f_P%.0f_S%u_chr%s_%u_%u", label_set1, label_set2, cutoff[run].coverage, cutoff[run].CpN, cutoff[run].d, cutoff[run].p*100, 100.0*cutoff[run].percent, cutoff[run].skip, bs_data_chromosome_changes[set1][0][chromosome].chromosome, mC_start, mC_end);
											if (strcmp(list_gene,"n/a") != 0) {
												fprintf(rscript, "_%s", list_gene);
											}
											fprintf(rscript, ".eps')\n");
										
											R_figure(rscript, all_CpN, mC_count - similar_nucleotide_count, label_set1, label_set2, xaxis_label, list_gene, all_p, all_percent, all_sum_p, all_sum_percent, all_nucleotides, NUMBER_OF_REPLICATES_COMPARED, mC_start, mC_end);
											all_CpN = uint_clear(all_CpN);
											all_p = double_clear(all_p);
											all_percent = double_clear(all_percent);
											all_sum_p = double_clear(all_sum_p);
											all_sum_percent = double_clear(all_sum_percent);
											all_nucleotides = clear_nucleotides(all_nucleotides, NUMBER_OF_REPLICATES_COMPARED);
										}
/*										if (options.pvalue_scaling == true) {
											dice_p_values = double_clear(dice_p_values);
										}*/
										cutoff[run].number_of_DMRs++;
									}
								}
							}
							break;
						}
//						printf("@line %u, nucleotide = %u, distance = %u\n",__LINE__, nucleotide, nucleotide - mC_end);
//						printf("%u/%u-chr %s:%u@line %u\n",replicates_meeting_minimum_coverage, TOTAL_REPLICATES, gene_chromosome_changes[chr].chromosome, nucleotide,__LINE__);
						unsigned short int replicates_meeting_minimum_coverage = 0;
			 			for (unsigned short int set = 0; set < 2; set++) {//how many organisms have this nucleotide?
							for (unsigned short int r = 0; r < NUMBER_OF_REPLICATES_COMPARED[set]; r++) {
								if (nucleotide < BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide) {
									continue;//I haven't yet reached this nucleotide, continue to next individual
								}
								if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].nucleotide == nucleotide) {
									if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage >= MIN_COVERAGE) {
/*										if (BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].methylated_C > BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage) {
											printf("@line %u nucleotide %u has methylated_C %u > coverage %u\n", __LINE__, nucleotide, BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].methylated_C, BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage);
											exit(EXIT_FAILURE);
										}*/
										single_nucleotide[set][r].methylated_C = BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].methylated_C;
										single_nucleotide[set][r].coverage     = BISULFITE_DATA[COMPARED_SETS[set]][r][bisulfite_nucleotide_min[set][r]].coverage;
										if (single_nucleotide[set][r].coverage >= cutoff[run].coverage) {
											replicates_meeting_minimum_coverage++;
										}
									}
								}
								bisulfite_nucleotide_min[set][r]++;
							}
						}
						total_nucleotides++;
//--------------------------
//PRINTING ALL NUCLEOTIDES
//-------------------------
						if (options.print_all_nucleotides == true) {//printing to each individual nucleotide information, only the columns about this nucleotide, last columns printed later
	//						if (replicates_meeting_minimum_coverage == TOTAL_REPLICATES){//If I can print out p-value and percent change
							if (options.fdr_on_all_cpn == false) {
								fprintf(fh_print_all_nucleotides, "%s\t%u\t%.2f\t%.3g", bs_data_chromosome_changes[set1][0][chromosome].chromosome, nucleotide, 100.0*mean_percent_difference(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED), Pvalue(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true));
							} else {
								fprintf(fh_print_all_nucleotides, "%s\t%u\t%.2f\t%.3g\t%.3g", bs_data_chromosome_changes[set1][0][chromosome].chromosome, nucleotide, 100.0*mean_percent_difference(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED), pvalues[total_nucleotides-1], qvalues[total_nucleotides-1]);
							}
//							} else {//If I don't have enough info to calculate p-value & percent change
	//							fprintf(fh_print_all_nucleotides, "%s\t%u\tn/a\tn/a", bs_data_chromosome_changes[set1][0][chromosome].chromosome, nucleotide);
//							}
//							fprintf(fh_print_all_nucleotides, "\t%u/%u", replicates_meeting_minimum_coverage, TOTAL_REPLICATES);
							for (unsigned short int nset = 0; nset < 2; nset++) {
								if (single_nucleotide[nset][0].coverage > 0) {//nucleotide is present
									fprintf(fh_print_all_nucleotides, "\t%zu/%zu",  single_nucleotide[nset][0].methylated_C, single_nucleotide[nset][0].coverage);
								} else {//nucleotide isn't present
									fprintf(fh_print_all_nucleotides, "\tX");
								}
								for (unsigned short int r = 1; r < NUMBER_OF_REPLICATES_COMPARED[nset]; r++) {
									if (single_nucleotide[nset][r].coverage > 0) {//nucleotide is present
	/*									if (single_nucleotide[0][r].methylated_C > single_nucleotide[0][r].coverage) {
											printf("%zu > %zu\n", single_nucleotide[0][r].methylated_C, single_nucleotide[0][r].coverage);
											exit(EXIT_FAILURE);
										}*/
										fprintf(fh_print_all_nucleotides, ",%zu/%zu",  single_nucleotide[nset][r].methylated_C, single_nucleotide[nset][r].coverage);
									} else {//nucleotide isn't present
										fprintf(fh_print_all_nucleotides, ",X");
									}
								}
							}
//the following conditions will be in further code, but I'm printing here for debuggingoptions.MINIMUM_CPN_RANGE) && (good_nucleotide_count >= cutoff[run].d)) {
						}
//						printf("%u/%u-chr %s:%u@line %u\n",replicates_meeting_minimum_coverage, TOTAL_REPLICATES, bs_data_chromosome_changes[set1][0][chromosome].chromosome, nucleotide,__LINE__);
//printf("@line %u\n", __LINE__);	
						if (((mC_count > 0) && ((nucleotide - mC_end) > options.allowed_nucleotide_gap_between_CpN)) || (similar_nucleotide_count > options.MAX_SIMILAR_CPN) || ((consecutive_skipped_CpN >= cutoff[run].skip) && (replicates_meeting_minimum_coverage < TOTAL_REPLICATES))) {//if the gap is too big, or if this nucleotide doesn't have minimum coverage in every sample, don't use it
//	printf("@line %u\n", __LINE__);
							const int NO_COAT_TAILS = mC_count - similar_nucleotide_count - consecutive_skipped_CpN;
							if (options.print_all_nucleotides == true) {
								if (options.fdr_on_all_cpn == false) {
									fprintf(fh_print_all_nucleotides,"\t0\t%u\t%u\t%.2f\t%.3g\n", similar_nucleotide_count, consecutive_skipped_CpN, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), Pvalue(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true));
								} else {
									fprintf(fh_print_all_nucleotides,"\t0\t%u\t%u\t%.2f\t%.3g\t%.3g\n", similar_nucleotide_count, consecutive_skipped_CpN, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), pvalues[total_nucleotides-1], qvalues[total_nucleotides-1]);
								}
							}
							if ((NO_COAT_TAILS >= cutoff[run].CpN) && ((mC_end-mC_start) >= options.MINIMUM_CPN_RANGE) && (good_nucleotide_count >= cutoff[run].d)) {
								subtract_2nd_dmr_from_1st_dmr(DMR_sum, DMR_similar_sum, NUMBER_OF_REPLICATES_COMPARED, __LINE__);
								const double SUM_PERCENT_DIFFERENCE = mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED);
								if (fabs(SUM_PERCENT_DIFFERENCE) >= cutoff[run].percent) {
									if (options.make_bed_files == true) {
										fprintf(bedfile_fh,"chr%s	%u	%u\n",bs_data_chromosome_changes[set1][0][chromosome].chromosome,mC_start ,mC_end);
									}
									fprintf(answers,"%s	%u	%u\t%u	%u",bs_data_chromosome_changes[set1][0][chromosome].chromosome, mC_start , mC_end, NO_COAT_TAILS, good_nucleotide_count);
									fprintf(answers,"\t%.1f", 100.0*SUM_PERCENT_DIFFERENCE);
									if (options.print_DMR_pvalue == true) {
										all_DMRs = add_nucleotides(all_DMRs, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].number_of_DMRs, DMR_sum);
										DMR_chromosome_indices = add_uint(DMR_chromosome_indices, chromosome, cutoff[run].number_of_DMRs);
										DMR_starts             = add_uint(DMR_starts, mC_start, cutoff[run].number_of_DMRs);
										DMR_ends               = add_uint(DMR_ends, mC_end, cutoff[run].number_of_DMRs);
										nCpN                   = add_uint(nCpN, NO_COAT_TAILS, cutoff[run].number_of_DMRs);
										diffCpN               = add_uint(diffCpN, good_nucleotide_count, cutoff[run].number_of_DMRs);
										CpN_skips_in_this_DMR_all  = add_uint(CpN_skips_in_this_DMR_all, CpN_skips_in_this_DMR, cutoff[run].number_of_DMRs);
									}
/*									if (options.pvalue_scaling == true) {
										fprintf(answers, "\t%.3g", DMR_p(pvalues, pvalue_index, dice_p_values, mC_count-1));
									}*/
									print_methylation_percentages(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, answers);
									if (cutoff[run].skip > 0) {
										CpN_skips_in_this_DMR -= consecutive_skipped_CpN;
										fprintf(answers,"\t%u", CpN_skips_in_this_DMR);
									}
									char gene[48] = "n/a", intergene[48] = "n/a", list_gene[48] = "n/a";
									if (gene_annotation_defined == true) {
//									printf("@ %s line %u list_gene = %s\n", __FILE__, __LINE__, list_gene);
										identify_gene(mC_start, mC_end, gene, intergene, list_gene, &min_gene_search_index, &max_gene_search_index, first_nucleotide);
										fprintf(answers,"\t%s\t%s\t%s", gene, intergene, list_gene);
										gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, gene, false, true);
										gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, intergene, false, true);
										gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, list_gene, false, true);
										if (SUM_PERCENT_DIFFERENCE > 0) {
											methylation_up_gene_list = add_name(methylation_up_gene_list, &methylation_up_gene_list_size, &number_of_methylation_up_list_genes, list_gene, true, false);
										} else {
											methylation_down_gene_list = add_name(methylation_down_gene_list, &methylation_down_gene_list_size, &number_of_methylation_down_list_genes, list_gene, true, false);
										}
									}
									if (options.printing_CpN_list == true) {
										print_CpN_list(answers, CpN_list, good_nucleotide_count);
									}
/*									if (options.isolation == true) {
										fprintf(answers, "\t%u;%u", mC_start - last_CpN_before_DMR, get_next_CpN(mC_end, (const size_t **restrict)bisulfite_nucleotide_min, (const size_t **restrict)bisulfite_nucleotide_max, BISULFITE_DATA, NUMBER_OF_REPLICATES_COMPARED, COMPARED_SETS) - mC_end);
									}*/
									fprintf(answers,"\n");
									if (options.print_DMR_pvalue == true) {
										all_DMRs               = add_nucleotides(all_DMRs, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].number_of_DMRs, DMR_sum);
										DMR_chromosome_indices = add_uint(DMR_chromosome_indices, chromosome, cutoff[run].number_of_DMRs);
										DMR_starts             = add_uint(DMR_starts, mC_start, cutoff[run].number_of_DMRs);
										DMR_ends               = add_uint(DMR_ends, mC_end, cutoff[run].number_of_DMRs);
										nCpN                   = add_uint(nCpN, NO_COAT_TAILS, cutoff[run].number_of_DMRs);
										diffCpN                = add_uint(diffCpN, good_nucleotide_count, cutoff[run].number_of_DMRs);
										CpN_skips_in_this_DMR_all  = add_uint(CpN_skips_in_this_DMR_all, CpN_skips_in_this_DMR, cutoff[run].number_of_DMRs);
									}
									if (options.make_figures == true) {
										fprintf(rscript, "setEPS()\n");
										fprintf(rscript, "postscript('DMR_figures/%s_%s_c%u_CpN%u_d%u_p0_%02.0f_P%.0f_S%u_chr%s_%u_%u", label_set1, label_set2, cutoff[run].coverage, cutoff[run].CpN, cutoff[run].d, cutoff[run].p*100, 100.0*cutoff[run].percent, cutoff[run].skip, bs_data_chromosome_changes[set1][0][chromosome].chromosome, mC_start, mC_end);
										if (strcmp(list_gene,"n/a") != 0) {
											fprintf(rscript, "_%s", list_gene);
										}
										fprintf(rscript, ".eps')\n");
										
										R_figure(rscript, all_CpN, mC_count - similar_nucleotide_count, label_set1, label_set2, xaxis_label, list_gene, all_p, all_percent, all_sum_p, all_sum_percent, all_nucleotides, NUMBER_OF_REPLICATES_COMPARED, mC_start, mC_end);
										all_CpN = uint_clear(all_CpN);
										all_p = double_clear(all_p);
										all_percent = double_clear(all_percent);
										all_sum_p = double_clear(all_sum_p);
										all_sum_percent = double_clear(all_sum_percent);
										all_nucleotides = clear_nucleotides(all_nucleotides, NUMBER_OF_REPLICATES_COMPARED);
									}
/*									if (options.pvalue_scaling == true) {
										dice_p_values = double_clear(dice_p_values);
									}*/
									cutoff[run].number_of_DMRs++;
								}
							}
							zero_DMR_struct(DMR_sum, NUMBER_OF_REPLICATES_COMPARED);
							zero_DMR_struct(DMR_similar_sum, NUMBER_OF_REPLICATES_COMPARED);
//							last_CpN_before_DMR = nucleotide;
							mC_count = 0;
							similar_nucleotide_count = 0;
							good_nucleotide_count = 0;
							consecutive_skipped_CpN = 0;
							CpN_skips_in_this_DMR = 0;
							if (options.printing_CpN_list == true) {
								CpN_list = uint_clear(CpN_list);
							}
							continue;
						} else if ((mC_count > 0) && (consecutive_skipped_CpN < cutoff[run].skip) && (replicates_meeting_minimum_coverage < TOTAL_REPLICATES)) {
//if mC_count > 0, then I don't start on similar CpN
							add_2nd_dmr_to_1st_dmr(DMR_similar_sum, single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);
							add_2nd_dmr_to_1st_dmr(DMR_sum, single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);
							consecutive_skipped_CpN++;
							CpN_skips_in_this_DMR++;
							mC_count++;
							if (options.print_all_nucleotides == true) {
								if (options.fdr_on_all_cpn == false) {
									fprintf(fh_print_all_nucleotides,"\t%u\t%u\t%u\t%.2f\t%g\n", mC_count, similar_nucleotide_count, consecutive_skipped_CpN, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), Pvalue(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true));
								} else {
									fprintf(fh_print_all_nucleotides,"\t%u\t%u\t%u\t%.2f\t%.3g\t%.3g\n", mC_count, similar_nucleotide_count, consecutive_skipped_CpN, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), pvalues[total_nucleotides-1], qvalues[total_nucleotides-1]);
								}
							}
//maybe need to add p-value to all_p and dice_p_values here?
							continue;
						}
//						printf("\nchr%s:%u @ line %u\t",CHR,nucleotide,__LINE__);
//						puts("Single Nucleotide:");
						nucleotides_good_in_every_organism++;
	//					printf("@line %u, single_nucleotide: \n", __LINE__);
	//					print_DMR_struct(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);
	//					printf("@line %u, DMR_sum: \n", __LINE__);
//						print_DMR_struct(DMR_sum, NUMBER_OF_REPLICATES_COMPARED);
						add_2nd_dmr_to_1st_dmr(DMR_sum, single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);
						const double SINGLE_NUCLEOTIDE_MEAN_DIFFERENCE = mean_percent_difference(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);
						mC_count++;
/*						if (options.pvalue_scaling == true) {
							const double PVALUE = Pvalue(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true);
							dice_p_values = add_double(dice_p_values, PVALUE, mC_count - 1);
						}*/
						if (options.make_figures == true) {
							all_CpN = add_uint(all_CpN, nucleotide, mC_count - 1);
							double pvalue = Pvalue(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true);
//							if (pvalue < 0) {
	//							printf("@ %s line %u, p < 0\n", __FILE__, __LINE__);
		//					}
							all_p = add_double(all_p, pvalue, mC_count - 1);
							pvalue = Pvalue(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true);
//							if (pvalue < 0) {
//								printf("@ %s line %u, p < 0\n", __FILE__, __LINE__);
//							}
							all_percent = add_double(all_percent, 100.0*mean_percent_difference(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED), mC_count - 1);
							all_sum_p = add_double(all_sum_p, pvalue , mC_count - 1);
							all_sum_percent = add_double(all_sum_percent, 100.0*mean_percent_difference(DMR_sum, NUMBER_OF_REPLICATES_COMPARED), mC_count - 1);
							all_nucleotides = add_nucleotides(all_nucleotides, NUMBER_OF_REPLICATES_COMPARED, mC_count - 1, single_nucleotide);
						}
	//					printf("Mean Difference = %lf\n",MEAN_DIFFERENCE);
						if ((fabs(SINGLE_NUCLEOTIDE_MEAN_DIFFERENCE) < cutoff[run].percent) || ((options.fdr_on_all_cpn == false) && (Pvalue(single_nucleotide, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, false)) > cutoff[run].p) || ((options.fdr_on_all_cpn == true) && (qvalues[total_nucleotides-1] > cutoff[run].p))) {//i.e. this nucleotide is not differentially methylated
							if (options.print_all_nucleotides == true) {
								if (options.fdr_on_all_cpn == false) {
									fprintf(fh_print_all_nucleotides,"\t0\t%u\t%u\t%.2f\t%g\n", similar_nucleotide_count, consecutive_skipped_CpN, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), Pvalue(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true));
								} else {
									fprintf(fh_print_all_nucleotides,"\t0\t%u\t%u\t%.2f\t%g\t%g\n", similar_nucleotide_count, consecutive_skipped_CpN, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), pvalues[total_nucleotides-1], qvalues[total_nucleotides-1]);
								}
							}
							similar_nucleotide_count++;
							consecutive_skipped_CpN = 0;
							add_2nd_dmr_to_1st_dmr(DMR_similar_sum, single_nucleotide, NUMBER_OF_REPLICATES_COMPARED);
						} else {//this nucleotide *is* differentially methylated
							similar_nucleotide_count = 0;
							consecutive_skipped_CpN = 0;
	//printf("@line %u\n",__LINE__);
							zero_DMR_struct(DMR_similar_sum, NUMBER_OF_REPLICATES_COMPARED);
							if (mC_count == 1) {
								mC_start = nucleotide;
							}
							mC_end = nucleotide;
							if (options.printing_CpN_list == true) {
								CpN_list = add_uint(CpN_list, nucleotide, good_nucleotide_count);
							}
							good_nucleotide_count++;
							if (options.print_all_nucleotides == true) {
								if (options.fdr_on_all_cpn == false) {
									fprintf(fh_print_all_nucleotides,"\t%u\t0\t0\t%.2f\t%.3g\n", mC_count, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), Pvalue(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, true));
								} else {
									fprintf(fh_print_all_nucleotides,"\t%u\t0\t0\t%.2f\t%.3g\t%.3g\n", mC_count, 100.0*mean_percent_difference(DMR_sum,NUMBER_OF_REPLICATES_COMPARED), pvalues[total_nucleotides-1], qvalues[total_nucleotides-1]);
								}
							}
							continue;//this nucleotide is differentially methylated, can only improve score, why calculate p-value of set?
						}
	//					printf("chr.%s:%u @ line %u\n", gene_chromosome_changes[chr].chromosome, nucleotide, __LINE__);
//-----------------------------------------------------------
//CASE II: trial array shows differential methylation, so just add to the overall array
//-----------------------------------------------------------
//now I decide if I've got an end region or I'm continuing within a DMR
						const double SUM_MEAN_DIFFERENCE = mean_percent_difference(DMR_sum, NUMBER_OF_REPLICATES_COMPARED);
						const double P_VALUE = fabs(SUM_MEAN_DIFFERENCE) >= cutoff[run].percent ? Pvalue(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].p, &min_DEGREES_OF_FREEDOM, &min_WELCH_T_STATISTIC, false) : 1.0;
		//				print_2d_double_array(DMR_sum, NUMBER_OF_REPLICATES_COMPARED);//debugging
	//					printf("mean difference = %lf\tp = %lf\n\n",MEAN_DIFFERENCE, P_VALUE);//debugging
						if (P_VALUE < cutoff[run].p) {
							continue;//no point in doing the rest“
						}
//-----------------------------------------------------------
//CASE III: Differential methylation stops
//-----------------------------------------------------------
						const int NO_COAT_TAILS = mC_count - similar_nucleotide_count;
						if ((NO_COAT_TAILS >= cutoff[run].CpN) && ((mC_end-mC_start) >= options.MINIMUM_CPN_RANGE) && (good_nucleotide_count >= cutoff[run].d)) {
							subtract_2nd_dmr_from_1st_dmr(DMR_sum, DMR_similar_sum, NUMBER_OF_REPLICATES_COMPARED, __LINE__);
							const double SUM_PERCENT_DIFFERENCE = mean_percent_difference(DMR_sum, NUMBER_OF_REPLICATES_COMPARED);
							if (fabs(SUM_PERCENT_DIFFERENCE) >= cutoff[run].percent) {
								if (options.make_bed_files == true) {
									fprintf(bedfile_fh,"chr%s	%u	%u\n",bs_data_chromosome_changes[set1][0][chromosome].chromosome,mC_start ,mC_end);
								}
								fprintf(answers,"%s	%u	%u\t%u	%u", bs_data_chromosome_changes[set1][0][chromosome].chromosome, mC_start,mC_end, NO_COAT_TAILS, good_nucleotide_count);
								fprintf(answers,"\t%.1f", 100.0*SUM_PERCENT_DIFFERENCE);
/*								if (options.pvalue_scaling == true) {
									if (DEBUG == true) {
										printf("at %s line %u\n", __FILE__, __LINE__);
									}
									fprintf(answers, "\t%.3g", DMR_p(pvalues, pvalue_index, dice_p_values, mC_count-1));
									if (DEBUG == true) {
										printf("at %s line %u\n", __FILE__, __LINE__);
									}
								}*/
								print_methylation_percentages(DMR_sum, NUMBER_OF_REPLICATES_COMPARED, answers);
								if (cutoff[run].skip > 0) {
									fprintf(answers,"\t%u", CpN_skips_in_this_DMR);
								}
								char gene[48] = "n/a", intergene[48] = "n/a", list_gene[48] = "n/a";
								if (gene_annotation_defined == true) {
									identify_gene(mC_start, mC_end, gene, intergene, list_gene,  &min_gene_search_index, &max_gene_search_index, first_nucleotide);
									if (SUM_PERCENT_DIFFERENCE > 0) {
										methylation_up_gene_list = add_name(methylation_up_gene_list, &methylation_up_gene_list_size, &number_of_methylation_up_list_genes, list_gene, true, false);
									} else {
										methylation_down_gene_list = add_name(methylation_down_gene_list, &methylation_down_gene_list_size, &number_of_methylation_down_list_genes, list_gene, true, false);
									}
									fprintf(answers,"\t%s\t%s\t%s", gene, intergene, list_gene);
									gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, gene, false, true);
									gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, intergene, false, true);
									gene_list = add_name(gene_list, &gene_list_size, &number_of_list_genes, list_gene, false, true);
								}
								if (options.make_figures == true) {
									fprintf(rscript, "setEPS()\n");
									fprintf(rscript, "postscript('DMR_figures/%s_%s_c%u_CpN%u_d%u_p0_%02.0f_P%.0f_S%u_chr%s_%u_%u", label_set1, label_set2, cutoff[run].coverage, cutoff[run].CpN, cutoff[run].d, cutoff[run].p*100, 100.0*cutoff[run].percent, cutoff[run].skip, bs_data_chromosome_changes[set1][0][chromosome].chromosome, mC_start, mC_end);
									if (strcmp(list_gene,"n/a") != 0) {
										fprintf(rscript, "_%s", list_gene);
									}
									fprintf(rscript, ".eps')\n");
									R_figure(rscript, all_CpN, mC_count - similar_nucleotide_count, label_set1, label_set2, xaxis_label, list_gene, all_p, all_percent, all_sum_p, all_sum_percent, all_nucleotides, NUMBER_OF_REPLICATES_COMPARED, mC_start, mC_end);
									all_CpN = uint_clear(all_CpN);
									all_p = double_clear(all_p);
									all_percent = double_clear(all_percent);
									all_sum_p = double_clear(all_sum_p);
									all_sum_percent = double_clear(all_sum_percent);
									all_nucleotides = clear_nucleotides(all_nucleotides, NUMBER_OF_REPLICATES_COMPARED);
								}
								if (options.printing_CpN_list == true) {
									print_CpN_list(answers, CpN_list, good_nucleotide_count);
								}
								if (options.print_DMR_pvalue == true) {
									all_DMRs = add_nucleotides(all_DMRs, NUMBER_OF_REPLICATES_COMPARED, cutoff[run].number_of_DMRs, DMR_sum);
									DMR_chromosome_indices = add_uint(DMR_chromosome_indices, chromosome, cutoff[run].number_of_DMRs);
									DMR_starts             = add_uint(DMR_starts, mC_start, cutoff[run].number_of_DMRs);
									DMR_ends               = add_uint(DMR_ends, mC_end, cutoff[run].number_of_DMRs);
									nCpN                   = add_uint(nCpN, NO_COAT_TAILS, cutoff[run].number_of_DMRs);
									diffCpN               = add_uint(diffCpN, good_nucleotide_count, cutoff[run].number_of_DMRs);
									CpN_skips_in_this_DMR_all  = add_uint(CpN_skips_in_this_DMR_all, CpN_skips_in_this_DMR, cutoff[run].number_of_DMRs);
									if (DEBUG == true) {printf("@line %u with %u DMRs\n", __LINE__, cutoff[run].number_of_DMRs);}
								}
								cutoff[run].number_of_DMRs++;
/*								if (options.isolation == true) {
									fprintf(answers, "\t%u;%u", mC_start - last_CpN_before_DMR, get_next_CpN(mC_end,(const size_t **restrict) bisulfite_nucleotide_min, (const size_t **restrict)bisulfite_nucleotide_max, BISULFITE_DATA, NUMBER_OF_REPLICATES_COMPARED, COMPARED_SETS) - mC_end);
								}*/
								fprintf(answers,"\n");
							}
						}
						mC_count = 0;
//						last_CpN_before_DMR = nucleotide;
						similar_nucleotide_count = 0;
						good_nucleotide_count = 0;
						consecutive_skipped_CpN = 0;
						CpN_skips_in_this_DMR = 0;
						if (options.printing_CpN_list == true) {
							CpN_list = uint_clear(CpN_list);
						}
						zero_DMR_struct(DMR_sum, NUMBER_OF_REPLICATES_COMPARED);
						zero_DMR_struct(DMR_similar_sum, NUMBER_OF_REPLICATES_COMPARED);
					}//end of while loop
					CpN_list = uint_clear(CpN_list);
					all_CpN = uint_clear(all_CpN);
					free(all_CpN); all_CpN = NULL;
					free(CpN_list); CpN_list = NULL;
					free(all_p); all_p = NULL;
					free(all_percent); all_percent = NULL;
					free(all_sum_p); all_sum_p = NULL;
					free(all_sum_percent); all_sum_percent = NULL;
					free(dice_p_values); dice_p_values = NULL;
					for (unsigned short int set = 0; set < 2; set++) {//there are only 2 sets
						free(DMR_sum[set]); DMR_sum[set] = NULL;
						free(bisulfite_nucleotide_min[set]); bisulfite_nucleotide_min[set] = NULL;
						free(bisulfite_nucleotide_max[set]); bisulfite_nucleotide_max[set] = NULL;
						free(single_nucleotide[set]); single_nucleotide[set] = NULL;
						free(DMR_similar_sum[set]); DMR_similar_sum[set] = NULL;
					}
					free(DMR_sum);								DMR_sum = NULL;
					free(bisulfite_nucleotide_min);		bisulfite_nucleotide_min = NULL;
					free(bisulfite_nucleotide_max);		bisulfite_nucleotide_max = NULL;
					free(single_nucleotide);				single_nucleotide = NULL;
					free(DMR_similar_sum);					DMR_similar_sum = NULL;
					if (all_nucleotides != NULL) {
						all_nucleotides = final_free_nucleotides(all_nucleotides, NUMBER_OF_REPLICATES_COMPARED);
					}
					if (DEBUG == true) {
						printf("just finished chromosome %s @ line %u\n", bs_data_chromosome_changes[set1][0][chromosome].chromosome, __LINE__);
					}
				}//end of chromosome
				qvalues = double_clear(qvalues);//will eat up RAM, free ASAP
				pvalues = double_clear(pvalues);//will eat up RAM, free ASAP
				free(qvalues); qvalues = NULL;
				free(pvalues); pvalues = NULL;
				if (options.make_bed_files == true) {
					fclose(bedfile_fh);
				}
				if (options.print_all_nucleotides == true) {
					fclose(fh_print_all_nucleotides);
				}
				if (cutoff[run].number_of_DMRs == 0) {
					fprintf(answers, "\nNo_DMR_was_found_with_current_parameters\n\n");
					puts("\n\nNo_DMR_was_found_with_current_parameters\n");
				}
				fclose(answers);
				printf("Answers written to %s, helpful to run the command: sort -k4n %s\n",answers_filename, answers_filename);
				if (options.print_DMR_pvalue == true) {
					print_DMRs(answers_filename, all_DMRs, set1, DMR_chromosome_indices, bs_data_chromosome_changes, DMR_starts, DMR_ends, cutoff[run].number_of_DMRs, NUMBER_OF_REPLICATES_COMPARED, FDR_type, label_set1, label_set2, gene_annotation_defined, promoter_cutoff, cutoff[run].skip, options.printing_CpN_list, nCpN, diffCpN, CpN_skips_in_this_DMR_all, gene_list);
				}
				if (all_DMRs != NULL) {
					all_DMRs = final_free_nucleotides(all_DMRs, NUMBER_OF_REPLICATES_COMPARED);
				}
				free(answers_filename); answers_filename = NULL;
				free(DMR_chromosome_indices); DMR_chromosome_indices = NULL;//only used if DMR FDR is 'true'
				free(DMR_starts); DMR_starts = NULL;
				free(DMR_ends);   DMR_ends = NULL;
				free(nCpN);       nCpN = NULL;
				free(diffCpN);    diffCpN = NULL;
				free(CpN_skips_in_this_DMR_all);   CpN_skips_in_this_DMR_all   = NULL;
				gene_list = clear_names(gene_list, &gene_list_size, &number_of_list_genes);
				free(gene_list); gene_list = NULL;
				if ((options.make_bed_files == true) && (cutoff[run].number_of_DMRs > 0)) {
					printf("A bed file has been written to %s\n",bedfile_filename);
				}
				free(bedfile_filename); bedfile_filename = NULL;
				if (options.make_figures == true) {
					fclose(rscript);
					char command[64] = "Rscript ";
					strcat(command, rscript_filename);
					if (system(command) != 0) {
						printf("%s FAILED.\n", command);
						perror("");
						exit(EXIT_FAILURE);
					}
				}
//-------------------------------------------------
//finished opening gene list file
//-------------------------------------------------
				if (gene_annotation_defined == true) {
					if (number_of_methylation_up_list_genes > 0) {//only print the names if there are names to print
						FILE *restrict methylation_up_gene_list_fh = NULL;
						char *restrict gene_list_filename = malloc(sizeof(label_set1)+sizeof(label_set2)+sizeof(char)*strlen("_vs____methylation_up_gene_list.txt")+sizeof(options_string));
						sprintf(gene_list_filename,"%s_vs_%s",label_set1, label_set2);
						strcat(gene_list_filename,"_");
						strcat(gene_list_filename,options_string);
						strcat(gene_list_filename,"_methylation_up_gene_list.txt");
						methylation_up_gene_list_fh = fopen(gene_list_filename,"w");
						if (methylation_up_gene_list_fh == NULL) {
							perror("");
							printf("Failed to write %s\n", gene_list_filename);
							exit(EXIT_FAILURE);
						}
						for (unsigned int gene_index = 0; gene_index < number_of_methylation_up_list_genes; gene_index++) {
							fprintf(methylation_up_gene_list_fh,"%s\n",methylation_up_gene_list[gene_index]);
						}
						fclose(methylation_up_gene_list_fh);
						printf("A gene list, with intergenic genes identified with promoter cutoff = %u nucleotides has been written to %s\n", promoter_cutoff, gene_list_filename);
						free(gene_list_filename); gene_list_filename = NULL;
					} else {
						printf("For %s vs. %s, there were no detected genes with increases in methylation\n", label_set1, label_set2);
					}
					if (number_of_methylation_down_list_genes > 0) {//only print the names if there are names to print
						FILE *restrict gene_list_fh = NULL;
						char *restrict gene_list_filename = malloc(sizeof(label_set1)+sizeof(label_set2)+sizeof(char)*strlen("_vs____methylation_down_gene_list.txt")+sizeof(options_string));
						sprintf(gene_list_filename,"%s_vs_%s",label_set1, label_set2);
						strcat(gene_list_filename,"_");
						strcat(gene_list_filename,options_string);
						strcat(gene_list_filename,"_methylation_down_gene_list.txt");
						gene_list_fh = fopen(gene_list_filename,"w");
						if (gene_list_fh == NULL) {
							perror("");
							printf("Failed to write %s\n", gene_list_filename);
							exit(EXIT_FAILURE);
						}
						for (unsigned int gene_index = 0; gene_index < number_of_methylation_down_list_genes; gene_index++) {
							fprintf(gene_list_fh,"%s\n",methylation_down_gene_list[gene_index]);
						}
						fclose(gene_list_fh);
						printf("A gene list, with intergenic genes identified with promoter cutoff = %u nucleotides has been written to %s\n", promoter_cutoff, gene_list_filename);
						free(gene_list_filename); gene_list_filename = NULL;
					} else {
						printf("For %s vs. %s, there were no detected genes with decreases in methylation\n", label_set1, label_set2);
					}
				}
//begin clearing out memory
				methylation_up_gene_list = clear_names(methylation_up_gene_list, &methylation_up_gene_list_size, &number_of_methylation_up_list_genes);
				free(methylation_up_gene_list); methylation_up_gene_list = NULL;
				methylation_down_gene_list = clear_names(methylation_down_gene_list, &methylation_down_gene_list_size, &number_of_methylation_down_list_genes);
				free(methylation_down_gene_list); methylation_down_gene_list = NULL;

				printf("\t%zu/%zu = %.1f%% of nucleotides met minimum coverage and were present with minimum coverage = %u in every sample.\n", nucleotides_good_in_every_organism, total_nucleotides, 100.0*(double)nucleotides_good_in_every_organism /total_nucleotides, cutoff[run].coverage);
			}
			if (RUNS > 1) {	
//first need to allocate memory for the filename string
				unsigned short int TOTAL_LABEL_STRING_LENGTH = 0;
				if (total_label != NULL) {//strlen on null string gives segfault
					TOTAL_LABEL_STRING_LENGTH = strlen(total_label);
				}
				char *restrict dmr_count_filename = malloc(sizeof(label_set1)+sizeof(label_set2)*sizeof(char)*strlen("_vs__dmr_count.tsv")+sizeof(char*) + sizeof(char)*TOTAL_LABEL_STRING_LENGTH);
				if (TOTAL_LABEL_STRING_LENGTH > 0) {
					sprintf(dmr_count_filename,"%s_vs_%s_%s_dmr_count.tsv", label_set1, label_set2, total_label);//make the filename
				} else {
					sprintf(dmr_count_filename,"%s_vs_%s_dmr_count.tsv", label_set1, label_set2);//make the filename
				}
				FILE *restrict dmr_count_fp = fopen(dmr_count_filename, "w");//open file for writing
				if (dmr_count_fp == NULL) {//in case I can't write the file, abort the execution
					printf("Couldn't write %s\n", dmr_count_filename);
					perror("");
					free(label_set1); label_set1 = NULL;
					free(label_set2); label_set2 = NULL;
					exit(EXIT_FAILURE);
				}
				fprintf(dmr_count_fp, "Coverage\tMin.CpN\tMin.Diff.CpN\tMax.pValue\tMin.percent\tSkips\t#DMRs\n");//print the header
				for (unsigned int run = 0; run < RUNS; run++) {
					fprintf(dmr_count_fp, "%u\t%u\t%u\t%g\t%lf\t%u\t%u\n", cutoff[run].coverage, cutoff[run].CpN, cutoff[run].d, cutoff[run].p, 100.0*cutoff[run].percent, cutoff[run].skip, cutoff[run].number_of_DMRs);
				}
				fclose(dmr_count_fp);//close the file pointer
				printf("DMR counts with varying cutoffs have been written to %s\n", dmr_count_filename);
				free(dmr_count_filename); dmr_count_filename = NULL;//free the memory used for the dmr_count_filename
			}
			free(label_set1); label_set1 = NULL;
			free(label_set2); label_set2 = NULL;
		}
		
	}
//---------------------------------------------------------------------------------------------
//Begin Freeing memory
//---------------------------------------------------------------------------------------------
	puts("Finished analysis, now freeing memory...");
	free(FDR_type); FDR_type = NULL;
	free(cutoff); cutoff = NULL;
	for (unsigned short int set_loop = 0; set_loop < SETS; set_loop++) {
		for (unsigned short int replicate_loop = 0; replicate_loop < number_of_replicates_per_set[set_loop]; replicate_loop++) {
			if (DEBUG == true) {
		 		printf("Now freeing BISULFITE_DATA[%hu][%hu] on line %u\n",set_loop, replicate_loop, __LINE__);
		 	}
			free(BISULFITE_DATA[set_loop][replicate_loop]); BISULFITE_DATA[set_loop][replicate_loop] = NULL;
			if (DEBUG == true) {
		 		printf("Now freeing bs_data_chromosome_changes[%u][%u] on line %u\n",set_loop, replicate_loop, __LINE__);
		 	}
			free(bs_data_chromosome_changes[set_loop][replicate_loop]); bs_data_chromosome_changes[set_loop][replicate_loop] = NULL;
		}
		if (DEBUG == true) {
			printf("about to free BISULFITE_LOOP[%hu] on line %u\n",set_loop,__LINE__);
		}
		free(BISULFITE_DATA[set_loop]); BISULFITE_DATA[set_loop] = NULL;
		if (DEBUG == true) {
			printf("about to free bs_data_chromosome_changes[%hu] on line %u\n",set_loop,__LINE__);
		}
		free(bs_data_chromosome_changes[set_loop]); bs_data_chromosome_changes[set_loop] = NULL;
	}
	if (DEBUG == true) {
		printf("about to free BISULFITE_DATA on line %u\n",__LINE__);
	}
	free(BISULFITE_DATA); BISULFITE_DATA = NULL;
	if (DEBUG == true) {
		printf("about to free gene_chromosome_changes on line %u\n",__LINE__);
	}
	free(gene_chromosome_changes); gene_chromosome_changes = NULL;
	free(number_of_replicates_per_set); number_of_replicates_per_set = NULL;
	free(bs_data_chromosome_changes); bs_data_chromosome_changes = NULL;
	free(gene_chromosome_changes); gene_chromosome_changes = NULL;
	if (DEBUG == true) {
		printf("About to free GENES @ line %u\n",__LINE__);
	}
	free(GENES); GENES = NULL;
	if (DEBUG == true) {
		printf("Successfully closed GENES, now about to close defiant_run_info @ %s line %u\n",__FILE__, __LINE__);
	}
	labels = clear_names(labels, &labels_size, &number_of_labels);
	free(labels); labels = NULL;
	free(xaxis_label); xaxis_label = NULL;
	free(total_label); total_label = NULL;
	return 0;
}
