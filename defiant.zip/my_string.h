#include <stdio.h>
#include <string.h>

unsigned short int count_occurences_of_string (const char *restrict BIG_STRING, const char *restrict SMALL_STRING) {//count occurences of a small string in a big string
//modified from http://www.sanfoundry.com/c-program-count-occurence-substring/
	unsigned short int i, j, count = 0, count1 = 0;
	const size_t l1 = strlen(BIG_STRING), l2 = strlen(SMALL_STRING);
	for (i = 0; i < l1;)	{
		j = 0;
		count = 0;
		while (BIG_STRING[i] == SMALL_STRING[j])	{
			count++;
			i++;
			j++;
		}
		if (count == l2)	{
			count1++;
			count = 0;
		} else {
			i++;
		}
	}
	return count1;
}

