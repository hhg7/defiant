#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define GNU_SOURCE
#include <stdbool.h>

typedef struct {
	double min, max, step;
} option_range_struct;

typedef struct {
	unsigned int coverage, d, skip, CpN;
	unsigned int number_of_DMRs;
	double p, percent;
} cutoff_struct;


option_range_struct get_option_range (const char *restrict STRING) {
	option_range_struct return_struct;
	if (strstr(STRING,",") == NULL) {
		return_struct.step = 7.0;
		return_struct.min = safe_strtod(STRING);
		return_struct.max = safe_strtod(STRING);
		return return_struct;
	}
	char *restrict copy_string = strdup(STRING);
	char *restrict string, *string_pointer = NULL;
	string = strtok_r(copy_string, ",", &string_pointer);
//
	return_struct.min = safe_strtod(string);
	string = strtok_r(NULL, ",", &string_pointer);

	return_struct.max = safe_strtod(string);
	string = strtok_r(NULL, ",", &string_pointer);
	if (string == NULL) {//i.e., the string ends here
		free(copy_string); copy_string = NULL;
		if (return_struct.max < return_struct.min) {
			const double TMP = return_struct.max;
			return_struct.max = return_struct.min;
			return_struct.min = TMP;
		}
		return_struct.step = return_struct.max - return_struct.min;
		return return_struct;
	}

	return_struct.step = safe_strtod(string);
	free(copy_string); copy_string = NULL;
	if (return_struct.max < return_struct.min) {
		const double TMP = return_struct.max;
		return_struct.max = return_struct.min;
		return_struct.min = TMP;
	}
	return return_struct;
}

/*int cmpfunc (const void *restrict a, const void *restrict b) {
   return ( *(int *restrict)a - *(int *restrict)b );
}

int double_cmpfunc (const void *restrict a, const void *restrict b) {
   return ( *(double *restrict)a - *(double *restrict)b );
}*/

unsigned int how_many_uint_array_elements (const unsigned int DEFAULT, const option_range_struct RANGE, const unsigned int CPU) {
	if ((RANGE.min == RANGE.max) ) {
		if (RANGE.min == DEFAULT) {
			return 1;
		} else if (RANGE.min != DEFAULT) {//will return the value and the default
			if (CPU > 1) {
				return 2;
			} else {
				return 1;
			}
		}
	}
	unsigned int NUMBER_OF_ARRAY_ELEMENTS = 0;
	bool defaults_present = 0;
	for (unsigned int c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		NUMBER_OF_ARRAY_ELEMENTS++;
		if (c == DEFAULT) {
			defaults_present = 1;
		}
	}
	if ((defaults_present == 0) && (CPU > 1)) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	return NUMBER_OF_ARRAY_ELEMENTS;
}

unsigned int how_many_double_array_elements (const double DEFAULT, const option_range_struct RANGE, const unsigned int CPU) {
	if (RANGE.min == RANGE.max) {
		if (RANGE.min == DEFAULT) {
			return 1;
		} else if (RANGE.min != DEFAULT) {//will return the value and the default
			if (CPU > 1) {
				return 2;
			} else {
				return 1;
			}
		}
	}
	bool defaults_present = 0;
	unsigned int NUMBER_OF_ARRAY_ELEMENTS = 0;
	for (double c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		NUMBER_OF_ARRAY_ELEMENTS++;
		if (c == DEFAULT) {
			defaults_present = 1;
		}
	}
	if ((defaults_present == 0) && (CPU > 1)) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	return NUMBER_OF_ARRAY_ELEMENTS;
}

void *restrict uint_array_alloc (const unsigned int DEFAULT, const option_range_struct RANGE, const unsigned int CPU) {
	unsigned int *restrict array = NULL;
	if (RANGE.min == RANGE.max) {
		if (RANGE.min == DEFAULT) {
			array = malloc(sizeof(unsigned int));
			array[0] = DEFAULT;
		} else if (RANGE.min != DEFAULT) {
			if (CPU > 1) {
				array = malloc(sizeof(unsigned int)*2);
				array[0] = DEFAULT;
				array[1] = RANGE.max;//could also use range.max
			} else {//CPU = 1 
				array = malloc(sizeof(unsigned int));
				array[0] = RANGE.max;
			}
		}
		return array;
	}
	bool defaults_present = 0;
	unsigned int index = 0;
	for (unsigned int c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		if (c == DEFAULT) {
			defaults_present = 1;
		}
		index++;
	}

	unsigned int NUMBER_OF_ARRAY_ELEMENTS = index;
	if ((defaults_present == 0) && (CPU > 1)) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	array = malloc(sizeof(unsigned int)*NUMBER_OF_ARRAY_ELEMENTS);
	index = 0;
	for (unsigned int c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		array[index] = c;
		index++;
	}
	if ((defaults_present == 0) && (CPU > 1)) {
		array[index] = DEFAULT;
	}
	return array;
}

void *restrict double_array_alloc (const double DEFAULT, const option_range_struct RANGE, const unsigned int CPU) {
	if (RANGE.min == RANGE.max) {
		double *restrict array = NULL;
		if (RANGE.min == DEFAULT) {
			array = malloc(sizeof(double));
			array[0] = DEFAULT;
		} else if (RANGE.min != DEFAULT) {
			if (CPU > 1) {
				array = malloc(sizeof(double)*2);
				array[0] = DEFAULT;
				array[1] = RANGE.max;//could also use range.max
			} else {//CPU = 1 
				array = malloc(sizeof(double));
				array[0] = RANGE.max;
			}
		}
		return array;
	}
	bool defaults_present = 0;
	unsigned int index = 0;
	for (double c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		index++;
		if (c == DEFAULT) {
			defaults_present = 1;
		}
	}
	size_t NUMBER_OF_ARRAY_ELEMENTS = index;
	if ((defaults_present == 0) && (CPU > 1)) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	double *restrict array = malloc(sizeof(double)*NUMBER_OF_ARRAY_ELEMENTS);
	index = 0;
	for (double c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		array[index] = c;
		index++;
	}
	if ((defaults_present == 0) && (CPU > 1)) {
		array[index] = DEFAULT;
	}
	return array;
}

const unsigned int how_many_runs (const option_range_struct coverage, const option_range_struct CpN, const option_range_struct d, const option_range_struct p, const option_range_struct percent, const option_range_struct skip, const cutoff_struct defaults, const unsigned short int ALLOWED_NON_DEFAULTS, const unsigned int CPU) {
	const unsigned int COVERAGE_ITERATIONS = how_many_uint_array_elements(defaults.coverage, coverage, CPU);
	const unsigned int CPN_ITERATIONS = how_many_uint_array_elements(defaults.CpN, CpN, CPU);
	const unsigned int D_ITERATIONS = how_many_uint_array_elements(defaults.d, d, CPU);
	const unsigned int P_ITERATIONS = how_many_double_array_elements(defaults.p, p, CPU);
	const unsigned int PERCENT_ITERATIONS = how_many_double_array_elements(defaults.percent, percent, CPU);
	const unsigned int SKIP_ITERATIONS = how_many_uint_array_elements(defaults.skip, skip, CPU);
	unsigned int *restrict coverage_array = uint_array_alloc(defaults.coverage, coverage, CPU);
	unsigned int *restrict cpn_array = uint_array_alloc(defaults.CpN, CpN, CPU);
	unsigned int *restrict d_array = uint_array_alloc(defaults.d, d, CPU);
	double *restrict p_array = double_array_alloc(defaults.p, p, CPU);
	double *restrict percent_array = double_array_alloc(defaults.percent, percent, CPU);
	unsigned int *restrict skip_array = uint_array_alloc(defaults.skip, skip, CPU);
	unsigned int runs = 0;
	for (unsigned int c = 0; c < COVERAGE_ITERATIONS; c++) {
		for (unsigned int CpG = 0; CpG < CPN_ITERATIONS; CpG++) {
			for (unsigned int diff = 0; diff < D_ITERATIONS; diff++) {
				for (unsigned int pvalue = 0; pvalue < P_ITERATIONS; pvalue ++) {
					for (unsigned int Percent = 0; Percent < PERCENT_ITERATIONS; Percent ++) {
						for (unsigned int skips = 0; skips < SKIP_ITERATIONS; skips ++) {
							unsigned short int non_default_values = 0;
							if (coverage_array[c] != defaults.coverage) {
								non_default_values++;
							}
							if (cpn_array[CpG] != defaults.CpN) {
								non_default_values++;
							}
							if (d_array[diff] != defaults.d) {
								non_default_values++;
							}
							if (p_array[pvalue] != defaults.p) {
								non_default_values++;
							}
							if (percent_array[Percent] != defaults.percent) {
								non_default_values++;
							}
							if (skip_array[skips] != defaults.skip) {
								non_default_values++;
							}
//							printf("c%u	CpN%u	p%.2f	P%.2f	S%u\n", c, CpG, pvalue, Percent, skips);
							if (non_default_values <= ALLOWED_NON_DEFAULTS) {
								runs++;
							}
						}
					}
				}
			}
		}
	}
	free(coverage_array);	coverage_array = NULL;
	free(cpn_array);			cpn_array = NULL;
	free(d_array);				d_array = NULL;
	free(p_array);				p_array = NULL;
	free(percent_array);		percent_array = NULL;
	free(skip_array);			skip_array = NULL;
	return runs;
}

cutoff_struct *restrict make_cutoff_struct (const option_range_struct coverage, const option_range_struct CpN, const option_range_struct d, const option_range_struct p, const option_range_struct percent, const option_range_struct skip,  const cutoff_struct defaults, const unsigned short int ALLOWED_NON_DEFAULTS, const unsigned int CPU) {
	const unsigned int RUNS = how_many_runs(coverage, CpN, d, p, percent, skip, defaults, ALLOWED_NON_DEFAULTS, CPU);
	if (RUNS == 0) {
		return NULL;
	}
	cutoff_struct *restrict array = malloc(RUNS * sizeof(cutoff_struct));
	const unsigned int COVERAGE_ITERATIONS = how_many_uint_array_elements(defaults.coverage, coverage, CPU);
	const unsigned int CPN_ITERATIONS = how_many_uint_array_elements(defaults.CpN, CpN, CPU);
	const unsigned int D_ITERATIONS = how_many_uint_array_elements(defaults.d, d, CPU);
	const unsigned int P_ITERATIONS = how_many_double_array_elements(defaults.p, p, CPU);
	const unsigned int PERCENT_ITERATIONS = how_many_double_array_elements(defaults.percent, percent, CPU);
	const unsigned int SKIP_ITERATIONS = how_many_uint_array_elements(defaults.skip, skip, CPU);
	unsigned int *restrict coverage_array = uint_array_alloc(defaults.coverage, coverage, CPU);
	unsigned int *restrict cpn_array = uint_array_alloc(defaults.CpN, CpN, CPU);
	unsigned int *restrict d_array = uint_array_alloc(defaults.d, d, CPU);
	double *restrict p_array = double_array_alloc(defaults.p, p, CPU);
	double *restrict percent_array = double_array_alloc(defaults.percent, percent, CPU);
	unsigned int *restrict skip_array = uint_array_alloc(defaults.skip, skip, CPU);
	unsigned int run = 0;//first run is all defaults
	for (unsigned int c = 0; c < COVERAGE_ITERATIONS; c++) {
		for (unsigned int CpG = 0; CpG < CPN_ITERATIONS; CpG++) {
	//		printf("	CpN = %u, %u/%u\n", cpn_array[CpG], CpG, CPN_ITERATIONS);
			for (unsigned int diff = 0; diff < D_ITERATIONS; diff++) {
//				printf("		d = %u, %u/%u\n", d_array[diff], diff, D_ITERATIONS);
				for (unsigned int pvalue = 0; pvalue < P_ITERATIONS; pvalue ++) {
//					printf("			p = %lf, %u/%u\n", p_array[pvalue], pvalue, P_ITERATIONS);
					for (unsigned int Percent = 0; Percent < PERCENT_ITERATIONS; Percent ++) {
//						printf("				%% = %lf,	 %u/%u\n", percent_array[Percent], Percent, PERCENT_ITERATIONS);
						for (unsigned int skips = 0; skips < SKIP_ITERATIONS; skips++) {
//							printf("					skips = %u, %u/%u\n", skip_array[skips], skips, SKIP_ITERATIONS);
							unsigned short int non_default_values = 0;
							if (coverage_array[c] != defaults.coverage) {
								non_default_values++;
							}
							if (cpn_array[CpG] != defaults.CpN) {
								non_default_values++;
							}
							if (d_array[diff] != defaults.d) {
								non_default_values++;
							}
							if (p_array[pvalue] != defaults.p) {
								non_default_values++;
							}
							if (percent_array[Percent] != defaults.percent) {
								non_default_values++;
							}
							if (skip_array[skips] != defaults.skip) {
								non_default_values++;
							}
							if (non_default_values <= ALLOWED_NON_DEFAULTS) {
								if (run > RUNS) {
									printf("You are about to segfault at @ %s line %u\n", __FILE__, __LINE__);
									exit(EXIT_FAILURE);
								}
								array[run].coverage			= coverage_array[c];
								array[run].CpN					= cpn_array[CpG];
								array[run].d					= d_array[diff];
								array[run].p					= p_array[pvalue];
								array[run].percent			= percent_array[Percent];
								array[run].skip				= skip_array[skips];
								array[run].number_of_DMRs	= 0;
//								printf("run %u	c = %u	CpN = %u	d = %u	p = %.2f	P = %lf	S = %u\n", run, array[run].coverage, array[run].CpN, array[run].d, array[run].p, array[run].percent, array[run].skip);
								run++;
							}
						}
					}
				}
			}
		}
	}
	free(coverage_array); coverage_array = NULL;
	free(cpn_array); cpn_array = NULL;
	free(d_array);	d_array = NULL;
	free(p_array); p_array = NULL;
	free(percent_array); percent_array = NULL;
	free(skip_array); skip_array = NULL;
	return array;
}
