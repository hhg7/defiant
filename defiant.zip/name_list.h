#include <stdbool.h>
#include <string.h>

void *restrict add_gene(char **restrict array, size_t *restrict size, unsigned int *restrict f_number_of_list_genes, const char *restrict NAME, const bool UNIQUE) {//this function works, when freed inside main()
	if (strcmp(NAME,"n/a") == 0) {
		return array;
	}//don't bother with empty strings
//	printf("@line %u, adding %s to gene list array, with size %zu and %u elements.\n", __LINE__, NAME, *size, *f_number_of_list_genes);//debugging
	if (UNIQUE == true) {
		for (int name = *f_number_of_list_genes-1; name >= 0; name--) {//if I count a gene twice, it is most likely from the front 
	//		printf("array[%u] = %s with %s\n",name, array[name], NAME);
			if (strcmp(array[name], NAME) == 0) {
				return array;//if this name is already in the list, don't add it
			}
		}
	}
	const size_t NAME_SIZE = strlen(NAME)*sizeof(char)+2*sizeof(char*);
	*size += NAME_SIZE;
	array = realloc(array, *size);
	if (array == NULL) {
		puts("realloc of array failed.\n");
		exit(EXIT_FAILURE);
	}
	array[*f_number_of_list_genes] = malloc(NAME_SIZE);
	if (array[*f_number_of_list_genes] == NULL) {
		printf("alloc of array[%u] failed.\n", *f_number_of_list_genes);
		exit(EXIT_FAILURE);
	}
	strcpy(array[*f_number_of_list_genes], NAME);
	*f_number_of_list_genes += 1;
	return array;
}

void *restrict clear_names(char **restrict array, size_t *restrict size, unsigned int *restrict number_of_annotated_genes) {//empty the list of names
	for (size_t name = 0; name < *number_of_annotated_genes; name++) {
		free(array[name]); array[name] = NULL;//this is missing something
		if (array[name] != NULL) {
			printf("free of array[%zu] failed.\n", name);
		}
	}
	*number_of_annotated_genes = 0;
	*size = sizeof(char);
	array = realloc(array, *size);
	if (array == NULL) {
		printf("realloc of array failed @ %s line %u\n",__FILE__, __LINE__);
		exit(EXIT_FAILURE);
	}
	return array;
}
