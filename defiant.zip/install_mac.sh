clang -o defiant_mac defiant_mac.c -Wall -pedantic -std=gnu11 -lm
echo "defiant_mac has been successfully installed!"
echo "Defiant is accessable with the executable \"defiant_mac\""
echo "Please read defiant_mac_manual.pdf"
