grep -v omp.h defiant.c | grep -v omp_ | grep -v pragma | sed 's/char \*restrict argv/char * argv/g' > defiant_mac.c
clang -o defiant_mac defiant_mac.c -Wall -pedantic -std=gnu99 -lm -O3
echo "defiant_mac has been successfully installed!"
echo "Defiant is accessable with the executable \"defiant_mac\""
echo "Please read defiant_mac_manual.pdf"
