#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define GNU_SOURCE
#include <ctype.h>
#include <stdbool.h>

bool is_string_integer (const char *restrict STRING) {
	for (size_t x = 0; x < strlen(STRING); x++) {
		if (STRING[x] == '\n') {
			break;
		}
		if (!isdigit(STRING[x])) {
			return false;
		}//if any digit isn't a digit, return false
	}
	return true;
}

bool is_string_float (const char *restrict STRING) {
	const size_t STRING_LENGTH = strlen(STRING);
	unsigned short int number_of_decimal_points = 0;
	for (size_t x = 0; x < STRING_LENGTH; x++) {
		if (STRING[x] == '\n') {
			break;
		}
		if ((x > 0) && (x < (STRING_LENGTH-1)) && (STRING[x] == '.')) {
			if (number_of_decimal_points == 1) {
				return false;
			}//only allowed 1 decimal point '.'
			number_of_decimal_points++;
			continue;
		}
		if (!isdigit(STRING[x])) {
			return false;
		}//if any digit isn't a digit, return false
	}
	if (number_of_decimal_points == 1) {
		return true;
	} else {
		return false;
	}
}

typedef struct {
	unsigned int nucleotide, coverage, methylated_C;
	char chromosome[96];
} LINE_STRUCT;

typedef struct {
	unsigned short int type;
	bool header;
} FILE_TYPE_STRUCT;

FILE_TYPE_STRUCT get_file_type (const char *restrict line) {//determines file type of input
//return 1: "chr1	768	768	0.4666	15"//Jon Schug's format
//return 2: "chr21.43008720	chr21	43008720	R	67	92.54	7.46"
//return 2 header "chrBase	chr	base	strand	coverage	freqC	freqT"//some program gives this output, I don't know which one, header
//return 3: "chr1	768	768	0.4666" without coverage information//found on Geobase
//return 4:"chr1	3391	6	14"//found on GeoBase
//return 5:<chromosome> <position> <strand> <count methylated> <count unmethylated> <C-context> <trinucleotide context>//Bismark coverage2cytosine format
//return 6 <chromosome> <start position> <end position> <methylation percentage> <count methylated> <count unmethylated>//Bismark bismark2bedGraph format
//return 7::tid chr pos m-score conf
//return 8: chr1	3010874	3010876	'46/47'	978	+ (EPP)Epigenome Processing Pipeline
//return 9: bsmooth input: 10	60025	+	CG	25	26
//return 10:	chr1	10496	10497	79.69	64	+	10496	10497	180,60,0 (BisSNP), found in RnBeads
//check list of possible headers
	FILE_TYPE_STRUCT return_struct;
	return_struct.type = 0;
	if (strcmp("chrBase	chr	base	strand	coverage	freqC	freqT\n", line) == 0) {
		return_struct.header = true;
		return_struct.type = 2;
		return return_struct;
	} else if (strcmp(":tid chr pos m-score conf\n", line) == 0) {
		return_struct.header = true;
		return_struct.type = 7;
		return return_struct;
	}
	return_struct.header = false;
	char *restrict line_copy = strdup(line);
	if (line_copy[strlen(line)-1] == '\n') {
		line_copy[strlen(line)-1] = '\0';//get rid of newline, i.e. same as perl's 'chomp'
	}
	char *restrict temporary_char_string,  *saveptr;//necessary for strtok_r
	temporary_char_string = strtok_r(line_copy, "\t ", &saveptr);
	unsigned short int number_of_columns = 1, integers = 0, floats = 0, strand_definition = 0;
	bool column2_is_chr = false, column1_is_int = false, column1_is_chr = false;
	bool column4_is_fraction = false;
//	bool column4_is_float = false;
	size_t column2 = 0, column3 = 0;//for comparing and distinguishing file types
	bool column2_is_int = false;
	bool column3_is_int = false;
	bool column4_is_int = false;
	if ((number_of_columns == 1)) {// && (strstr(temporary_char_string,"chr") != NULL)) {
		column1_is_chr = true;
	}
	while (temporary_char_string != NULL) {
//		printf("%s\n",temporary_char_string);//debugging
		if ((number_of_columns == 2) && (strstr(temporary_char_string,"chr") != NULL)) {
			column2_is_chr = true;
		}
		if ((number_of_columns == 2) && (is_string_integer(temporary_char_string) == true)) {
			column2_is_int = true;
			column2 = (unsigned)safe_strtoul(temporary_char_string);
		}
		if ((number_of_columns == 3) && (is_string_integer(temporary_char_string) == true)) {
			column3_is_int = true;
			column3 = (unsigned)safe_strtoul(temporary_char_string);
		}
		if ((number_of_columns == 4) && (strstr(temporary_char_string,"/") != NULL)) {
			column4_is_fraction = true;
		}
		if ((number_of_columns == 4) && (is_string_integer(temporary_char_string) == true)) {
			column4_is_int = true;
		}
//		if ((number_of_columns == 4) && (is_string_float(temporary_char_string) == true)){
//			column4_is_float = true;
//		}
		if ((number_of_columns == 6) && ((strcmp(temporary_char_string,"+") == 0) || (strcmp(temporary_char_string,"-") == 0))) {
			strand_definition = 6;
		}
		if ((strcmp(temporary_char_string,"-") == 0) || (strcmp(temporary_char_string,"+") == 0) || (strcmp(temporary_char_string,"R") == 0) || (strcmp(temporary_char_string,"F") == 0) ) {
			strand_definition = number_of_columns;
		}
		if ((number_of_columns == 7) && (strand_definition == 3) && ((strcmp(temporary_char_string,"CGA") == 0) || (strcmp(temporary_char_string,"CGC") == 0) || (strcmp(temporary_char_string,"CGG") == 0) || (strcmp(temporary_char_string,"CGN") == 0) ||(strcmp(temporary_char_string,"CGT") == 0))) {//trying to be as specific as I can
			return_struct.type = 5;
			break;
		}
		if (is_string_float(temporary_char_string) == true) {
//			printf("%s is a float\n",temporary_char_string);
			floats++;
		} else if (is_string_integer(temporary_char_string) == true) {
//			printf("%s is an integer\n",temporary_char_string);
			integers++;
			if (number_of_columns == 1) {
				column1_is_int = true;
				column1_is_chr = false;
			}
		}
		temporary_char_string = strtok_r(NULL, "\t ", &saveptr);
		if (temporary_char_string == NULL) {
			break;
		}
		number_of_columns++;
	}
	if ((number_of_columns == 5) && (column1_is_chr == true) && (strand_definition == 0) && ((integers == 4) || (integers == 3)) && ((floats == 1) || (floats == 0))) {
		return_struct.type = 1;
	} else if ((column2_is_chr == true) && (number_of_columns == 7)) {
		return_struct.type = 2;
	} else if ((number_of_columns == 4) && (column2_is_int == true) && (column3_is_int == true) && (column3 == (column2+1))) {
		return_struct.type = 3;
	} else if ((number_of_columns == 4) && (column2_is_int == true) && (column4_is_int == true) && (column4_is_int == true) && (column3 != (column2+1))) {
		return_struct.type = 4;
	} else if ((column1_is_chr == true) && (number_of_columns == 7) && (strand_definition == 3)) {
		return_struct.type = 5;
	} else if ((number_of_columns == 6) && (strand_definition == 0) && ((integers == 4) || (integers == 5)) && ((floats == 1) || (floats == 0))) {
		return_struct.type = 6;
	} else if ((number_of_columns == 6) && (column1_is_int == true) && (strand_definition == 0)) {
		return_struct.type = 7;
	} else if ((column4_is_fraction == true) && (strand_definition == 7)) {
		return_struct.type = 8;
	} else if ((column1_is_chr == false) && (number_of_columns == 6) && (integers == 4) && (floats == 0) && (strand_definition == 3)) {
		return_struct.type = 9;
	} else if (((column2_is_int == true) && (column3_is_int == true) && (column2 == (column3-1))) && (strand_definition == 0)) {
		return_struct.type = 10;
	} else {//everything below this prints details so I can debug
		printf("%s:\ncould not identify file type with number_of_columns = %u, integers = %u, floats = %u\n",line,number_of_columns,integers,floats);
		printf("failed at %s line %u\n", __FILE__, __LINE__);
		if (strand_definition == 0) {
			puts("strand is not defined.");
		} else {
			printf("strand is defined @ column %u.\n", strand_definition);
		}
		if (column1_is_int == false) {
			puts("column1_is_int = false.");
		} else {
			puts("column1_is_int = true.");
		}
		if (column1_is_chr == false) {
			puts("column1_is_chr = false.");
		} else {
			puts("column1_is_chr = true.");
		}
		exit(EXIT_FAILURE);
	}
	free(line_copy); line_copy = NULL;
	return return_struct;
}

const char UNDEFINED_CHAR[96] = "?";
LINE_STRUCT read_data_line(const char *restrict line, const unsigned short int TYPE) {//, const bool FDEBUG) {//read line of data from file, necessary if the program reads multiple file types
/*	if (FDEBUG == true) {
		FILE_TYPE_STRUCT file_type_check = get_file_type(line);
		if (file_type_check.type != TYPE) {
			printf("line %s does not match file type @ %s line %u\n", line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
	}*/
	LINE_STRUCT return_struct;
	char *restrict bs_line_copy = strdup(line);
	char *saveptr, *restrict temporary_character_string;
	return_struct.nucleotide = 0;
	return_struct.methylated_C = 0;
	strcpy(return_struct.chromosome,UNDEFINED_CHAR);
	return_struct.coverage = 0;
	const size_t SUBSTITUTION_INDEX = strlen(line)-1;
	if (line[SUBSTITUTION_INDEX] == '\n') {
		bs_line_copy[SUBSTITUTION_INDEX] = '\0';//get rid of newline, i.e. same as perl's 'chomp'
	}
//	return_struct.sense = 0;
	if (TYPE == 1) {//bedgraph format
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);//get 2nd column as string
		temporary_character_string = strtok_r(NULL,"\t ",&saveptr);//throw away 3rd column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL,"\t ",&saveptr);//get 4th column as string
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		const double PERCENT = safe_strtod(temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);
		if (temporary_character_string == NULL) {
			printf("I couldn't get 5th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
 		return_struct.coverage = (unsigned)safe_strtoul(temporary_character_string);//5th column is coverage
 		return_struct.methylated_C = (unsigned)(double)(PERCENT*return_struct.coverage);
	} else if (TYPE == 2) {//chrBase	chr	base	strand	coverage	freqC	freqT			methylSig input (maybe bismark?)
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//like chr21
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//ignore first string of characters
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//like 43008720 = nucleotide
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);//export nucleotide to output struct
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//ignore sense
		if (temporary_character_string == NULL) {
			printf("I couldn't get 5th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//will be coverage
		if (temporary_character_string == NULL) {
			printf("I couldn't get 6th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.coverage = (unsigned)safe_strtoul(temporary_character_string);//export nucleotide to output struct
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//will be percent
		if (temporary_character_string == NULL) {
			printf("I couldn't get 7th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.methylated_C = (unsigned)((safe_strtod(temporary_character_string) / 100.0) * return_struct.coverage);
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);
	} else if (TYPE == 3) {//chr10	119965	119966	0.03846
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//2nd column nucleotide
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);//get 2nd column as string
		temporary_character_string = strtok_r(NULL,"\t ",&saveptr);//discard 3rd column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL,"\t ",&saveptr);//get 4th column as string
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		const double PERCENT = (double)safe_strtod(temporary_character_string);//4th column is percent
		return_struct.coverage = USHRT_MAX;//USHRT_MAX is higher coverage limit than I think a user could want
		return_struct.methylated_C = (unsigned)(PERCENT * return_struct.coverage);
	} else if (TYPE == 4) {//chr1	762	6	14
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//like chr21
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//like 43008720 = nucleotide
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);//export nucleotide to output struct
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//like 43008720 = nucleotide
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.methylated_C = (unsigned)safe_strtoul(temporary_character_string);//export nucleotide to output struct
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//like 43008720 = nucleotide
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.coverage = (unsigned)(return_struct.methylated_C + safe_strtoul(temporary_character_string));//export nucleotide to output struct;
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);
//		exit(EXIT_SUCCESS);
//		return_struct.methylated_C = (unsigned)(double)mC/return_struct.coverage;
//		printf("%u/%u = %f\n\n",return_struct.methylated_C,return_struct.coverage,return_struct.methylated_C);
//printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);
	} else if (TYPE == 5) {//<chromosome> <position> <strand> <count methylated> <count unmethylated> <C-context> <trinucleotide context> from Bismark
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column, chromosome
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column, position
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);
//		printf("%u\n\n",return_struct.nucleotide);//DEBUGGING
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 3rd column, sense
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 4th column, mC count
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.methylated_C = (unsigned)safe_strtoul(temporary_character_string);//assing string to unsigned integer
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 5th column, C count
		if (temporary_character_string == NULL) {
			printf("I couldn't get 5th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.coverage = return_struct.methylated_C + (unsigned)safe_strtoul(temporary_character_string);
		if (return_struct.coverage == 0) {
			return return_struct;
		}
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);//DEBUGGING
	} else if (TYPE == 6) {//chr1	762	763	0.265625	17	76
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column is chromosome
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column, position
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned int)safe_strtoul(temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//ignore the 2nd position (3rd column)
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 4th column, percent
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.methylated_C = (unsigned)safe_strtod(temporary_character_string);//4th column is percent
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 5th column, methylated C count
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.methylated_C = (unsigned int)safe_strtoul(temporary_character_string);
		if (temporary_character_string == NULL) {
			printf("I couldn't get 5th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 6th column, non-methylated C count
		if (temporary_character_string == NULL) {
			printf("I couldn't get 6th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.coverage = (unsigned)(return_struct.methylated_C + safe_strtoul(temporary_character_string));
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);
	} else if (TYPE == 7) {//return 7::tid chr pos m-score conf (HELP-Tag)
		return_struct.coverage = 100000;
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column, throw it away
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column, chromosome
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 3rd column, position
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned int)safe_strtoul(temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 4th column, m-score (methylation percent)
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
//		const double PERCENT = strtod(temporary_character_string,NULL) / 100.0;
//		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 5th column, confidence
//		return_struct.methylated_C = return_struct.coverage * PERCENT;
		return_struct.methylated_C = (unsigned)(safe_strtod(temporary_character_string) * return_struct.coverage / 100.0);
		if (return_struct.methylated_C > return_struct.coverage) {
			printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);
			exit(EXIT_FAILURE);
		}
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %zu	coverage = %zu\n\n", line, return_struct.chromosome, return_struct.nucleotide,  return_struct.methylated_C, return_struct.coverage);//DEBUGGING
//the 5th column isn't relevant so I'm not going to waste time with strtok_r again
	} else if (TYPE == 8) {//"chr1	3010874	3010876	'10/14'	714	+"
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column, position
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column, position 2
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		removeSubstring(temporary_character_string,"'");
		char *restrict str2 = NULL, *subtoken;
		str2 = temporary_character_string;
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		str2[strlen(str2)-1] = '\0';
		str2 = strtok_r(str2, "/", &subtoken);
		return_struct.methylated_C = (unsigned)safe_strtoul(str2);
		return_struct.coverage = (unsigned)safe_strtoul(subtoken);
//		return_struct.methylated_C = (double)METHYLATED_COUNT/return_struct.coverage;
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);
	} else if (TYPE == 9) {//10	60025	+	CG	25	26
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column, positioSn
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 3rd column, sense (not using it)
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 4th column, CpN type (not using it)
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 5th colum, number of methylated nucleotides
		if (temporary_character_string == NULL) {
			printf("I couldn't get 5th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.methylated_C = (unsigned)safe_strtoul(temporary_character_string);//convert string to unsigned integer
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 6th column, coverage
		if (temporary_character_string == NULL) {
			printf("I couldn't get 6th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.coverage = (unsigned)(return_struct.methylated_C + safe_strtoul(temporary_character_string));//convert string to unsigned integer (coverage)
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage);//debugging
	} else if (TYPE == 10) {//return 10:	chr1	10496	10497	79.69	64	+	10496	10497	180,60,0 (BisSNP), found in RnBeads
		temporary_character_string = strtok_r(bs_line_copy, "\t ",&saveptr);//1st column
		if (temporary_character_string == NULL) {
			printf("I couldn't get 1st column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(return_struct.chromosome, temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 2nd column, C of CpG
		if (temporary_character_string == NULL) {
			printf("I couldn't get 2nd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.nucleotide = (unsigned)safe_strtoul(temporary_character_string);
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 3rd column, nucleotide +1 (discard)
		if (temporary_character_string == NULL) {
			printf("I couldn't get 3rd column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 4th column = methylation percent
		if (temporary_character_string == NULL) {
			printf("I couldn't get 4th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		const double PERCENT = safe_strtod(temporary_character_string) / 100.0;//make 4th column into double data type
		temporary_character_string = strtok_r(NULL, "\t ",&saveptr);//get 5th column = coverage
		if (temporary_character_string == NULL) {
			printf("I couldn't get 5th column for the line \"%s\"	cf. %s line %u\n",line, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		return_struct.coverage = (unsigned)safe_strtoul(temporary_character_string);
		return_struct.methylated_C = (unsigned)(PERCENT * return_struct.coverage);
//		printf("%schromosome = %s	nucleotide = %u	methylated_C = %u	coverage = %u, percent = %lf\n\n", line, return_struct.chromosome, return_struct.nucleotide, return_struct.methylated_C, return_struct.coverage, PERCENT);//debugging
	} else {
		printf("TYPE %u is not defined @ %s line %u\n\n", TYPE, __FILE__, __LINE__);
		exit(EXIT_FAILURE);
	}
	free(bs_line_copy); bs_line_copy = NULL;
	return return_struct;
}

