#include <stdlib.h>
#include <stdio.h>

void * add_uint (unsigned int *restrict array, const unsigned int NUMBER, const unsigned int INDEX) {
	array = realloc(array, sizeof(unsigned int)*(1+INDEX));
	if (array == NULL) {
		perror("array failed to realloc.");
		exit(EXIT_FAILURE);
	}
	array[INDEX] = NUMBER;
	return array;
}

void * uint_clear (unsigned int *restrict array) {
	array = realloc(array, 0);
	return array;
}

void print_CpN_list(FILE *restrict fh, const unsigned int *restrict array, const unsigned int INDEX) {
	fprintf(fh, "\t%u", array[0]);
	for (unsigned int i = 1; i < INDEX; i++) {
		fprintf(fh, ",%u", array[i]);
	}
}
