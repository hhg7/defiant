grep -v omp.h defiant.c | grep -v omp_ | grep -v pragma | sed 's/char \*restrict argv/char * argv/g' > defiant_mac.c
