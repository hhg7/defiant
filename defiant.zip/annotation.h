#include <stdlib.h>
#include <stdio.h>
#define GNU_SOURCE
#include <stdbool.h>
#include <string.h>

void * add_name(char **restrict array, size_t *restrict size, unsigned int *restrict f_number_of_list_genes, const char *restrict NAME, const bool UNIQUE, const bool KEEP_NA) {//this function works, when freed inside main()
	if ((KEEP_NA == false) && (strcmp(NAME,"n/a") == 0)) {
		return array;
	}//don't bother with empty strings
//	printf("@line %u, adding %s to gene list array, with size %zu and %u elements.\n", __LINE__, NAME, *size, *f_number_of_list_genes);//debugging
	if (UNIQUE == true) {
		for (int name = (int)*f_number_of_list_genes-1; name >= 0; name--) {//if I count a gene twice, it is most likely from the front 
	//		printf("array[%u] = %s with %s\n",name, array[name], NAME);
			if (strcmp(array[name], NAME) == 0) {
				return array;//if this name is already in the list, don't add it
			}
		}
	}
	const size_t NAME_SIZE = strlen(NAME)*+2*sizeof(char*);
	*size += NAME_SIZE;
	array = realloc(array, *size);
	if (array == NULL) {
		fprintf(stderr, "realloc of array failed.\n");
		exit(EXIT_FAILURE);
	}
	array[*f_number_of_list_genes] = malloc(NAME_SIZE);
	if (array[*f_number_of_list_genes] == NULL) {
		fprintf(stderr, "alloc of array[%u] failed.\n", *f_number_of_list_genes);
		exit(EXIT_FAILURE);
	}
	strcpy(array[*f_number_of_list_genes], NAME);
	*f_number_of_list_genes += 1;
	return array;
}

void * clear_names(char **restrict array, size_t *restrict size, unsigned int *restrict number_of_annotated_genes) {//empty the list of names
	for (unsigned int name = 0; name < *number_of_annotated_genes; name++) {
		free(array[name]); array[name] = NULL;//this is missing something
		if (array[name] != NULL) {
			printf("free of array[%u] failed.\n", name);
		}
	}
	*number_of_annotated_genes = 0;
	*size = 1;
	array = realloc(array, *size);
	if (array == NULL) {
		fprintf(stderr, "realloc of array failed @ %s line %u\n", __FILE__, __LINE__);
		exit(EXIT_FAILURE);
	}
	return array;
}

void safe_string_copy ( char *restrict DESTINATION, const char *restrict SOURCE) {//to ensure no boundary violations
	strcpy(DESTINATION,SOURCE);//already ensures NULL terminator
	if (strcmp(DESTINATION,SOURCE) != 0) {
		fprintf(stderr, "%s doesn't match %s, strcpy failed.\n",DESTINATION,SOURCE);
		exit(EXIT_FAILURE);
	}
}
void removeSubstring(char *restrict s, const char *restrict toremove) {//remove a small string from a larger string
//http://stackoverflow.com/questions/4833347/removing-substring-from-a-string user411313
	while( s==strstr(s,toremove) ) {
		memmove(s,s+strlen(toremove),1+strlen(s+strlen(toremove)));
	}
}

unsigned short int get_annotation_type (const char *restrict line) {//determines file type of input, e.g. refFlat or Gencode GTF
//return 1: refFlat
//return 2: Gencode chr1	HAVANA	gene	11869	14409	.	+	.	gene_id "ENSG00000223972.5"; gene_type "transcribed_unprocessed_pseudogene"; gene_status "KNOWN"; gene_name "DDX11L1"; level 2; havana_gene "OTTHUMG00000000961.2";
	if (line[0] == '#') {
		return 0;//comment, assumes comments don't exist in refFlat (I don't see them)
	}
	if (strstr(line, "	Ensembl	chromosome	") != NULL) {
		return 0;
	}
//	printf("@ %s line %u\n", __FILE__, __LINE__);
	char *restrict line_copy = strdup(line);
	if (line_copy[strlen(line_copy)-2] == '\n') {
		line_copy[strlen(line_copy)-2] = '\0';//get rid of newline
	}
	char *restrict temporary_char_string,  *saveptr;//necessary for strtok_r
	temporary_char_string = strtok_r(line_copy, "\t ", &saveptr);
	unsigned short int number_of_columns = 1, strand_definition = 0;
//	bool column1_is_chr = false;

//	if ((number_of_columns == 1) && (strstr(temporary_char_string,"chr") != NULL)) {
//		column1_is_chr = true;
//	}
	while (temporary_char_string != NULL) {
		if ((temporary_char_string[0] == '-') || (temporary_char_string[0] == '+')) {
			strand_definition = number_of_columns;
		}
		temporary_char_string = strtok_r(NULL, "\t ", &saveptr);
		if (temporary_char_string == NULL) {
			break;
		}
		number_of_columns++;
	}
	free(line_copy); line_copy = NULL;
//	printf("strand definition = %u\n", strand_definition);
	if (strand_definition == 0) {
		fprintf(stderr, "strand_definition isn't defined @ %s line %u\n", __FILE__, __LINE__);
		fprintf(stderr, "This happened for %s\n", line);
		exit(EXIT_FAILURE);
	}
	if (strand_definition == 4) {
		return 1;//refFlat
	} else if (strand_definition == 7) {
		return 2;//GTF & GFF
	} else {
		fprintf(stderr, "Couldn't recognize annotation file format with strand_definition = %u @ %s line %u\n", strand_definition, __FILE__, __LINE__);
		exit(EXIT_FAILURE);
	}
}

typedef struct {
	char gene_name[256];//, transcript[48];//1,2, M, X, Y etc.
	unsigned int gene_start, gene_end;//, code_start, code_end;
//	unsigned short int number_of_exons;
	short int sense;//-1 or +1
	char chromosome[96];
} ANNOTATION_LINE_STRUCT;

ANNOTATION_LINE_STRUCT read_gene_annotation_line (const char *restrict line, const unsigned short int TYPE) {
	ANNOTATION_LINE_STRUCT gene;
	char *restrict copy_line = strdup(line);
	if (TYPE == 1) {//refFlat format
		char *restrict column, *column_pointer;
		column = strtok_r(copy_line,"\t ",&column_pointer);//http://stackoverflow.com/questions/15961253/c-correct-usage-of-strtok-r
		if (column == NULL) {//error checking
			fprintf(stderr, "1st column of annotation file is NULL for line %s @ %s line %u.\n",copy_line,__FILE__,__LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(gene.gene_name,column);
//		printf("@line %u	gene %s ID'd\n", __LINE__, gene.gene_name);
//2nd column: transcript
		column = strtok_r(NULL,"\t ",&column_pointer);
		if (column == NULL) {//error checking
			fprintf(stderr, "2nd column of annotation file is NULL for line %s @ %s line %u.\n",copy_line, __FILE__, __LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
//				strncpy(gene.transcript,column,sizeof(gene.transcript));
//3rd column: chromosome
		column = strtok_r(NULL,"\t ",&column_pointer);
		if (column == NULL) {//error checking
			fprintf(stderr, "3rd column of annotation file is NULL for line %s @ %s line %u.\n",copy_line,__FILE__,__LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
		removeSubstring(column,"chr");
		safe_string_copy(gene.chromosome, column);
//4th column: +/- sense
		column = strtok_r(NULL,"\t ",&column_pointer);
		if (column == NULL) {//error checking
			fprintf(stderr, "4th column of annotation file is NULL for line %s @ %s line %u.\n",copy_line,__FILE__,__LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
		gene.sense = 1;//1 if + sense, -1 if - sense
		if (strcmp(column,"-") == 0) {
			gene.sense = -1;
		}
//5th column: gene start
		column = strtok_r(NULL,"\t ",&column_pointer);
		if (column == NULL) {//error checking
			fprintf(stderr, "5th column of annotation file is NULL for line %s @ %s line %u.\n",copy_line,__FILE__,__LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
		gene.gene_start = (unsigned int)safe_strtoul(column);
//6th column: gene end
		column = strtok_r(NULL,"\t ",&column_pointer);
		if (column == NULL) {//error checking
			fprintf(stderr, "6th column of annotation file is NULL for line %s @ %s line %u.\n",copy_line,__FILE__,__LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
		const size_t STRING_LENGTH = strlen(column);
		if (column[STRING_LENGTH-1] == '\n') {
			column[STRING_LENGTH-1] = '\0';
		}
		gene.gene_end = (unsigned int)safe_strtoul(column);
	} else if (TYPE == 2) {//GTF format (GFF3)
//		printf("@ %s line %u\n", __FILE__, __LINE__);
		if (strstr(line,"#") != NULL) {
			free(copy_line); copy_line = NULL;
			gene.sense = 0;
			return gene;
		}/*
		if ((strstr(line,"gene_id") == NULL) && (strstr(line,"gene_name") == NULL)) {
			printf("%s has neither 'gene_id' nor 'gene_name' so I can't get a gene out of it.\n", line);
			printf("Failed at %s line %u\n", __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}*/
		char *restrict column, *column_pointer;
		column = strtok_r(copy_line,"\t ",&column_pointer);//http://stackoverflow.com/questions/15961253/c-correct-usage-of-strtok-r
		if (column == NULL) {//error checking
			fprintf(stderr, "1st column of annotation file is NULL for line %s @ %s line %u.\n",copy_line,__FILE__,__LINE__);
			exit(EXIT_FAILURE);
		}
/*		if (strstr(column,"_") != NULL) {
			free(copy_line); copy_line = NULL;
			gene.sense = 0;
			return gene;
		}
		if (strstr(column,"chr") == NULL) {//some 'chromosomes' look like GL000241.1
			free(copy_line); copy_line = NULL;
			gene.sense = 0;
			return gene;
		}*/
		removeSubstring(column,"chr");
		safe_string_copy(gene.chromosome, column);
//3rd column, "type", discard
		column = strtok_r(NULL,"\t ",&column_pointer);
		column = strtok_r(NULL,"\t ",&column_pointer);
//		printf("@ %s line %u\n", __FILE__, __LINE__);
		if (column == NULL) {//error checking
			fprintf(stderr, "3rd column of annotation file is NULL for line %s @ %s line %u.\n",copy_line, __FILE__, __LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
//4th column, "start", 
		column = strtok_r(NULL,"\t ",&column_pointer);
//		printf("@ %s line %u\n", __FILE__, __LINE__);
		if (column == NULL) {//error checking
			fprintf(stderr, "4th column of annotation file is NULL for line %s @ %s line %u.\n",copy_line, __FILE__, __LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
		gene.gene_start = (unsigned int)safe_strtoul(column);//4th col, gene start
//		printf("@ %s line %u\n", __FILE__, __LINE__);
//5th column, end
		column = strtok_r(NULL,"\t ",&column_pointer);
//		printf("@ %s line %u\n", __FILE__, __LINE__);
		if (column == NULL) {//error checking
			fprintf(stderr, "5th column of annotation file is NULL for line %s @ %s line %u.\n",copy_line,__FILE__,__LINE__);//DEBUGGING
			exit(EXIT_FAILURE);
		}
		gene.gene_end = (unsigned)safe_strtoul(column);//5th col, gene end
		column = strtok_r(NULL,"\t ",&column_pointer);//6th col, score, discard
		column = strtok_r(NULL,"\t ",&column_pointer);//7th col, sense
		if (strcmp(column, "-") == 0) {
			gene.sense = -1;
		} else {
			gene.sense = 1;//1 if + sense, -1 if - sense
		}
		column = strtok_r(NULL,"\t ",&column_pointer);//8th col, frame, discard
		column = strtok_r(NULL,"\t ",&column_pointer);//9th frame, attribute
		column = strtok_r(NULL,"\t ", &column_pointer);//10th frame
		column = strtok_r(NULL,"\t ", &column_pointer);//11th frame
		column = strtok_r(NULL,"\t ", &column_pointer);//12th frame
		column = strtok_r(NULL,"\t ", &column_pointer);//13th frame
		column = strtok_r(NULL,"\t ", &column_pointer);//14th frame
		removeSubstring(column, "\"");
		const size_t STRLEN = strlen(column);
		if (column[STRLEN-1] == '\n') {
			column[STRLEN-1] = '\0';//get rid of newline
		}
		if (strstr(column, "\";") != 0) {
			column[STRLEN-2] = '\0';
		}
//		printf("@ %s line %u\n", __FILE__, __LINE__);
		safe_string_copy(gene.gene_name, column);
//		printf("@ %s line %u\n", __FILE__, __LINE__);
//create a list of column elements
/*		unsigned int number_of_columns = 0;
		size_t column_list_size = strlen(column) + 1;
		char **restrict column_list = NULL;
		column_list = malloc(column_list_size);
		int gene_id_index = -1, gene_name_index = -1;//-1 means not yet defined
		while (column != NULL) {
			if (strcmp("gene_id",column) == 0) {
				gene_id_index = (int)number_of_columns;
			} else if (strcmp("gene_name",column) == 0) {
				gene_name_index = (int)number_of_columns;
			}
			column_list = add_name(column_list, &column_list_size, &number_of_columns, column, false, true);
	//		printf("%s => column_list[%u]\n", column, number_of_columns-1);
//ABSOLUTELY **NOTHING** MORE IN THIS LOOP AFTER THE FOLLOWING COMMAND
			column = strtok_r(NULL," \t",&column_pointer);
		}
		if ((long)number_of_columns == (long)gene_id_index) {//prevents segmentation fault
			printf("a line ended with 'gene_id', so I don't know what the gene_id is @ %s line %u\n", __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		} else if ((long)number_of_columns == (long)gene_name_index) {
			printf("a line ended with 'gene_name', so I dont know what the gene name is @ %s line %u\n", __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		safe_string_copy(gene.chromosome, column_list[0]);
		gene.gene_start = (unsigned)safe_strtoul(column_list[3]);
		gene.gene_end = (unsigned)safe_strtoul(column_list[4]);
		if (strcmp(column_list[6],"-") == 0) {
			gene.sense = -1;
		} else if (strcmp(column_list[6],"+") == 0) {
			gene.sense = 1;
		} else {
			printf("sense %s is neither '+' nor '-' @ %s %u\n", column_list[6], __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		}
		if (gene_name_index > 0) {//i.e. Gencode25 GTF
			char *restrict gene_name, *gene_pointer;
			gene_name = strtok_r(column_list[gene_name_index+1],"\t ;\"",&gene_pointer);
			safe_string_copy(gene.gene_name, gene_name);
		} else if (gene_id_index > 0) {//i.e. mm9 GTF
			char *restrict gene_name, *gene_pointer;
			gene_name = strtok_r(column_list[gene_id_index+1],"\t ;\"",&gene_pointer);
			safe_string_copy(gene.gene_name, gene_name);
		} else {
			printf("Failed to find either gene_name or gene_id for %s @ %s line %u\n",line,__FILE__,__LINE__);
			exit(EXIT_FAILURE);
		}
		column_list = clear_names(column_list, &column_list_size, &number_of_columns);
		free(column_list); column_list = NULL;*/
	} else {
		free(copy_line); copy_line = NULL;
		fprintf(stderr, "I got a type = %u, which is not a recognized type. This is @ %s line %u\n", TYPE,__FILE__, __LINE__);
		exit(EXIT_FAILURE);
	}
	free(copy_line); copy_line = NULL;
	return gene;
}

