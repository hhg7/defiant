#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

const double safe_strtod(const char *restrict str) {
	char *endptr;
	const double value = strtod(str, &endptr);
	if (*endptr) {
		printf("The string '%s' failed to convert to a double precision floating point.\n", str);
		exit(EXIT_FAILURE);
	}
	return value;
}//slightly modified from mousio on http://stackoverflow.com/questions/5601537/converting-a-string-to-double/5601559#5601559
