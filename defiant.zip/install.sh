gcc -O4 -o defiant defiant.c -Wall -pedantic -std=gnu11  -lm -fopenmp
echo "defiant has been successfully installed!"
echo "Defiant is accessable with the executable \"defiant\""
echo "Please read defiant_manual.pdf"
