#include <stdlib.h>
#include <stdio.h>

void *restrict add_double (double *restrict array, const double NUMBER, const unsigned int INDEX) {
	array = realloc(array, sizeof(double)*(1+INDEX));
	if (array == NULL) {
		perror("array failed to realloc.");
		exit(EXIT_FAILURE);
	}
	array[INDEX] = NUMBER;
	return array;
}

void *restrict double_clear (double *restrict array) {
	array = realloc(array, 0);
	return array;
}

void print_double_CpN_list(FILE *restrict fh, const double *restrict array, const unsigned int INDEX) {
	fprintf(fh, "\t%g", array[0]);
	for (unsigned int i = 1; i < INDEX; i++) {
		fprintf(fh, ",%g", array[i]);
	}
}
