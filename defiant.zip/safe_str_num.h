#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const double safe_strtod(const char *restrict STRING) {
	char *endptr;
	const double VALUE = strtod(STRING, &endptr);
	if (*endptr) {
		printf("The string '%s' failed to convert to a double precision floating point @ %s line %u.\n", STRING, __FILE__, __LINE__);
		perror("");
		exit(EXIT_FAILURE);
	}
	return VALUE;
}//slightly modified from mousio on http://stackoverflow.com/questions/5601537/converting-a-string-to-double/5601559#5601559

const unsigned long int safe_strtoul (const char *restrict STRING) {
	if (STRING[0] == '-') {
		printf("Negative numbers like '%s' can't be fed to unsigned integers @ %s line %u.\n", STRING, __FILE__, __LINE__);
	}
	char *endptr;
	const double VALUE = strtoul(STRING, &endptr, 0);
	if (*endptr) {
		printf("The string '%s' failed to convert to a unsigned integer @ %s line %u.\n", STRING, __FILE__, __LINE__);
		perror("");
		exit(EXIT_FAILURE);
	}
	return VALUE;
}
