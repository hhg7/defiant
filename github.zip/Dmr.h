#include <math.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

bool print_all_nucleotides = false;

typedef struct {//store nucleotide information
	unsigned int nucleotide, methylated_C, coverage;
} BISULFITE_DATA_STRUCT;

typedef struct {
	size_t methylated_C, coverage;
} DMR_struct;

void print_methylation_percentages (DMR_struct **restrict dmr, const unsigned short int *restrict NO_OF_REPLICATES, FILE *restrict answers_filehandle) {
//this assumes coverages are all > 0
	for (unsigned short int set_loop = 0; set_loop < 2; set_loop++) {
		fprintf(answers_filehandle,"\t[%.1f",100.0*(double)dmr[set_loop][0].methylated_C / dmr[set_loop][0].coverage);
		for (unsigned short int r = 1; r < NO_OF_REPLICATES[set_loop]; r++) {
			fprintf(answers_filehandle,",%.1f",100.0*(double)dmr[set_loop][r].methylated_C / dmr[set_loop][r].coverage);
		}
		fprintf(answers_filehandle,"]");
	}
}

void Rprint_methylation_percentages (DMR_struct **restrict dmr, const unsigned short int *restrict NO_OF_REPLICATES, FILE *restrict r, const unsigned short int SET) {
	bool first = true;
	for (unsigned int replicate = 0; replicate < NO_OF_REPLICATES[SET]; replicate++) {
		if (dmr[SET][replicate].coverage > 0) {
			if (first == true) {//first will not have comma
				fprintf(r,"%zu/%zu",dmr[SET][replicate].methylated_C, dmr[SET][replicate].coverage);
				first = false;
			} else {
				fprintf(r,",%zu/%zu", dmr[SET][replicate].methylated_C, dmr[SET][replicate].coverage);
			}
		}
	}
}

const double single_set_DMR_mean (DMR_struct **restrict DMR, const unsigned short int *restrict NO_OF_REPLICATES, const unsigned short int SET) {
	size_t methylated_C_sum = 0, coverage_sum = 0;
	for (unsigned int replicate = 0; replicate < NO_OF_REPLICATES[SET]; replicate++) {
//		if (DMR[SET][replicate].methylated_C > DMR[SET][replicate].coverage) {
//			printf("@line %u	methylated_C = %zu > coverage = %zu, not possible.\n", __LINE__, DMR[SET][replicate].methylated_C, DMR[SET][replicate].coverage);
//			exit(EXIT_FAILURE);
//		}
		if (DMR[SET][replicate].coverage > 0) {
			methylated_C_sum += DMR[SET][replicate].methylated_C;
			coverage_sum += DMR[SET][replicate].coverage;
		}
	}
	if (coverage_sum == 0) {
		printf("@ file %s line %u you tried to divide by 0 when taking a set mean.\n", __FILE__, __LINE__);
		exit(EXIT_FAILURE);
	}
	return (double) methylated_C_sum / coverage_sum;
}

const unsigned int coverage_sum (DMR_struct **restrict dmr, const unsigned short int *restrict NO_OF_REPLICATES, const unsigned short int SET) {
	unsigned int sum_coverage = 0;
	for (unsigned int replicate = 0; replicate < NO_OF_REPLICATES[SET]; replicate++) {
		if (dmr[SET][replicate].coverage > 0) {
			sum_coverage++;
		}
	}
	return sum_coverage;
}

const double Pvalue (DMR_struct **restrict dmr, const unsigned short int *restrict NO_OF_REPLICATES, const double MAX_P_VALUE, double *restrict min_DOF, double *restrict min_WELCH_T, const bool EXACT_P_VALUE) {//calculate a p-value based on an array
	size_t methylated_C_1 = 0, methylated_C_2 = 0, coverage1 = 0, coverage2 = 0;
	for (unsigned short int replicate = 0; replicate < NO_OF_REPLICATES[0]; replicate++) {
		methylated_C_1 += dmr[0][replicate].methylated_C;
		coverage1 += dmr[0][replicate].coverage;
	}
	for (unsigned short int replicate = 0; replicate < NO_OF_REPLICATES[1]; replicate++) {
		methylated_C_2 += dmr[1][replicate].methylated_C;
		coverage2 += dmr[1][replicate].coverage;
	}
	if ((NO_OF_REPLICATES[0] == 1) || (NO_OF_REPLICATES[1] == 1)) {//Fisher's exact test
//		printf("A = %u	B = %u	C = %u	D = %u, coverage1 = %u,	coverage2 = %u\n", A, B, C, D, coverage1, coverage2);
		return expl(lgammal(methylated_C_1+methylated_C_2+1) + lgammal(coverage1 - methylated_C_1+coverage2 - methylated_C_2+1) + lgammal(coverage1+1) + lgammal(coverage2+1) - lgammal(methylated_C_1+1) - lgammal(methylated_C_2+1) - lgammal(coverage1 - methylated_C_1+1) - lgammal(coverage2 - methylated_C_2+1) - lgammal(coverage1 + coverage2 +1));
	}
	const double FMEAN1 = (double)methylated_C_1 / coverage1, FMEAN2 = (double)methylated_C_2 / coverage2;
//	printf("mean1 = %g\tmean2 = %g\n", FMEAN1, FMEAN2);
//	printf("mean1 = %lf\tmean2 = %lf\n", FMEAN1, FMEAN2);//DEBUGGING
	if (FMEAN1 == FMEAN2) {
		return 1.0;//if the means are equal, the p-value is 1, leave the function
	}
	double unbiased_sample_variance1 = 0.0, unbiased_sample_variance2 = 0.0;
	for (unsigned short int replicate = 0; replicate < NO_OF_REPLICATES[0]; replicate++) {//1st part of added unbiased_sample_variance
		unbiased_sample_variance1 += ((double)dmr[0][replicate].methylated_C/dmr[0][replicate].coverage-FMEAN1)*((double)dmr[0][replicate].methylated_C/dmr[0][replicate].coverage-FMEAN1)*dmr[0][replicate].coverage;
	}
	for (unsigned short int replicate = 0; replicate < NO_OF_REPLICATES[1]; replicate++) {
		unbiased_sample_variance2 += ((double)dmr[1][replicate].methylated_C/dmr[1][replicate].coverage-FMEAN2)*((double)dmr[1][replicate].methylated_C/dmr[1][replicate].coverage-FMEAN2)*dmr[1][replicate].coverage;
	}
//	printf("unbiased_sample_variance1 = %lf\tunbiased_sample_variance2 = %lf\n",unbiased_sample_variance1,unbiased_sample_variance2);//DEBUGGING
	unbiased_sample_variance1 = unbiased_sample_variance1/(coverage1-1);
	unbiased_sample_variance2 = unbiased_sample_variance2/(coverage2-1);
	const double WELCH_T_STATISTIC = (FMEAN1-FMEAN2)/sqrt(unbiased_sample_variance1/NO_OF_REPLICATES[0]+unbiased_sample_variance2/NO_OF_REPLICATES[1]);
	const double DEGREES_OF_FREEDOM = pow((unbiased_sample_variance1/NO_OF_REPLICATES[0]+unbiased_sample_variance2/NO_OF_REPLICATES[1]),2.0)//numerator
	 /
	(
		(unbiased_sample_variance1*unbiased_sample_variance1)/(NO_OF_REPLICATES[0]*NO_OF_REPLICATES[0]*(NO_OF_REPLICATES[0]-1))+
		(unbiased_sample_variance2*unbiased_sample_variance2)/(NO_OF_REPLICATES[1]*NO_OF_REPLICATES[1]*(NO_OF_REPLICATES[1]-1))
	);
	if ((print_all_nucleotides == false) && (DEGREES_OF_FREEDOM < *min_DOF) && (fabs(WELCH_T_STATISTIC) < *min_WELCH_T)) {
		return 1.0;
	}
	const double a = DEGREES_OF_FREEDOM/2, x = DEGREES_OF_FREEDOM/(WELCH_T_STATISTIC*WELCH_T_STATISTIC+DEGREES_OF_FREEDOM);
	const unsigned short int N = 199;//increase N for a tighter convergence
	const double h = x/N;//necessary for integrating with Simpson's method
	double sum1 = 0.0, sum2 = 0.0;
	for(unsigned short int i = 1;i < N+1; i++) {//integrate by Simpson's method (sometimes blows up at i = 0, so I start @ 1
		sum1 += (pow(h * i + h / 2.0,a-1))/(sqrt(1-(h * i + h / 2.0)));
		sum2 += (pow(h * i,a-1))/(sqrt(1-h * i));
	}
	const double p_value = ((h / 6.0) * ((pow(x,a-1))/(sqrt(1-x)) + 4.0 * sum1 + 2.0 * sum2))/(exp(lgammal(a)+0.57236494292470009-lgammal(a+0.5)));//0.5723649... is lgammal(0.5)
	if ((EXACT_P_VALUE == false) && (p_value > MAX_P_VALUE) && (DEGREES_OF_FREEDOM > *min_DOF) && (WELCH_T_STATISTIC > *min_WELCH_T)) {
		*min_DOF = DEGREES_OF_FREEDOM;
		*min_WELCH_T = WELCH_T_STATISTIC;
//		printf("%lf	%lf	%lf\n",WELCH_T_STATISTIC,DEGREES_OF_FREEDOM,return_value);
		return 1.0;
	}
//	printf("zzz%lf	%lf	%lf\n",WELCH_T_STATISTIC, DEGREES_OF_FREEDOM, return_value);
	if ((isinf(p_value) != 0) || (isnan(p_value) != 0) || (p_value > 1.0)) {
		return 1.0;
	} else {
		return p_value;
	}
}

void zero_DMR_struct (DMR_struct **restrict dmr, const unsigned short int *restrict NO_OF_REPLICATES) {
	for (unsigned short int set = 0; set < 2; set++) {
		for (unsigned int replicate = 0; replicate < NO_OF_REPLICATES[set]; replicate++) {
			dmr[set][replicate].methylated_C = 0;
			dmr[set][replicate].coverage = 0;
		}
	}
}

typedef struct {//this allows me to keep RAM use down by saving chromosome changes instead of chromosome for each line read
	size_t index;
	char chromosome[3];
} CHROMOSOME_CHANGES_STRUCT;

typedef struct {
	char gene_name[48];
	unsigned int gene_start, gene_end;
	short int sense;//-1 or +1
} GENES_STRUCT;


/*(void print_DMR_struct ( DMR_struct **restrict dmr, const unsigned short int *restrict NO_OF_REPLICATES) {
	for (unsigned short int set = 0; set < 2; set++) {
		for (unsigned int replicate = 0; replicate < NO_OF_REPLICATES[set]; replicate++) {
			printf("dmr[%u][%u].methylated_C = %zu	dmr[%u][%u].coverage = %zu\n", set, replicate, dmr[set][replicate].methylated_C, set, replicate, dmr[set][replicate].coverage);
		}
	}
}*/


const double mean_percent_difference (DMR_struct **restrict DMR, const unsigned short int *restrict NO_OF_REPLICATES) {
	size_t methylated_C_sum[] = {0,0};
	size_t coverage_sum[] = {0,0};
	for (unsigned short int set = 0; set < 2; set++) {
		for (unsigned int replicate = 0; replicate < NO_OF_REPLICATES[set]; replicate++) {
/*			if (DMR[set][replicate].methylated_C > DMR[set][replicate].coverage) {
				printf("@line %u	methylated_C = %zu > coverage = %zu, not possible.\n", __LINE__, DMR[set][replicate].methylated_C, DMR[set][replicate].coverage);
				exit(EXIT_FAILURE);
			}*/
			methylated_C_sum[set] += DMR[set][replicate].methylated_C;
			coverage_sum[set] += DMR[set][replicate].coverage;
		}
	}
	if ((coverage_sum[0] == 0) || (coverage_sum[1] == 0)) {
		return 0;//actually undefined
	}
	return (double)((double)methylated_C_sum[1]/coverage_sum[1] - (double)methylated_C_sum[0]/coverage_sum[0]);
}

unsigned int promoter_cutoff = 10000;//used in assigning
unsigned short int number_of_chromosomes_in_GENES = 0;//declared outside main so I can use it in functions
GENES_STRUCT *restrict GENES = 0;//declare struct to hold gene data
CHROMOSOME_CHANGES_STRUCT *restrict gene_chromosome_changes = NULL;//declared outside main so I can use it in functions
unsigned int GENES_chromosome_change_index = 0, number_of_annotated_genes = 0;
bool gene_annotation_defined = false, printing_CpN_list = false;

void identify_gene (const unsigned int NUCLEOTIDE, const bool START, char *restrict gene_string, const unsigned short int GENE_STRING_LENGTH, char *restrict intergene_string, const unsigned short int INTERGENE_STRING_LENGTH, char *restrict list_gene, const unsigned short int LIST_LENGTH, unsigned int *restrict min_gene_search_index, unsigned int *restrict max_gene_search_index, unsigned int *restrict intergenic_start_nucleotide, unsigned int *restrict intergenic_end_nucleotide, unsigned int first_nucleotide) {//given nucleotide and globally accessed lists, how can I identify this nucleotide's genomic region?
//	printf("@line %u	nucleotide = %u\n", __LINE__, NUCLEOTIDE);
	if (*min_gene_search_index > *max_gene_search_index) {
		*min_gene_search_index = 0;
		*max_gene_search_index = number_of_annotated_genes;
	}
	if (*max_gene_search_index > number_of_annotated_genes) {
		*max_gene_search_index = number_of_annotated_genes;
	}
	if (*min_gene_search_index == *max_gene_search_index) {
		printf("*min_gene_search_index = *max_gene_search_index = %u\n", *min_gene_search_index);
		exit(EXIT_FAILURE);
	}
//	printf("@line %u searching gene indices	%u-%u\n",__LINE__, *min_gene_search_index,*max_gene_search_index);
	if (NUCLEOTIDE < first_nucleotide) {//is this nucleotide in the beginning of the chromosome?
		sprintf(intergene_string,"Chr%s_Start-%u-%s",gene_chromosome_changes[GENES_chromosome_change_index].chromosome,GENES[*min_gene_search_index].gene_start - NUCLEOTIDE, GENES[*min_gene_search_index].gene_name);
		if ((GENES[*min_gene_search_index].sense == 1) && ((GENES[*min_gene_search_index].gene_start - NUCLEOTIDE) < promoter_cutoff)) {
			safe_string_copy(list_gene, GENES[*min_gene_search_index].gene_name);
			list_gene[strlen(GENES[*min_gene_search_index].gene_name)] = '\0';
		}
	} else if (NUCLEOTIDE > GENES[*max_gene_search_index].gene_end) {//is this nucleotide in the end of the chromosome?
		sprintf(intergene_string,"%s-%u-End_Chr%s",GENES[*max_gene_search_index].gene_name,NUCLEOTIDE-GENES[*max_gene_search_index].gene_end, gene_chromosome_changes[GENES_chromosome_change_index].chromosome);
		if ((GENES[*max_gene_search_index].sense == -1) && ((NUCLEOTIDE-GENES[*max_gene_search_index].gene_end) < promoter_cutoff)) {
			safe_string_copy(list_gene, GENES[*max_gene_search_index].gene_name);
		}
	}
	for (size_t i = *min_gene_search_index; i <= *max_gene_search_index; i++) {
//printf("@line %u	i = %zu of possible %u\n", __LINE__, i, *max_gene_search_index);
		if ((GENES[i].gene_start <= NUCLEOTIDE) && (NUCLEOTIDE <= GENES[i].gene_end)) {//is this nucleotide in this gene?
//			printf("Nucleotide %u <= %u <= %u is inside %s\n",GENES[i].gene_start, GENES[i].gene_end, NUCLEOTIDE, GENES[i].gene_name);
			safe_string_copy(gene_string, GENES[i].gene_name);
			gene_string[strlen(GENES[i].gene_name)] = '\0';
			safe_string_copy(list_gene, GENES[i].gene_name);
			list_gene[strlen(GENES[i].gene_name)] = '\0';
			*min_gene_search_index = i;
		} else if ((i < *max_gene_search_index) && (GENES[i].gene_end < NUCLEOTIDE) && (NUCLEOTIDE < GENES[i+1].gene_start)) {//intergenic
			if (START == true) {//*intergenic_start_nucleotide only changes after ending DMRs and finding new DMRs
				*intergenic_start_nucleotide = (NUCLEOTIDE - GENES[i].gene_end);
			} else {//i.e. START == false
				*intergenic_end_nucleotide = (GENES[i+1].gene_start - NUCLEOTIDE);
			}
//			printf("@line %u	nucleotide = %u	START\n", __LINE__, NUCLEOTIDE);
			sprintf(intergene_string,"%s-%u,%u-%s",GENES[i].gene_name, *intergenic_start_nucleotide, *intergenic_end_nucleotide,GENES[i+1].gene_name);
			if ((GENES[i].sense == -1) && (*intergenic_start_nucleotide <= promoter_cutoff)) {//the gene is transcribed 3'-5', and within promoter cutoff
				safe_string_copy(list_gene, GENES[i].gene_name);
				list_gene[strlen(GENES[i].gene_name)] = '\0';
			}
			if ((GENES[i+1].sense == 1) && (*intergenic_end_nucleotide <= promoter_cutoff)) {//the gene is transcribed 3'-5', and within promoter cutoff
				safe_string_copy(list_gene, GENES[i+1].gene_name);
				list_gene[strlen(GENES[i+1].gene_name)] = '\0';
			}
		} else if (NUCLEOTIDE < GENES[i].gene_start) {//I've passed what this gene can possibly be
//			printf("at i = %zu:\t%zu > %u -> %s is the last gene examined.\n",i,NUCLEOTIDE,GENES[i].gene_end,GENES[i].gene_name);
			return;
		}
	}
	if ((strcmp(gene_string,"-") == 0) && (strcmp(intergene_string,"-") == 0)) {// && (strcmp(transcripts,"-") == 0) ) {
		printf("Chromosome %s Nucleotide %u failed to identify.\n",gene_chromosome_changes[GENES_chromosome_change_index].chromosome,NUCLEOTIDE);
		exit(EXIT_FAILURE);
	}
}

void add_2nd_dmr_to_1st_dmr(DMR_struct **restrict dmr1, DMR_struct **restrict dmr2, const unsigned short int *restrict NO_OF_REPLICATES) {
//this function assumes the array dimensions are identical
	for (unsigned short int set= 0; set < 2; set++) {
		for (unsigned short int r = 0; r < NO_OF_REPLICATES[set]; r++) {
//			if (dmr1[set][r].methylated_C > dmr1[set][r].coverage) {
//				printf("@line %u, methylated_C = %zu > coverage = %zu, which isn't possible.\n",__LINE__,dmr1[set][r].methylated_C,dmr1[set][r].coverage);
//				exit(EXIT_FAILURE);
//			}
//			if (dmr2[set][r].methylated_C > dmr2[set][r].coverage) {
//				printf("@line %u, methylated_C = %zu > coverage = %zu, which isn't possible.\n",__LINE__,dmr1[set][r].methylated_C,dmr1[set][r].coverage);
//				exit(EXIT_FAILURE);
//			}
			dmr1[set][r].methylated_C += dmr2[set][r].methylated_C;
			dmr1[set][r].coverage += dmr2[set][r].coverage;
		}
	}
}

void subtract_2nd_dmr_from_1st_dmr(DMR_struct **restrict dmr1, DMR_struct **restrict dmr2, const unsigned short int *restrict NO_OF_REPLICATES, const unsigned int LINE) {
//this function assumes the array dimensions are identical
	for (unsigned short int set = 0; set < 2; set++) {
		for (unsigned short int replicate = 0; replicate < NO_OF_REPLICATES[set]; replicate++) {
//			if (dmr1[set][replicate].methylated_C < dmr2[set][replicate].methylated_C) {
//				printf("%zu - %zu	Вниманиe! subtracting a large unsigned integer from a small unsigned integer will give an unsigned integer a negative value @line %u. :,(\n", dmr1[set][replicate].methylated_C, dmr2[set][replicate].methylated_C, LINE);
//				exit(EXIT_FAILURE);
//			}
//			if (dmr1[set][replicate].methylated_C > dmr1[set][replicate].coverage) {
//				printf("@line %u, methylated_C = %zu > coverage = %zu, which isn't possible.\n",__LINE__,dmr1[set][replicate].methylated_C,dmr1[set][replicate].coverage);
//				exit(EXIT_FAILURE);
//			}
			dmr1[set][replicate].methylated_C -= dmr2[set][replicate].methylated_C;
			dmr1[set][replicate].coverage -= dmr2[set][replicate].coverage;
		}
	}
}

