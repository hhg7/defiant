gcc  -o defiant defiant.c   -Wall -pedantic -std=gnu11  -lm -fopenmp
