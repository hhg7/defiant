#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define GNU_SOURCE
#include <stdbool.h>

typedef struct {
	double min, max, step;
} option_range_struct;

typedef struct {
	unsigned int coverage, skip, CpN;
	unsigned int number_of_DMRs;
	double p, percent;
} cutoff_struct;

const short int ZERO_STEPS = 7;

option_range_struct get_option_range (const char *restrict STRING) {
	option_range_struct return_struct;
	if (strstr(STRING,",") == NULL) {
		return_struct.step = ZERO_STEPS;
		return_struct.min = safe_strtod(STRING);
		return_struct.max = safe_strtod(STRING);
		return return_struct;
	}
	char *restrict copy_string = malloc(1+sizeof(char)*strlen(STRING));
	strcpy(copy_string, STRING);
	char *restrict string, *string_pointer;
	string = strtok_r(copy_string, ",", &string_pointer);
//
	return_struct.min = safe_strtod(string);
	string = strtok_r(NULL, ",", &string_pointer);

	return_struct.max = safe_strtod(string);
	string = strtok_r(NULL, ",", &string_pointer);
	if (string == NULL) {//i.e., the string ends here
		free(copy_string); copy_string = NULL;
		if (return_struct.max < return_struct.min) {
			const double TMP = return_struct.max;
			return_struct.max = return_struct.min;
			return_struct.min = TMP;
		}
		return_struct.step = return_struct.max - return_struct.min;
		return return_struct;
	}

	return_struct.step = safe_strtod(string);
	free(copy_string); copy_string = NULL;
	if (return_struct.max < return_struct.min) {
		const double TMP = return_struct.max;
		return_struct.max = return_struct.min;
		return_struct.min = TMP;
	}
	return return_struct;
}

int cmpfunc (const void *restrict a, const void *restrict b) {
   return ( *(int *restrict)a - *(int *restrict)b );
}

int double_cmpfunc (const void *restrict a, const void *restrict b) {
   return ( *(double *restrict)a - *(double *restrict)b );
}

unsigned int how_many_uint_array_elements (const unsigned int DEFAULT, const option_range_struct RANGE) {
	if ((RANGE.min == RANGE.max) ) {
		if (RANGE.min == DEFAULT) {
			return 1;
		} else {//will return the value and the default
			return 2;
		}
	}
	unsigned int NUMBER_OF_ARRAY_ELEMENTS = 0;
	bool defaults_present = 0;
	for (unsigned int c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		NUMBER_OF_ARRAY_ELEMENTS++;
		if (c == DEFAULT) {
			defaults_present = 1;
		}
	}
	if (defaults_present == 0) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	return NUMBER_OF_ARRAY_ELEMENTS;
}

unsigned int how_many_double_array_elements (const double DEFAULT, const option_range_struct RANGE) {
	if (RANGE.min == RANGE.max) {
		if (RANGE.min == DEFAULT) {
			return 1;
		} else {//will return the value and the default
			return 2;
		}
	}
	bool defaults_present = 0;
	unsigned int NUMBER_OF_ARRAY_ELEMENTS = 0;
	for (double c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		NUMBER_OF_ARRAY_ELEMENTS++;
		if (c == DEFAULT) {
			defaults_present = 1;
		}
	}
	if (defaults_present == 0) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	return NUMBER_OF_ARRAY_ELEMENTS;
}

void *restrict uint_array_alloc (const unsigned int DEFAULT, const option_range_struct RANGE) {
	if (RANGE.min == RANGE.max) {
		unsigned int *restrict array = NULL;
		if (RANGE.min == DEFAULT) {
			array = malloc(sizeof(unsigned int));
			array[0] = DEFAULT;
		} else {
			array = malloc(sizeof(unsigned int)*2);
			array[0] = DEFAULT;
			array[1] = RANGE.max;//could also use range.max
			qsort(array, 2, sizeof(unsigned int), cmpfunc);//sorting helps the final table look better
		}
		return array;
	}
	bool defaults_present = 0;
	unsigned int index = 0;
	for (unsigned int c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		if (c == DEFAULT) {
			defaults_present = 1;
		}
		index++;
	}

	unsigned int NUMBER_OF_ARRAY_ELEMENTS = index;
	if (defaults_present == 0) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	unsigned int *restrict array = malloc(sizeof(unsigned int)*NUMBER_OF_ARRAY_ELEMENTS);
	index = 0;
	for (unsigned int c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		array[index] = c;
		index++;
	}
	if (defaults_present == 0) {
		array[index] = DEFAULT;
	}
	qsort(array, NUMBER_OF_ARRAY_ELEMENTS, sizeof(unsigned int), double_cmpfunc);//sorting helps the final table look better
	return array;
}

void *restrict double_array_alloc (const double DEFAULT, const option_range_struct RANGE) {
	if (RANGE.min == RANGE.max) {
		double *restrict array = NULL;
		if (RANGE.min == DEFAULT) {
			array = malloc(sizeof(double));
			array[0] = DEFAULT;
		} else {
			array = malloc(sizeof(double)*2);
			array[0] = DEFAULT;
			array[1] = RANGE.max;//could also use range.max
			qsort(array, 2, sizeof(double), cmpfunc);//sorting helps the final table look better
		}
		return array;
	}
	bool defaults_present = 0;
	unsigned int index = 0;
	for (double c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		index++;
		if (c == DEFAULT) {
			defaults_present = 1;
		}
	}
	size_t NUMBER_OF_ARRAY_ELEMENTS = index;
	if (defaults_present == 0) {
		NUMBER_OF_ARRAY_ELEMENTS++;
	}
	double *restrict array = malloc(sizeof(double)*NUMBER_OF_ARRAY_ELEMENTS);
	index = 0;
	for (double c = RANGE.min; c <= RANGE.max; c += RANGE.step) {
		array[index] = c;
		index++;
	}
	if (defaults_present == 0) {
		array[index] = DEFAULT;
	}
	qsort(array, NUMBER_OF_ARRAY_ELEMENTS, sizeof(double), double_cmpfunc);//sorting helps the final table look better
	return array;
}

const unsigned int how_many_runs (const option_range_struct coverage, const option_range_struct CpN, const option_range_struct p, const option_range_struct percent, const option_range_struct skip, const cutoff_struct defaults, const unsigned short int ALLOWED_NON_DEFAULTS) {
	const unsigned int COVERAGE_ITERATIONS = how_many_uint_array_elements(defaults.coverage, coverage);
	const unsigned int CPN_ITERATIONS = how_many_uint_array_elements(defaults.CpN, CpN);
	const unsigned int P_ITERATIONS = how_many_double_array_elements(defaults.p, p);
	const unsigned int PERCENT_ITERATIONS = how_many_double_array_elements(defaults.percent, percent);
	const unsigned int SKIP_ITERATIONS = how_many_uint_array_elements(defaults.skip, skip);
	unsigned int *restrict cpn_array = uint_array_alloc(defaults.CpN, CpN);
	unsigned int *restrict coverage_array = uint_array_alloc(defaults.coverage, coverage);
	double *restrict p_array = double_array_alloc(defaults.p, p);
	double *restrict percent_array = double_array_alloc(defaults.percent, percent);
	unsigned int *restrict skip_array = uint_array_alloc(defaults.skip, skip);
	unsigned int runs = 0;
	for (unsigned int c = 0; c < COVERAGE_ITERATIONS; c++) {
		for (unsigned int CpG = 0; CpG < CPN_ITERATIONS; CpG++) {
			for (unsigned int pvalue = 0; pvalue < P_ITERATIONS; pvalue ++) {
				for (unsigned int Percent = 0; Percent < PERCENT_ITERATIONS; Percent ++) {
					for (unsigned int skips = 0; skips < SKIP_ITERATIONS; skips ++) {
						unsigned short int non_default_values = 0;
						if (coverage_array[c] != defaults.coverage) {
							non_default_values++;
						}
						if (cpn_array[CpG] != defaults.CpN) {
							non_default_values++;
						}
						if (p_array[pvalue] != defaults.p) {
							non_default_values++;
						}
						if (percent_array[Percent] != defaults.percent) {
							non_default_values++;
						}
						if (skip_array[skips] != defaults.skip) {
							non_default_values++;
						}
//						printf("c%u	CpN%u	p%.2f	P%.2f	S%u\n", c, CpG, pvalue, Percent, skips);
						if (non_default_values <= ALLOWED_NON_DEFAULTS) {
							runs++;
						}
					}
				}
			}
		}
	}
	free(coverage_array); coverage_array = NULL;
	free(cpn_array); cpn_array = NULL;
	free(p_array); p_array = NULL;
	free(percent_array); percent_array = NULL;
	free(skip_array); skip_array = NULL;
	return runs;
}

cutoff_struct *restrict make_cutoff_struct (const option_range_struct coverage, const option_range_struct CpN, const option_range_struct p, const option_range_struct percent, const option_range_struct skip,  const cutoff_struct defaults, const unsigned short int ALLOWED_NON_DEFAULTS) {
	const unsigned int RUNS = how_many_runs(coverage, CpN, p, percent, skip, defaults, ALLOWED_NON_DEFAULTS);
	if (RUNS == 0) {
		return NULL;
	}
	cutoff_struct *restrict array = malloc(RUNS * sizeof(cutoff_struct));
	if (RUNS == 1) {//don't bother allocating
		array[0].coverage = defaults.coverage;
		array[0].CpN = defaults.CpN;
		array[0].p = defaults.p;
		array[0].percent = defaults.percent;
		array[0].skip = defaults.skip;
		array[0].number_of_DMRs = 0;
		return array;
	}
	const unsigned int COVERAGE_ITERATIONS = how_many_uint_array_elements(defaults.coverage, coverage);
	const unsigned int CPN_ITERATIONS = how_many_uint_array_elements(defaults.CpN, CpN);
	const unsigned int P_ITERATIONS = how_many_double_array_elements(defaults.p, p);
	const unsigned int PERCENT_ITERATIONS = how_many_double_array_elements(defaults.percent, percent);
	const unsigned int SKIP_ITERATIONS = how_many_uint_array_elements(defaults.skip, skip);
	unsigned int *restrict cpn_array = uint_array_alloc(defaults.CpN, CpN);
	unsigned int *restrict coverage_array = uint_array_alloc(defaults.coverage, coverage);
	double *restrict p_array = double_array_alloc(defaults.p, p);
	double *restrict percent_array = double_array_alloc(defaults.percent, percent);
	unsigned int *restrict skip_array = uint_array_alloc(defaults.skip, skip);
	unsigned int run = 0;//first run is all defaults
	for (unsigned int c = 0; c < COVERAGE_ITERATIONS; c++) {
		for (unsigned int CpG = 0; CpG < CPN_ITERATIONS; CpG++) {
			for (unsigned int pvalue = 0; pvalue < P_ITERATIONS; pvalue ++) {
				for (unsigned int Percent = 0; Percent < PERCENT_ITERATIONS; Percent ++) {
					for (unsigned int skips = 0; skips < SKIP_ITERATIONS; skips ++) {
						unsigned short int non_default_values = 0;
						if (coverage_array[c] != defaults.coverage) {
							non_default_values++;
						}
						if (cpn_array[CpG] != defaults.CpN) {
							non_default_values++;
						}
						if (p_array[pvalue] != defaults.p) {
							non_default_values++;
						}
						if (percent_array[Percent] != defaults.percent) {
							non_default_values++;
						}
						if (skip_array[skips] != defaults.skip) {
							non_default_values++;
						}
						if (non_default_values <= ALLOWED_NON_DEFAULTS) {
							array[run].coverage = coverage_array[c];
							array[run].CpN = cpn_array[CpG];
							array[run].p = p_array[pvalue];
							array[run].percent = percent_array[Percent];
							array[run].skip = skips;
							array[run].number_of_DMRs = 0;
							run++;
						}
					}
				}
			}
		}
	}
	free(coverage_array); coverage_array = NULL;
	free(cpn_array); cpn_array = NULL;
	free(p_array); p_array = NULL;
	free(percent_array); percent_array = NULL;
	free(skip_array); skip_array = NULL;
	return array;
}
